import { useEffect, useState } from "react";
import { supabase } from "../lib/supabase";

type Cliente = {
  id: string;
  nome: string;
  telefone: string;
  email: string;
};

export default function ClientesPage() {
  const [clientes, setClientes] = useState<Cliente[]>([]);
  const [loading, setLoading] = useState(true);

  const [nome, setNome] = useState("");
  const [telefone, setTelefone] = useState("");
  const [email, setEmail] = useState("");

  const [mostrarFormulario, setMostrarFormulario] = useState(false);
  const [editandoId, setEditandoId] = useState<string | null>(null);

  async function carregarClientes() {
    setLoading(true);

    const { data } = await supabase
      .from("clientes")
      .select("*")
      .order("nome", { ascending: true });

    setClientes(data || []);
    setLoading(false);
  }

  useEffect(() => {
    carregarClientes();
  }, []);

  function limparFormulario() {
    setNome("");
    setTelefone("");
    setEmail("");
    setEditandoId(null);
    setMostrarFormulario(false);
  }

  async function salvarCliente(e: any) {
    e.preventDefault();

    if (!nome) {
      alert("Nome é obrigatório");
      return;
    }

    if (editandoId) {
      await supabase
        .from("clientes")
        .update({
          nome,
          telefone,
          email,
        })
        .eq("id", editandoId);

      limparFormulario();
      carregarClientes();
      return;
    }

    await supabase.from("clientes").insert([
      {
        nome,
        telefone,
        email,
      },
    ]);

    limparFormulario();
    carregarClientes();
  }

  function editarCliente(item: Cliente) {
    setNome(item.nome);
    setTelefone(item.telefone || "");
    setEmail(item.email || "");
    setEditandoId(item.id);
    setMostrarFormulario(true);
  }

  async function excluirCliente(id: string) {
    const confirmar = confirm("Excluir cliente?");
    if (!confirmar) return;

    await supabase.from("clientes").delete().eq("id", id);
    carregarClientes();
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between">
        <h1 className="text-2xl font-bold">Clientes</h1>

        <button
          onClick={() => setMostrarFormulario(!mostrarFormulario)}
          className="bg-orange-500 text-white px-4 py-2 rounded"
        >
          {mostrarFormulario ? "Fechar" : "Novo cliente"}
        </button>
      </div>

      {mostrarFormulario && (
        <form onSubmit={salvarCliente} className="space-y-3 bg-white p-4 rounded border">
          <input
            placeholder="Nome"
            value={nome}
            onChange={(e) => setNome(e.target.value)}
            className="border p-2 w-full"
          />

          <input
            placeholder="Telefone"
            value={telefone}
            onChange={(e) => setTelefone(e.target.value)}
            className="border p-2 w-full"
          />

          <input
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="border p-2 w-full"
          />

          <button className="bg-black text-white px-4 py-2 rounded">
            {editandoId ? "Atualizar" : "Salvar"}
          </button>
        </form>
      )}

      <div className="space-y-2">
        {loading ? (
          <p>Carregando...</p>
        ) : clientes.length === 0 ? (
          <p>Nenhum cliente cadastrado.</p>
        ) : (
          clientes.map((item) => (
            <div key={item.id} className="border p-3 rounded flex justify-between">
              <div>
                <p className="font-bold">{item.nome}</p>
                <p className="text-sm">{item.telefone}</p>
                <p className="text-sm text-gray-500">{item.email}</p>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => editarCliente(item)}
                  className="text-blue-600"
                >
                  Editar
                </button>

                <button
                  onClick={() => excluirCliente(item.id)}
                  className="text-red-600"
                >
                  Excluir
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}