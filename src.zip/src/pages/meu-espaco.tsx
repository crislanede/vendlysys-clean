import { useEffect, useState } from "react";
import { supabase } from "../lib/supabase";
import AssinaturaCanvas from "../components/AssinaturaCanvas";
import { gerarHash } from "../lib/hash";
import { gerarPdfBlob } from "../lib/pdfAnamnese";
import { uploadPdfAnamnese } from "../lib/uploadAnamnese";

import type {
  CampoAnamnese,
  ServicoCliente,
  ProfissionalCliente,
} from "./meu-espaco/types";

import {
  limparTelefone,
  formatarData,
  formatarMoeda,
  primeiroNome,
  hojeISO,
  somarMinutos,
  normalizarHorario,
  horarioSobrepoeIntervalo,
  gerarHorariosBase,
} from "./meu-espaco/utils";

function obterDataBaseAnamnese(ficha: any) {
  return (
    ficha?.data_assinatura ||
    ficha?.preenchido_em ||
    ficha?.created_at ||
    ficha?.criado_em ||
    null
  );
}

function calcularValidadeAnamnese(ficha: any) {
  const dataBase = obterDataBaseAnamnese(ficha);

  if (!dataBase) return null;

  const validade = new Date(dataBase);
  validade.setMonth(validade.getMonth() + 12);
  return validade;
}

function anamneseEstaVencida(ficha: any) {
  const validade = calcularValidadeAnamnese(ficha);

  if (!validade) return true;

  return validade < new Date();
}

function formatarDataAnamnese(data?: string | Date | null) {
  if (!data) return "-";

  const dataObj = data instanceof Date ? data : new Date(data);

  if (Number.isNaN(dataObj.getTime())) return "-";

  return dataObj.toLocaleDateString("pt-BR");
}

function normalizarChaveAnamnese(valor?: string | null) {
  return String(valor || "")
    .trim()
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "");
}

function obterChaveCampoAnamnese(campo: any) {
  return normalizarChaveAnamnese(
    campo?.nome_campo || campo?.nome_interno || campo?.label || campo?.pergunta || campo?.id,
  );
}

export default function MeuEspaco() {
  const [aba, setAba] = useState("agenda");
  const [telefone, setTelefone] = useState("");
  const [modoCadastro, setModoCadastro] = useState(false);
  const [cadastro, setCadastro] = useState({
    nome: "",
    telefone: "",
    email: "",
    data_nascimento: "",
    cep: "",
    endereco: "",
    numero: "",
    bairro: "",
    cidade: "",
    estado: "",
  });
  const [editandoDados, setEditandoDados] = useState(false);
  const [salvandoDados, setSalvandoDados] = useState(false);
  const [dadosEdicao, setDadosEdicao] = useState({
    nome: "",
    email: "",
    data_nascimento: "",
    cep: "",
    endereco: "",
    numero: "",
    bairro: "",
    cidade: "",
    estado: "",
  });
  const [cadastrando, setCadastrando] = useState(false);
  const [buscandoCep, setBuscandoCep] = useState(false);
  const [cliente, setCliente] = useState<any>(null);
  const [mensagem, setMensagem] = useState("");
  const [carregando, setCarregando] = useState(false);

  const [agendamentos, setAgendamentos] = useState<any[]>([]);
  const [historico, setHistorico] = useState<any[]>([]);
  const [pacotesCliente, setPacotesCliente] = useState<any[]>([]);
  const [carregandoPacotesCliente, setCarregandoPacotesCliente] = useState(false);

  const [anamneseObrigatoria, setAnamneseObrigatoria] = useState(false);
  const [modalAnamneseAberto, setModalAnamneseAberto] = useState(false);
  const [
    assinaturaComplementarObrigatoria,
    setAssinaturaComplementarObrigatoria,
  ] = useState(false);
  const [modelo, setModelo] = useState<any>(null);
  const [empresaAnamneseId, setEmpresaAnamneseId] = useState<string | null>(
    null,
  );
  const [campos, setCampos] = useState<CampoAnamnese[]>([]);
  const [respostas, setRespostas] = useState<Record<string, string>>({});
  const [justificativas, setJustificativas] = useState<Record<string, string>>(
    {},
  );
  const [aceitaTermo, setAceitaTermo] = useState(false);
  const [assinatura, setAssinatura] = useState("");
  const [anamnesePreenchida, setAnamnesePreenchida] = useState<any>(null);
  const [, setPdfAnamneseUrl] = useState("");
  const [modoAtualizacaoAnamnese, setModoAtualizacaoAnamnese] = useState(false);
  const [salvando, setSalvando] = useState(false);

  const acessoBloqueadoPorAnamnese =
    anamneseObrigatoria || assinaturaComplementarObrigatoria;

  const [isMobile, setIsMobile] = useState(false);
  const [configuracoes, setConfiguracoes] = useState<any>(null);

  useEffect(() => {
    const atualizarMobile = () => setIsMobile(window.innerWidth < 640);
    atualizarMobile();
    window.addEventListener("resize", atualizarMobile);
    return () => window.removeEventListener("resize", atualizarMobile);
  }, []);

  function levarParaAnamneseObrigatoria() {
    setAba("anamnese");
    setModalAnamneseAberto(true);
    setMensagem(
      assinaturaComplementarObrigatoria
        ? "Para continuar, assine sua ficha de anamnese."
        : "Para continuar, preencha a ficha de anamnese obrigatória."
    );
  }

  const [servicos, setServicos] = useState<ServicoCliente[]>([]);
  const [profissionais, setProfissionais] = useState<ProfissionalCliente[]>([]);
  const [novoAgendamentoAberto, setNovoAgendamentoAberto] = useState(false);
  const [agendamentoReagendandoId, setAgendamentoReagendandoId] = useState<string | null>(null);
  const [servicoAgendamentoId, setServicoAgendamentoId] = useState("");
  const [profissionalAgendamentoId, setProfissionalAgendamentoId] =
    useState("");
  const [dataAgendamento, setDataAgendamento] = useState(hojeISO());
  const [horarioAgendamento, setHorarioAgendamento] = useState("");
  const [horariosLivres, setHorariosLivres] = useState<string[]>([]);
  const [carregandoHorarios, setCarregandoHorarios] = useState(false);
  const [salvandoAgendamento, setSalvandoAgendamento] = useState(false);
  const [valorAgendamentoFinal, setValorAgendamentoFinal] = useState<
    number | null
  >(null);
  const [precoEspecialAplicado, setPrecoEspecialAplicado] = useState(false);
  const [carregandoValorAgendamento, setCarregandoValorAgendamento] =
    useState(false);

  useEffect(() => {
    const token = new URLSearchParams(window.location.search).get("token");
    if (token) carregarPorToken(token);
  }, []);

  useEffect(() => {
    if (
      cliente &&
      servicoAgendamentoId &&
      profissionalAgendamentoId &&
      dataAgendamento
    ) {
      void carregarHorariosLivres();
    } else {
      setHorariosLivres([]);
      setHorarioAgendamento("");
    }
  }, [
    cliente,
    servicoAgendamentoId,
    profissionalAgendamentoId,
    dataAgendamento,
    agendamentoReagendandoId,
  ]);

  useEffect(() => {
    if (cliente && servicoAgendamentoId) {
      void atualizarValorAgendamento();
    } else {
      setValorAgendamentoFinal(null);
      setPrecoEspecialAplicado(false);
    }
  }, [cliente, servicoAgendamentoId]);

  async function carregarPorToken(token: string) {
    setCarregando(true);

    const { data } = await supabase
      .from("agendamentos")
      .select("cliente_id")
      .eq("token_cliente", token)
      .maybeSingle();

    if (data?.cliente_id) {
      await carregarCliente(data.cliente_id);
    } else {
      setMensagem("Link inválido ou expirado.");
    }

    setCarregando(false);
  }

  async function entrarPorTelefone() {
    const tel = limparTelefone(telefone);

    if (tel.length < 10) {
      setMensagem("Informe um telefone válido.");
      return;
    }

    setCarregando(true);
    setMensagem("");

    const { data, error } = await supabase.from("clientes").select("*");

    if (error) {
      setMensagem("Erro ao buscar cliente.");
      setCarregando(false);
      return;
    }

    const encontrado = (data || []).find((c) => {
      const telBanco = limparTelefone(c.telefone || "");
      return telBanco.endsWith(tel) || tel.endsWith(telBanco);
    });

    if (!encontrado) {
      setMensagem("Cliente não encontrado.");
      setCarregando(false);
      return;
    }

    await carregarCliente(encontrado.id);
    setCarregando(false);
  }

  async function obterEmpresaPublica() {
    const params = new URLSearchParams(window.location.search);
    const slug = params.get("empresa") || params.get("slug");

    if (slug) {
      const { data } = await supabase
        .from("empresas")
        .select("id, nome, slug")
        .eq("slug", slug)
        .maybeSingle();

      if (data?.id) return data;
    }

    // Quando o Meu Espaço está sendo testado sem slug na URL, usamos a empresa
    // ativa salva no navegador pelo painel administrativo. Isso evita cadastrar
    // cliente em uma empresa diferente da que possui os serviços.
    const empresaSalvaId = localStorage.getItem("empresa_id");
    if (empresaSalvaId) {
      const { data } = await supabase
        .from("empresas")
        .select("id, nome, slug")
        .eq("id", empresaSalvaId)
        .maybeSingle();

      if (data?.id) return data;
    }

    // Fallback mais seguro: escolhe uma empresa que tenha serviços cadastrados.
    const { data: servicoComEmpresa } = await supabase
      .from("servicos")
      .select("empresa_id")
      .not("empresa_id", "is", null)
      .limit(1)
      .maybeSingle();

    if (servicoComEmpresa?.empresa_id) {
      const { data } = await supabase
        .from("empresas")
        .select("id, nome, slug")
        .eq("id", servicoComEmpresa.empresa_id)
        .maybeSingle();

      if (data?.id) return data;
    }

    const { data } = await supabase
      .from("empresas")
      .select("id, nome, slug")
      .limit(1);

    return data?.[0] || null;
  }

  async function buscarCepCadastro(cepDigitado: string) {
    const cepLimpo = cepDigitado.replace(/\D/g, "");

    setCadastro((atual) => ({ ...atual, cep: cepDigitado }));

    if (cepLimpo.length !== 8) return;

    try {
      setBuscandoCep(true);
      setMensagem("");

      const resposta = await fetch(
        `https://viacep.com.br/ws/${cepLimpo}/json/`,
      );
      const dados = await resposta.json();

      if (dados?.erro) {
        setMensagem("CEP não encontrado. Confira o número digitado.");
        return;
      }

      setCadastro((atual) => ({
        ...atual,
        cep: cepDigitado,
        endereco: dados.logradouro || "",
        bairro: dados.bairro || "",
        cidade: dados.localidade || "",
        estado: dados.uf || "",
      }));
    } catch (error) {
      setMensagem(
        "Não foi possível buscar o CEP agora. Preencha o endereço manualmente.",
      );
    } finally {
      setBuscandoCep(false);
    }
  }

  async function buscarCepEdicao(cepDigitado: string) {
    const cepLimpo = cepDigitado.replace(/\D/g, "");

    setDadosEdicao((atual) => ({ ...atual, cep: cepDigitado }));

    if (cepLimpo.length !== 8) return;

    try {
      setBuscandoCep(true);
      setMensagem("");

      const resposta = await fetch(
        `https://viacep.com.br/ws/${cepLimpo}/json/`,
      );
      const dados = await resposta.json();

      if (dados?.erro) {
        setMensagem("CEP não encontrado. Confira o número digitado.");
        return;
      }

      setDadosEdicao((atual) => ({
        ...atual,
        cep: cepDigitado,
        endereco: dados.logradouro || "",
        bairro: dados.bairro || "",
        cidade: dados.localidade || "",
        estado: dados.uf || "",
      }));
    } catch (error) {
      setMensagem(
        "Não foi possível buscar o CEP agora. Preencha o endereço manualmente.",
      );
    } finally {
      setBuscandoCep(false);
    }
  }

  function iniciarEdicaoDados() {
    if (!cliente) return;

    setMensagem("");
    setDadosEdicao({
      nome: cliente.nome || "",
      email: cliente.email || "",
      data_nascimento: cliente.data_nascimento || "",
      cep: cliente.cep || "",
      endereco: cliente.endereco || "",
      numero: cliente.numero || "",
      bairro: cliente.bairro || "",
      cidade: cliente.cidade || "",
      estado: cliente.estado || "",
    });
    setEditandoDados(true);
  }

  function cancelarEdicaoDados() {
    setMensagem("");
    setEditandoDados(false);
  }

  async function salvarDadosCliente() {
    if (!cliente?.id) return;

    const nome = dadosEdicao.nome.trim();

    if (!nome) {
      setMensagem("Informe seu nome completo.");
      return;
    }

    setSalvandoDados(true);
    setMensagem("");

    const payload = {
      nome,
      email: dadosEdicao.email.trim() || null,
      data_nascimento: dadosEdicao.data_nascimento || null,
      cep: dadosEdicao.cep || null,
      endereco: dadosEdicao.endereco || null,
      numero: dadosEdicao.numero || null,
      bairro: dadosEdicao.bairro || null,
      cidade: dadosEdicao.cidade || null,
      estado: dadosEdicao.estado || null,
    };

    const { data, error } = await supabase
      .from("clientes")
      .update(payload)
      .eq("id", cliente.id)
      .select("*")
      .single();

    if (error) {
      setMensagem("Erro ao atualizar dados: " + error.message);
      setSalvandoDados(false);
      return;
    }

    setCliente(data || { ...cliente, ...payload });
    setEditandoDados(false);
    setSalvandoDados(false);
    setMensagem("Dados atualizados com sucesso.");
  }

  async function cadastrarClienteMeuEspaco() {
    const nome = cadastro.nome.trim();
    const telefoneCadastro = limparTelefone(cadastro.telefone);
    const email = cadastro.email.trim();

    if (!nome) {
      setMensagem("Informe seu nome completo.");
      return;
    }

    if (telefoneCadastro.length < 10) {
      setMensagem("Informe um telefone válido.");
      return;
    }

    setCadastrando(true);
    setMensagem("");

    const empresa = await obterEmpresaPublica();

    if (!empresa?.id) {
      setMensagem(
        "Não foi possível identificar a empresa para concluir o cadastro.",
      );
      setCadastrando(false);
      return;
    }

    const { data: clientesExistentes, error: erroBusca } = await supabase
      .from("clientes")
      .select("*")
      .eq("empresa_id", empresa.id);

    if (erroBusca) {
      setMensagem("Erro ao validar telefone. Tente novamente.");
      setCadastrando(false);
      return;
    }

    const clienteJaExiste = (clientesExistentes || []).find((c) => {
      const telBanco = limparTelefone(c.telefone || "");
      return (
        telBanco.endsWith(telefoneCadastro) ||
        telefoneCadastro.endsWith(telBanco)
      );
    });

    if (clienteJaExiste?.id) {
      setMensagem(
        "Este telefone já possui cadastro. Clique em Já tenho cadastro e entre usando esse número.",
      );
      setCadastrando(false);
      return;
    }

    const { data: novoCliente, error } = await supabase
      .from("clientes")
      .insert({
        nome,
        telefone: telefoneCadastro,
        email: email || null,
        data_nascimento: cadastro.data_nascimento || null,
        cep: cadastro.cep || null,
        endereco: cadastro.endereco || null,
        numero: cadastro.numero || null,
        bairro: cadastro.bairro || null,
        cidade: cadastro.cidade || null,
        estado: cadastro.estado || null,
        empresa_id: empresa.id,
      })
      .select("*")
      .single();

    if (error) {
      setMensagem("Erro ao cadastrar cliente: " + error.message);
      setCadastrando(false);
      return;
    }

    if (novoCliente?.id) {
      setTelefone(telefoneCadastro);
      setCadastro({
        nome: "",
        telefone: "",
        email: "",
        data_nascimento: "",
        cep: "",
        endereco: "",
        numero: "",
        bairro: "",
        cidade: "",
        estado: "",
      });
      setModoCadastro(false);
      await carregarCliente(novoCliente.id);
    }

    setCadastrando(false);
  }

  async function carregarConfiguracoes(empresaId: string | null) {
    if (!empresaId) {
      setConfiguracoes(null);
      return;
    }

    const { data, error } = await supabase
      .from("empresas")
      .select(`
        banner_cliente_ativo,
        banner_cliente_categoria,
        banner_cliente_titulo,
        banner_cliente_texto,
        banner_cliente_botao_texto,
        banner_cliente_botao_link,
        banner_cliente_imagem_url,
        banner_cliente_pos_x,
        banner_cliente_pos_y,
        banner_cliente_zoom
      `)
      .eq("id", empresaId)
      .maybeSingle();

    if (error) {
      console.warn("Não foi possível carregar banner:", error);
      setConfiguracoes(null);
      return;
    }

    setConfiguracoes(data);
  }

  async function carregarCliente(clienteId: string) {
    const { data } = await supabase
      .from("clientes")
      .select("*")
      .eq("id", clienteId)
      .maybeSingle();

    if (!data) {
      setMensagem("Cliente não encontrado.");
      return;
    }

    setCliente(data);

    const ags = await carregarAgendamentos(data.id);
    await carregarHistorico(data.id);
    await carregarPacotesCliente(data.id);

    const empresaId =
      data.empresa_id || ags.find((a: any) => a.empresa_id)?.empresa_id || null;
    await carregarAnamnese(data.id, empresaId);
    await carregarOpcoesAgendamento(empresaId);
    await carregarConfiguracoes(empresaId);
  }

  async function carregarAgendamentos(clienteId: string) {
    const { data } = await supabase
      .from("agendamentos")
      .select("*")
      .eq("cliente_id", clienteId)
      .neq("status", "finalizado")
      .order("data", { ascending: true });

    setAgendamentos(data || []);
    return data || [];
  }

  async function carregarHistorico(clienteId: string) {
    const { data } = await supabase
      .from("agendamentos")
      .select("*")
      .eq("cliente_id", clienteId)
      .eq("status", "finalizado")
      .order("data", { ascending: false });

    setHistorico(data || []);
  }


  async function carregarPacotesCliente(clienteId: string) {
    setCarregandoPacotesCliente(true);

    const { data: vinculos, error: erroVinculos } = await supabase
      .from("cliente_pacotes")
      .select("id, cliente_id, pacote_id, data_inicio, data_fim, validade_dias, quantidade_pacotes, status, created_at")
      .eq("cliente_id", clienteId)
      .order("created_at", { ascending: false });

    if (erroVinculos) {
      console.error("Erro ao carregar pacotes da cliente:", erroVinculos);
      setPacotesCliente([]);
      setCarregandoPacotesCliente(false);
      return;
    }

    const listaVinculos = vinculos || [];

    if (listaVinculos.length === 0) {
      setPacotesCliente([]);
      setCarregandoPacotesCliente(false);
      return;
    }

    const idsVinculos = listaVinculos.map((item: any) => item.id).filter(Boolean);
    const idsPacotes = Array.from(
      new Set(listaVinculos.map((item: any) => item.pacote_id).filter(Boolean)),
    );

    const { data: pacotesBanco } = idsPacotes.length
      ? await supabase
          .from("marketing_pacotes")
          .select("id, nome, descricao, valor_final, valor_original, status")
          .in("id", idsPacotes)
      : { data: [] as any[] };

    const { data: saldosBanco, error: erroSaldos } = idsVinculos.length
      ? await supabase
          .from("cliente_pacote_saldos")
          .select("id, cliente_pacote_id, servico_id, quantidade_total, quantidade_usada")
          .in("cliente_pacote_id", idsVinculos)
      : { data: [] as any[], error: null };

    if (erroSaldos) {
      console.error("Erro ao carregar saldos dos pacotes:", erroSaldos);
    }

    const idsServicos = Array.from(
      new Set((saldosBanco || []).map((item: any) => item.servico_id).filter(Boolean)),
    );

    const { data: servicosBanco } = idsServicos.length
      ? await supabase.from("servicos").select("id, nome").in("id", idsServicos)
      : { data: [] as any[] };

    const mapaPacotes = new Map((pacotesBanco || []).map((item: any) => [item.id, item]));
    const mapaServicos = new Map((servicosBanco || []).map((item: any) => [item.id, item]));

    const pacotesMontados = listaVinculos.map((vinculo: any) => {
      const pacote = mapaPacotes.get(vinculo.pacote_id) || null;
      const saldos = (saldosBanco || [])
        .filter((saldo: any) => saldo.cliente_pacote_id === vinculo.id)
        .map((saldo: any) => {
          const total = Number(saldo.quantidade_total || 0);
          const usada = Number(saldo.quantidade_usada || 0);
          return {
            ...saldo,
            servico_nome: mapaServicos.get(saldo.servico_id)?.nome || "Serviço",
            quantidade_total: total,
            quantidade_usada: usada,
            quantidade_restante: Math.max(total - usada, 0),
          };
        });

      const totalSessoes = saldos.reduce((total: number, saldo: any) => total + saldo.quantidade_total, 0);
      const totalUsado = saldos.reduce((total: number, saldo: any) => total + saldo.quantidade_usada, 0);
      const totalRestante = Math.max(totalSessoes - totalUsado, 0);

      return {
        ...vinculo,
        pacote,
        saldos,
        total_sessoes: totalSessoes,
        total_usado: totalUsado,
        total_restante: totalRestante,
      };
    });

    setPacotesCliente(pacotesMontados);
    setCarregandoPacotesCliente(false);
  }

  async function carregarOpcoesAgendamento(empresaId: string | null) {
    if (!empresaId) return;

    let empresaConsultaId = empresaId;

    let servicosRes = await supabase
      .from("servicos")
      .select("*")
      .eq("empresa_id", empresaConsultaId)
      .order("nome", { ascending: true });

    // Se o cliente novo foi cadastrado em uma empresa sem serviços, tentamos
    // localizar a empresa correta a partir do navegador/serviços existentes.
    if (!servicosRes.error && (servicosRes.data || []).length === 0) {
      const empresaSalvaId = localStorage.getItem("empresa_id");
      if (empresaSalvaId && empresaSalvaId !== empresaConsultaId) {
        const tentativa = await supabase
          .from("servicos")
          .select("*")
          .eq("empresa_id", empresaSalvaId)
          .order("nome", { ascending: true });

        if (!tentativa.error && (tentativa.data || []).length > 0) {
          empresaConsultaId = empresaSalvaId;
          servicosRes = tentativa;

          if (cliente?.id) {
            await supabase
              .from("clientes")
              .update({ empresa_id: empresaConsultaId })
              .eq("id", cliente.id);

            setCliente((atual: any) =>
              atual ? { ...atual, empresa_id: empresaConsultaId } : atual,
            );
          }
        }
      }
    }

    if (!servicosRes.error && (servicosRes.data || []).length === 0) {
      const todosServicos = await supabase
        .from("servicos")
        .select("*")
        .order("nome", { ascending: true });

      if (!todosServicos.error && (todosServicos.data || []).length > 0) {
        empresaConsultaId =
          todosServicos.data?.[0]?.empresa_id || empresaConsultaId;
        servicosRes = todosServicos;

        if (cliente?.id && empresaConsultaId) {
          await supabase
            .from("clientes")
            .update({ empresa_id: empresaConsultaId })
            .eq("id", cliente.id);

          setCliente((atual: any) =>
            atual ? { ...atual, empresa_id: empresaConsultaId } : atual,
          );
        }
      }
    }

    const profissionaisRes = await supabase
      .from("profissionais")
      .select("*")
      .eq("empresa_id", empresaConsultaId)
      .order("nome", { ascending: true });

    if (servicosRes.error) {
      console.error(
        "Erro ao carregar serviços no Meu Espaço:",
        servicosRes.error,
      );
      setServicos([]);
    } else {
      setServicos((servicosRes.data || []) as ServicoCliente[]);
    }

    if (profissionaisRes.error) {
      console.error(
        "Erro ao carregar profissionais no Meu Espaço:",
        profissionaisRes.error,
      );
      setProfissionais([]);
    } else {
      setProfissionais((profissionaisRes.data || []) as ProfissionalCliente[]);
    }
  }

  function pegarServicoSelecionado() {
    return servicos.find((item) => item.id === servicoAgendamentoId) || null;
  }

  function pegarProfissionalSelecionado() {
    return (
      profissionais.find((item) => item.id === profissionalAgendamentoId) ||
      null
    );
  }

  function precoBaseServico(servico: ServicoCliente | null) {
  if (!servico) return 0;

  const promocaoAtiva =
    servico?.promocao_ativa === true ||
    servico?.promocao_ativa === "true";

  const valor = promocaoAtiva
    ? Number(
        servico?.preco_promocional ??
          servico?.preco ??
          servico?.valor ??
          0,
      )
    : Number(servico?.preco ?? servico?.valor ?? 0);

  return Number.isNaN(valor) ? 0 : valor;
}
  async function calcularValorServicoCliente(
    servico: ServicoCliente | null,
    clienteAtual = cliente,
  ) {
    if (!servico) {
      return { valor: 0, especial: false };
    }

    const valorPadrao = precoBaseServico(servico);

    if (!clienteAtual?.id) {
      return { valor: valorPadrao, especial: false };
    }

    const { data, error } = await supabase
      .from("cliente_precos_servicos")
      .select("valor_especial")
      .eq("cliente_id", clienteAtual.id)
      .eq("servico_id", servico.id)
      .eq("ativo", true)
      .maybeSingle();

    if (error) {
      console.warn("Erro ao buscar preço especial do cliente:", error);
      return { valor: valorPadrao, especial: false };
    }

    const valorEspecial = Number(data?.valor_especial);

    if (data && !Number.isNaN(valorEspecial) && valorEspecial >= 0) {
      return { valor: valorEspecial, especial: true };
    }

    return { valor: valorPadrao, especial: false };
  }

  async function atualizarValorAgendamento() {
    const servicoSelecionado = pegarServicoSelecionado();

    if (!servicoSelecionado) {
      setValorAgendamentoFinal(null);
      setPrecoEspecialAplicado(false);
      return;
    }

    setCarregandoValorAgendamento(true);
    const resultado = await calcularValorServicoCliente(servicoSelecionado);
    setValorAgendamentoFinal(resultado.valor);
    setPrecoEspecialAplicado(resultado.especial);
    setCarregandoValorAgendamento(false);
  }

  async function criarLancamentoFinanceiroAgendamento(
    agendamentoId: string | null,
    servicoSelecionado: ServicoCliente,
    profissionalSelecionado: ProfissionalCliente,
    valorFinal: number,
    especialAplicado: boolean,
  ) {
    const payloadFinanceiro = {
      empresa_id: cliente.empresa_id,
      tipo: "entrada",
      descricao: `Agendamento pelo cliente: ${servicoSelecionado.nome}`,
      valor: valorFinal,
      data_lancamento: dataAgendamento,
      status: "pendente",
      cliente: cliente.nome || null,
      profissional: profissionalSelecionado.nome || null,
      servico: servicoSelecionado.nome || null,
      agendamento_id: agendamentoId,
      forma_pagamento: null,
      data_pagamento: null,
      observacoes: especialAplicado
        ? "Preço especial por serviço aplicado automaticamente no Meu Espaço."
        : "Lançamento gerado automaticamente pelo Meu Espaço.",
    };

    const { error } = await supabase
      .from("financeiro")
      .insert([payloadFinanceiro]);

    if (error) {
      console.error("Erro ao gerar financeiro do agendamento:", error);
      alert(
        "Agendamento criado, mas houve erro ao lançar no financeiro: " +
          error.message,
      );
    }
  }

  function duracaoTotalServico(servico: ServicoCliente | null) {
    const duracaoBase = Number(
      servico?.duracao_padrao_minutos || servico?.duracao || 60,
    );
    return duracaoBase + 10;
  }

  function existeConflitoHorario(
    horarioInicio: string,
    duracaoMinutos: number,
    agendamentosDia: any[],
    ignorarAgendamentoId?: string | null,
  ) {
    const horarioFim = somarMinutos(horarioInicio, duracaoMinutos);

    return agendamentosDia.some((item) => {
      if (item.status === "cancelado") return false;
      if (ignorarAgendamentoId && item.id === ignorarAgendamentoId) return false;

      const inicioExistente = item.horario;
      const fimExistente = somarMinutos(
        item.horario,
        Number(item.duracao_minutos || 60),
      );

      return horarioInicio < fimExistente && horarioFim > inicioExistente;
    });
  }

  async function carregarHorariosLivres() {
    const servicoSelecionado = pegarServicoSelecionado();

    if (
      !cliente?.empresa_id ||
      !servicoSelecionado ||
      !profissionalAgendamentoId ||
      !dataAgendamento
    ) {
      setHorariosLivres([]);
      return;
    }

    setCarregandoHorarios(true);
    setHorarioAgendamento("");

    const duracaoTotal = duracaoTotalServico(servicoSelecionado);
    const profissionalSelecionado = pegarProfissionalSelecionado();

    if (!profissionalSelecionado) {
      setHorariosLivres([]);
      setCarregandoHorarios(false);
      return;
    }

    const inicioExpediente = normalizarHorario(
      profissionalSelecionado.inicio_expediente,
      "08:00",
    );
    const fimExpediente = normalizarHorario(
      profissionalSelecionado.fim_expediente,
      "18:00",
    );
    const inicioAlmoco = normalizarHorario(
      profissionalSelecionado.inicio_almoco,
    );
    const fimAlmoco = normalizarHorario(profissionalSelecionado.fim_almoco);


    const { data: agendamentosDia, error } = await supabase
      .from("agendamentos")
      .select("id, data, horario, status, duracao_minutos, profissional_id")
      .eq("empresa_id", cliente.empresa_id)
      .eq("profissional_id", profissionalAgendamentoId)
      .eq("data", dataAgendamento)
      .neq("status", "cancelado");

    if (error) {
      console.error("Erro ao buscar horários:", error);
      alert("Erro ao buscar horários disponíveis: " + error.message);
      setHorariosLivres([]);
      setCarregandoHorarios(false);
      return;
    }

    const livres = gerarHorariosBase(
      inicioExpediente,
      fimExpediente,
     30 ,
 ).filter((horario: string) => {
      const fimServico = somarMinutos(horario, duracaoTotal);

      if (horario < inicioExpediente) return false;
      if (fimServico > fimExpediente) return false;

      if (
        horarioSobrepoeIntervalo(
          horario,
          duracaoTotal,
          inicioAlmoco,
          fimAlmoco,
        )
      ) {
        return false;
      }

      return !existeConflitoHorario(
        horario,
        duracaoTotal,
        agendamentosDia || [],
        agendamentoReagendandoId,
      );
    });

    setHorariosLivres(livres);
    setCarregandoHorarios(false);
  }

  function limparFormularioAgendamento() {
    setAgendamentoReagendandoId(null);
    setNovoAgendamentoAberto(false);
    setPacotesCliente([]);
    setAgendamentoReagendandoId(null);
    setServicoAgendamentoId("");
    setProfissionalAgendamentoId("");
    setDataAgendamento(hojeISO());
    setHorarioAgendamento("");
    setValorAgendamentoFinal(null);
    setPrecoEspecialAplicado(false);
  }

  async function confirmarAgendamentoCliente(agendamento: any) {
    if (!agendamento?.id || !cliente?.id) return;

    const confirmar = window.confirm("Confirmar este agendamento?");
    if (!confirmar) return;

    const { error } = await supabase
      .from("agendamentos")
      .update({ status: "confirmado" })
      .eq("id", agendamento.id)
      .eq("cliente_id", cliente.id);

    if (error) {
      alert("Erro ao confirmar agendamento: " + error.message);
      return;
    }

    alert("Agendamento confirmado com sucesso!");
    await carregarAgendamentos(cliente.id);
  }

  async function cancelarAgendamentoCliente(agendamento: any) {
    if (!agendamento?.id || !cliente?.id) return;

    const confirmar = window.confirm(
      "Tem certeza que deseja cancelar este agendamento?",
    );
    if (!confirmar) return;

    const { error } = await supabase
      .from("agendamentos")
      .update({ status: "cancelado" })
      .eq("id", agendamento.id)
      .eq("cliente_id", cliente.id);

    if (error) {
      alert("Erro ao cancelar agendamento: " + error.message);
      return;
    }

    alert("Agendamento cancelado com sucesso!");
    limparFormularioAgendamento();
    await carregarAgendamentos(cliente.id);
  }

  function iniciarReagendamentoCliente(agendamento: any) {
    if (!agendamento?.id) return;

    setAgendamentoReagendandoId(agendamento.id);
    setNovoAgendamentoAberto(true);
    setServicoAgendamentoId(agendamento.servico_id || "");
    setProfissionalAgendamentoId(agendamento.profissional_id || "");
    setDataAgendamento(agendamento.data || hojeISO());
    setHorarioAgendamento(agendamento.horario || "");
    setMensagem("Escolha a nova data e/ou horário e confirme o reagendamento.");
  }

  async function salvarNovoAgendamentoCliente() {
    if (acessoBloqueadoPorAnamnese) {
      levarParaAnamneseObrigatoria();
      alert(
        assinaturaComplementarObrigatoria
          ? "Para agendar, primeiro assine sua ficha de anamnese."
          : "Para agendar, primeiro preencha a ficha de anamnese obrigatória."
      );
      return;
    }

    if (!cliente?.empresa_id) {
      alert("Empresa não encontrada para este cliente.");
      return;
    }

    const servicoSelecionado = pegarServicoSelecionado();
    const profissionalSelecionado = pegarProfissionalSelecionado();

    if (
      !servicoSelecionado ||
      !profissionalSelecionado ||
      !dataAgendamento ||
      !horarioAgendamento
    ) {
      alert("Escolha serviço, profissional, data e horário.");
      return;
    }

    const duracaoTotal = duracaoTotalServico(servicoSelecionado);

    const inicioExpediente = normalizarHorario(
      profissionalSelecionado.inicio_expediente,
      "08:00",
    );
    const fimExpediente = normalizarHorario(
      profissionalSelecionado.fim_expediente,
      "18:00",
    );

    if (
      horarioAgendamento < inicioExpediente ||
      somarMinutos(horarioAgendamento, duracaoTotal) > fimExpediente
    ) {
      alert("Este horário está fora do expediente do profissional.");
      await carregarHorariosLivres();
      return;
    }

    if (
      horarioSobrepoeIntervalo(
        horarioAgendamento,
        duracaoTotal,
        profissionalSelecionado.inicio_almoco,
        profissionalSelecionado.fim_almoco,
      )
    ) {
      alert("Este horário está no intervalo de almoço do profissional. Escolha outro horário.");
      await carregarHorariosLivres();
      return;
    }

    const { data: agendamentosDia, error: erroConsulta } = await supabase
      .from("agendamentos")
      .select("id, horario, status, duracao_minutos")
      .eq("empresa_id", cliente.empresa_id)
      .eq("profissional_id", profissionalSelecionado.id)
      .eq("data", dataAgendamento)
      .neq("status", "cancelado");

    if (erroConsulta) {
      alert("Erro ao validar horário: " + erroConsulta.message);
      return;
    }

    if (
      existeConflitoHorario(
        horarioAgendamento,
        duracaoTotal,
        agendamentosDia || [],
        agendamentoReagendandoId,
      )
    ) {
      alert("Já existe um agendamento nesse intervalo. Escolha outro horário.");
      await carregarHorariosLivres();
      return;
    }

    setSalvandoAgendamento(true);

    const valorCalculado =
      await calcularValorServicoCliente(servicoSelecionado);

    let agendamentoCriado: any = null;
    let error: any = null;

    const payloadAgendamento = {
      empresa_id: cliente.empresa_id,
      cliente: cliente.nome,
      cliente_id: cliente.id,
      servico: servicoSelecionado.nome,
      servico_id: servicoSelecionado.id,
      profissional: profissionalSelecionado.nome,
      profissional_id: profissionalSelecionado.id,
      data: dataAgendamento,
      horario: horarioAgendamento,
      duracao_minutos: duracaoTotal,
      status: "agendado",
      no_show: false,
      observacoes: valorCalculado.especial
        ? `Agendamento realizado pelo Meu Espaço. Preço especial aplicado: ${formatarMoeda(valorCalculado.valor)}`
        : "Agendamento realizado pelo Meu Espaço",
    };

    if (agendamentoReagendandoId) {
      const resultado = await supabase
        .from("agendamentos")
        .update({
          ...payloadAgendamento,
          observacoes: valorCalculado.especial
            ? `Agendamento reagendado pelo Meu Espaço. Preço especial aplicado: ${formatarMoeda(valorCalculado.valor)}`
            : "Agendamento reagendado pelo Meu Espaço",
        })
        .eq("id", agendamentoReagendandoId)
        .eq("cliente_id", cliente.id)
        .select("id")
        .single();

      agendamentoCriado = resultado.data;
      error = resultado.error;
    } else {
      const resultado = await supabase
        .from("agendamentos")
        .insert([payloadAgendamento])
        .select("id")
        .single();

      agendamentoCriado = resultado.data;
      error = resultado.error;
    }

    if (error) {
      console.error(
        agendamentoReagendandoId
          ? "Erro ao reagendar agendamento:"
          : "Erro ao criar agendamento:",
        error,
      );
      setSalvandoAgendamento(false);
      alert(
        agendamentoReagendandoId
          ? "Erro ao reagendar agendamento: " + error.message
          : "Erro ao criar agendamento: " + error.message,
      );
      return;
    }

    if (!agendamentoReagendandoId) {
      await criarLancamentoFinanceiroAgendamento(
        agendamentoCriado?.id || null,
        servicoSelecionado,
        profissionalSelecionado,
        valorCalculado.valor,
        valorCalculado.especial,
      );
    }

    setSalvandoAgendamento(false);

    alert(
      agendamentoReagendandoId
        ? "Agendamento reagendado com sucesso!"
        : "Agendamento criado com sucesso!",
    );
    limparFormularioAgendamento();
    await carregarAgendamentos(cliente.id);
  }

  async function carregarAnamnese(clienteId: string, empresaId: string | null) {
    let query = supabase
      .from("anamnese_modelos")
      .select("*")
      .eq("ativo", true)
      .limit(1);

    if (empresaId) {
      query = query.or(`empresa_id.eq.${empresaId},empresa_id.is.null`);
    }

    const { data: modeloData } = await query.maybeSingle();

    if (!modeloData) {
      setModelo(null);
      setCampos([]);
      setEmpresaAnamneseId(empresaId || null);
      setAnamneseObrigatoria(false);
      setModalAnamneseAberto(false);
      setAnamnesePreenchida(null);
      setPdfAnamneseUrl("");
      setAssinaturaComplementarObrigatoria(false);
      setModoAtualizacaoAnamnese(false);
      return;
    }

    setModelo(modeloData);
    setEmpresaAnamneseId(modeloData.empresa_id || empresaId || null);

    const { data: camposData, error: erroCampos } = await supabase
      .from("anamnese_campos")
      .select("*")
      .eq("modelo_id", modeloData.id)
      .eq("ativo", true)
      .order("ordem", { ascending: true });

    if (erroCampos) {
      console.error("Erro ao carregar campos da anamnese:", erroCampos);
      setCampos([]);
      setAnamneseObrigatoria(false);
      setAssinaturaComplementarObrigatoria(false);
      return;
    }

    // Remove duplicidades geradas por versões antigas da configuração.
    // A chave usa nome_campo/nome_interno quando existir, pois é mais estável
    // do que o id. Isso evita pedir novamente "Possui alergia?" quando o campo
    // antigo foi recriado com outro id.
    const mapaCamposAtivos = new Map<string, CampoAnamnese>();
    ((camposData || []) as CampoAnamnese[]).forEach((campo: any) => {
      const chave = obterChaveCampoAnamnese(campo);
      if (!chave) return;
      if (!mapaCamposAtivos.has(chave)) {
        mapaCamposAtivos.set(chave, campo as CampoAnamnese);
      }
    });

    const camposAtivos = Array.from(mapaCamposAtivos.values());

    const { data: fichasPreenchidas, error: erroFichas } = await supabase
      .from("anamneses_clientes")
      .select("*")
      .eq("cliente_id", clienteId)
      .eq("preenchido", true)
      .order("preenchido_em", { ascending: false });

    if (erroFichas) {
      console.error("Erro ao carregar anamnese preenchida:", erroFichas);
    }

    const listaFichas = (fichasPreenchidas || []) as any[];
    const fichaPreenchida = listaFichas.length > 0 ? listaFichas[0] : null;

    setAnamnesePreenchida(fichaPreenchida);
    setPdfAnamneseUrl(fichaPreenchida?.pdf_url || "");

    const respostasAnteriores: Record<string, string> = {};
    const justificativasAnteriores: Record<string, string> = {};
    const respostasPorChave: Record<string, string> = {};
    const justificativasPorChave: Record<string, string> = {};
    const camposRespondidosIds = new Set<string>();
    const camposRespondidosChaves = new Set<string>();

    const idsFichas = listaFichas
      .map((ficha: any) => ficha?.id)
      .filter(Boolean);

    if (idsFichas.length > 0) {
      const { data: respostasSalvas, error: erroRespostasSalvas } =
        await supabase
          .from("anamnese_respostas")
          .select("anamnese_id, campo_id, resposta")
          .in("anamnese_id", idsFichas);

      if (erroRespostasSalvas) {
        console.warn(
          "Não foi possível carregar respostas anteriores da anamnese:",
          erroRespostasSalvas,
        );
      }

      const idsCamposRespondidos = Array.from(
        new Set(
          (respostasSalvas || [])
            .map((item: any) => item?.campo_id)
            .filter(Boolean),
        ),
      );

      let camposDasRespostas: any[] = [];

      if (idsCamposRespondidos.length > 0) {
        const { data: camposRespondidosData } = await supabase
          .from("anamnese_campos")
          .select("*")
          .in("id", idsCamposRespondidos);

        camposDasRespostas = camposRespondidosData || [];
      }

      const mapaCamposPorId = new Map<string, any>();
      [...camposDasRespostas, ...camposAtivos].forEach((campo: any) => {
        if (campo?.id) mapaCamposPorId.set(campo.id, campo);
      });

      // Percorremos as fichas da mais recente para a mais antiga.
      // A resposta mais nova prevalece, mas uma resposta antiga também conta
      // como preenchida quando o campo atual tem a mesma chave lógica.
      idsFichas.forEach((anamneseId: string) => {
        (respostasSalvas || [])
          .filter((item: any) => item?.anamnese_id === anamneseId)
          .forEach((item: any) => {
            const campoId = item?.campo_id;
            const respostaSalva = String(item?.resposta || "").trim();

            if (!campoId || !respostaSalva) return;

            const campoRelacionado = mapaCamposPorId.get(campoId);
            const chaveCampo = obterChaveCampoAnamnese(campoRelacionado);

            camposRespondidosIds.add(campoId);
            if (chaveCampo) camposRespondidosChaves.add(chaveCampo);

            let respostaNormalizada = respostaSalva;
            let justificativaNormalizada = "";

            if (
              campoRelacionado?.tipo === "sim_nao_justificativa" &&
              respostaSalva.startsWith("Sim - ")
            ) {
              respostaNormalizada = "Sim";
              justificativaNormalizada = respostaSalva.replace("Sim - ", "");
            }

            if (!respostasAnteriores[campoId]) {
              respostasAnteriores[campoId] = respostaNormalizada;
              if (justificativaNormalizada) {
                justificativasAnteriores[campoId] = justificativaNormalizada;
              }
            }

            if (chaveCampo && !respostasPorChave[chaveCampo]) {
              respostasPorChave[chaveCampo] = respostaNormalizada;
              if (justificativaNormalizada) {
                justificativasPorChave[chaveCampo] = justificativaNormalizada;
              }
            }
          });
      });
    }

    // Reaplica respostas antigas nos ids atuais quando o campo foi recriado.
    camposAtivos.forEach((campo: any) => {
      const chave = obterChaveCampoAnamnese(campo);
      if (!chave) return;

      if (!respostasAnteriores[campo.id] && respostasPorChave[chave]) {
        respostasAnteriores[campo.id] = respostasPorChave[chave];
      }

      if (!justificativasAnteriores[campo.id] && justificativasPorChave[chave]) {
        justificativasAnteriores[campo.id] = justificativasPorChave[chave];
      }
    });

    const camposNovosObrigatorios = camposAtivos.filter((campo: any) => {
      if (!campo.obrigatorio) return false;

      const resposta = respostasAnteriores[campo.id];

      return !resposta || String(resposta).trim() === "";
    });

    const temCamposNovosObrigatorios =
      Boolean(fichaPreenchida) && camposNovosObrigatorios.length > 0;

    const fichaVencida = fichaPreenchida
      ? anamneseEstaVencida(fichaPreenchida)
      : false;

    // Regra de produção:
    // - Sem ficha preenchida: mostra a ficha completa.
    // - Ficha vencida após 12 meses: mostra a ficha completa com respostas antigas carregadas.
    // - Nova pergunta obrigatória: mostra SOMENTE os campos novos pendentes.
    // - Ficha preenchida sem assinatura: pede apenas assinatura complementar.
    const precisaPreencher =
      !fichaPreenchida || fichaVencida || temCamposNovosObrigatorios;

    const precisaAssinarFichaAntiga =
      Boolean(fichaPreenchida) &&
      !fichaVencida &&
      !temCamposNovosObrigatorios &&
      !fichaPreenchida?.assinatura;

    if (temCamposNovosObrigatorios && !fichaVencida) {
      setCampos(camposNovosObrigatorios);
    } else {
      setCampos(camposAtivos);
    }

    setAnamneseObrigatoria(precisaPreencher);
    setAssinaturaComplementarObrigatoria(precisaAssinarFichaAntiga);
    setModoAtualizacaoAnamnese(
      Boolean(fichaPreenchida) && (fichaVencida || temCamposNovosObrigatorios),
    );

    if (precisaPreencher || precisaAssinarFichaAntiga) {
      setRespostas(fichaPreenchida ? respostasAnteriores : {});
      setJustificativas(fichaPreenchida ? justificativasAnteriores : {});
      setAceitaTermo(false);
      setAssinatura("");
      setAba("anamnese");
      setModalAnamneseAberto(true);

      if (temCamposNovosObrigatorios && !fichaVencida) {
        setMensagem(
          "Há nova pergunta obrigatória na sua ficha. Responda somente os campos abaixo e assine novamente para continuar.",
        );
      } else if (fichaVencida) {
        setMensagem(
          "Sua ficha de anamnese venceu. Atualize e assine novamente para continuar.",
        );
      } else if (!fichaPreenchida) {
        setMensagem("Para continuar, preencha a ficha de anamnese obrigatória.");
      }
    } else {
      setRespostas({});
      setJustificativas({});
      setModalAnamneseAberto(false);
      setAba("agenda");
    }
  }

  async function carregarRespostasAnamneseAtual() {
    if (!anamnesePreenchida?.id) {
      setRespostas({});
      setJustificativas({});
      return;
    }

    const { data } = await supabase
      .from("anamnese_respostas")
      .select("campo_id, resposta")
      .eq("anamnese_id", anamnesePreenchida.id);

    const novasRespostas: Record<string, string> = {};
    const novasJustificativas: Record<string, string> = {};

    (data || []).forEach((item: any) => {
      const campo = campos.find((c) => c.id === item?.campo_id);
      const respostaSalva = String(item?.resposta || "");

      if (
        campo?.tipo === "sim_nao_justificativa" &&
        respostaSalva.startsWith("Sim - ")
      ) {
        novasRespostas[item.campo_id] = "Sim";
        novasJustificativas[item.campo_id] = respostaSalva.replace(
          "Sim - ",
          "",
        );
      } else {
        novasRespostas[item.campo_id] = respostaSalva;
      }
    });

    setRespostas(novasRespostas);
    setJustificativas(novasJustificativas);
  }

  async function abrirAtualizacaoAnamnese() {
    await carregarRespostasAnamneseAtual();
    setModoAtualizacaoAnamnese(true);
    setAceitaTermo(false);
    setAssinatura("");
    setAba("anamnese");
  }

  function cancelarAtualizacaoAnamnese() {
    setModoAtualizacaoAnamnese(false);
    setRespostas({});
    setJustificativas({});
    setAceitaTermo(false);
    setAssinatura("");
  }

  function alterarResposta(id: string, valor: string) {
    setRespostas((prev) => ({ ...prev, [id]: valor }));

    if (valor !== "Sim") {
      setJustificativas((prev) => ({ ...prev, [id]: "" }));
    }
  }

  function alterarJustificativa(id: string, valor: string) {
    setJustificativas((prev) => ({ ...prev, [id]: valor }));
  }

  async function buscarIpCliente() {
    try {
      const resposta = await fetch("https://api.ipify.org?format=json");
      const dados = await resposta.json();
      return dados?.ip || "Não informado";
    } catch {
      return "Não informado";
    }
  }

  function montarRespostasParaPdf() {
    const respostasPdf: Record<string, string> = {};

    campos.forEach((campo) => {
      const resposta = respostas[campo.id] || "";
      const justificativa = justificativas[campo.id] || "";

      respostasPdf[campo.label] =
        campo.tipo === "sim_nao_justificativa" && resposta === "Sim"
          ? `Sim - ${justificativa}`
          : resposta;
    });

    return respostasPdf;
  }

  async function baixarPdfAnamnese() {
    if (!cliente) {
      alert("Cliente não encontrado.");
      return;
    }

    try {
      const empresaIdParaPdf =
        cliente?.empresa_id || empresaAnamneseId || modelo?.empresa_id || null;

      const { data: empresa } = empresaIdParaPdf
        ? await supabase
            .from("empresas")
            .select("nome")
            .eq("id", empresaIdParaPdf)
            .maybeSingle()
        : { data: null };

      const { data: respostasBanco, error: erroRespostas } = await supabase
        .from("anamnese_respostas")
        .select(`
          id,
          campo_id,
          resposta,
          justificativa,
          created_at,
          anamnese_campos (
            id,
            pergunta,
            label,
            nome_campo,
            tipo,
            ordem,
            ativo,
            modelo_id
          )
        `)
        .eq("cliente_id", cliente.id);

      if (erroRespostas) {
        console.error("Erro ao buscar respostas da anamnese:", erroRespostas);
        alert("Erro ao buscar respostas da anamnese.");
        return;
      }

      const respostasPorCampo = new Map<string, any>();

      (respostasBanco || []).forEach((item: any) => {
        const campoId = item?.campo_id;
        if (!campoId) return;

        const respostaExistente = respostasPorCampo.get(campoId);
        const dataAtual = new Date(item?.created_at || 0).getTime();
        const dataExistente = new Date(
          respostaExistente?.created_at || 0,
        ).getTime();

        if (!respostaExistente || dataAtual >= dataExistente) {
          respostasPorCampo.set(campoId, item);
        }
      });

      const respostasOrdenadas = Array.from(respostasPorCampo.values()).sort(
        (a: any, b: any) => {
          const campoA = Array.isArray(a?.anamnese_campos)
            ? a.anamnese_campos[0]
            : a?.anamnese_campos;
          const campoB = Array.isArray(b?.anamnese_campos)
            ? b.anamnese_campos[0]
            : b?.anamnese_campos;

          const ordemA = Number(campoA?.ordem ?? 9999);
          const ordemB = Number(campoB?.ordem ?? 9999);

          if (ordemA !== ordemB) return ordemA - ordemB;

          return String(campoA?.pergunta || campoA?.label || "").localeCompare(
            String(campoB?.pergunta || campoB?.label || ""),
            "pt-BR",
          );
        },
      );

      const respostasPdf: Record<string, string> = {};

      respostasOrdenadas.forEach((item: any) => {
        const campo = Array.isArray(item?.anamnese_campos)
          ? item.anamnese_campos[0]
          : item?.anamnese_campos;

        if (!campo || campo.ativo === false) return;

        const label =
          campo?.label || campo?.pergunta || campo?.nome_campo || "Campo";

        let textoResposta = item?.resposta || "-";

        if (
          campo?.tipo === "sim_nao_justificativa" &&
          String(item?.resposta || "").toLowerCase() === "sim"
        ) {
          textoResposta = item?.justificativa
            ? `Sim - ${item.justificativa}`
            : "Sim";
        }

        respostasPdf[label] = textoResposta;
      });

      if (Object.keys(respostasPdf).length === 0) {
        alert("Nenhuma resposta de anamnese encontrada para este cliente.");
        return;
      }

      const pdfBlob = gerarPdfBlob({
        empresaNome:
          empresa?.nome || cliente?.empresa_nome || "Seu estabelecimento",
        clienteNome: cliente?.nome || "Cliente",
        respostas: respostasPdf,
        assinatura: anamnesePreenchida?.assinatura || assinatura || "",
        hash: anamnesePreenchida?.hash || "",
        ip: anamnesePreenchida?.ip || "",
        data:
          anamnesePreenchida?.data_assinatura ||
          anamnesePreenchida?.preenchido_em ||
          anamnesePreenchida?.created_at ||
          new Date().toISOString(),
      });

      const url = URL.createObjectURL(pdfBlob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `anamnese-${cliente?.nome || "cliente"}.pdf`;
      link.click();
      URL.revokeObjectURL(url);
    } catch (erro) {
      console.error("Erro ao gerar PDF da anamnese:", erro);
      alert("Erro ao gerar PDF da anamnese.");
    }
  }

  async function salvarAssinaturaComplementar() {
    if (!cliente || !anamnesePreenchida) return;

    if (modelo?.termo_responsabilidade && !aceitaTermo) {
      alert("Aceite o termo de responsabilidade.");
      return;
    }

    if (!assinatura) {
      alert("Assine a ficha antes de enviar.");
      return;
    }

    setSalvando(true);

    const dataAssinatura = new Date().toISOString();
    const ip = await buscarIpCliente();

    const { data: respostasSalvas } = await supabase
      .from("anamnese_respostas")
      .select("campo_id, resposta")
      .eq("anamnese_id", anamnesePreenchida.id);

    const respostasPdf: Record<string, string> = {};

    (respostasSalvas || []).forEach((item: any) => {
      const campo = campos.find((c) => c.id === item?.campo_id);
      const label = campo?.label || "Campo";
      respostasPdf[label] = item?.resposta || "";
    });

    const hash = await gerarHash(
      JSON.stringify({
        anamnese_id: anamnesePreenchida.id,
        cliente_id: cliente.id,
        cliente_nome: cliente.nome,
        respostas: respostasPdf,
        assinatura,
        ip,
        dataAssinatura,
      }),
    );

    let pdfUrl = "";

    try {
      const pdfBlob = gerarPdfBlob({
        empresaNome: cliente?.empresa_nome || "Seu estabelecimento",
        clienteNome: cliente?.nome || "Cliente",
        respostas: respostasPdf,
        assinatura,
        hash,
        ip,
        data: dataAssinatura,
      });

      pdfUrl = await uploadPdfAnamnese(
        pdfBlob,
        cliente.nome || "cliente",
        anamnesePreenchida.id,
      );
    } catch (erroPdf) {
      console.warn(
        "Assinatura salva, mas houve erro ao gerar/upload do PDF:",
        erroPdf,
      );
    }

    const payloadCompleto: Record<string, any> = {
      assinatura,
      ip,
      hash,
      data_assinatura: dataAssinatura,
      aceita_termo: Boolean(
        modelo?.termo_responsabilidade ? aceitaTermo : true,
      ),
      pdf_url: pdfUrl || anamnesePreenchida?.pdf_url || null,
    };

    const payloadSemPdf: Record<string, any> = { ...payloadCompleto };
    delete payloadSemPdf.pdf_url;

    let error: any = null;

    for (const payload of [payloadCompleto, payloadSemPdf]) {
      const resultado = await supabase
        .from("anamneses_clientes")
        .update(payload)
        .eq("id", anamnesePreenchida.id);

      error = resultado.error;

      if (!error) break;

      const mensagemErro = String(error?.message || "").toLowerCase();
      const erroColuna =
        mensagemErro.includes("column") ||
        mensagemErro.includes("schema cache") ||
        mensagemErro.includes("could not find");

      if (!erroColuna) break;
    }

    if (error) {
      console.error("Erro ao salvar assinatura:", error);
      alert("Erro ao salvar assinatura: " + error.message);
      setSalvando(false);
      return;
    }

    alert("Assinatura salva com sucesso!");
    setAnamnesePreenchida({
      ...anamnesePreenchida,
      assinatura,
      ip,
      hash,
      data_assinatura: dataAssinatura,
      pdf_url: pdfUrl || anamnesePreenchida?.pdf_url || "",
    });
    setPdfAnamneseUrl(pdfUrl || anamnesePreenchida?.pdf_url || "");
    setAssinaturaComplementarObrigatoria(false);
    setModoAtualizacaoAnamnese(false);
    setModalAnamneseAberto(false);
    setAba("agenda");
    setAceitaTermo(false);
    setAssinatura("");
    setSalvando(false);
  }

  async function salvarAnamnese() {
    if (!cliente || !modelo) return;

    for (const campo of campos) {
      const resposta = String(respostas[campo.id] || "").trim();
      const justificativa = String(justificativas[campo.id] || "").trim();

      if (campo.obrigatorio && !resposta) {
        alert(`Preencha: ${campo.label}`);
        return;
      }

      if (
        campo.tipo === "sim_nao_justificativa" &&
        resposta === "Sim" &&
        !justificativa
      ) {
        alert(`Descreva os detalhes de: ${campo.label}`);
        return;
      }
    }

    if (modelo?.termo_responsabilidade && !aceitaTermo) {
      alert("Aceite o termo de responsabilidade.");
      return;
    }

    if (!assinatura) {
      alert("Assine a ficha antes de enviar.");
      return;
    }

    setSalvando(true);

    const dataAssinatura = new Date().toISOString();
    const ip = await buscarIpCliente();
    const respostasPdf = montarRespostasParaPdf();
    const hash = await gerarHash(
      JSON.stringify({
        cliente_id: cliente.id,
        cliente_nome: cliente.nome,
        modelo_id: modelo.id,
        respostas: respostasPdf,
        assinatura,
        ip,
        dataAssinatura,
      }),
    );

    const payloadCompleto: Record<string, any> = {
      cliente_id: cliente.id,
      cliente_nome: cliente.nome,
      empresa_id: empresaAnamneseId || cliente.empresa_id || null,
      modelo_id: modelo.id,
      preenchido: true,
      aceita_termo: Boolean(
        modelo?.termo_responsabilidade ? aceitaTermo : true,
      ),
      preenchido_em: dataAssinatura,
      assinatura,
      ip,
      hash,
      data_assinatura: dataAssinatura,
    };

    const payloadSemModelo: Record<string, any> = { ...payloadCompleto };
    delete payloadSemModelo.modelo_id;

    const payloadMinimo: Record<string, any> = {
      cliente_id: cliente.id,
      cliente_nome: cliente.nome,
      preenchido: true,
      aceita_termo: Boolean(
        modelo?.termo_responsabilidade ? aceitaTermo : true,
      ),
      preenchido_em: dataAssinatura,
      assinatura,
      ip,
      hash,
      data_assinatura: dataAssinatura,
    };

    let anamnese: any = null;
    let error: any = null;

    for (const payload of [payloadCompleto, payloadSemModelo, payloadMinimo]) {
      const resultado = await supabase
        .from("anamneses_clientes")
        .insert(payload)
        .select("id")
        .single();

      anamnese = resultado.data;
      error = resultado.error;

      if (!error && anamnese?.id) break;

      const mensagemErro = String(error?.message || "").toLowerCase();
      const erroColuna =
        mensagemErro.includes("column") ||
        mensagemErro.includes("schema cache") ||
        mensagemErro.includes("could not find");

      if (!erroColuna) break;
    }

    if (error || !anamnese) {
      console.error("Erro ao salvar anamnese:", error);
      alert(
        "Erro ao salvar anamnese: " +
          (error?.message || "registro não retornado"),
      );
      setSalvando(false);
      return;
    }

    const { error: erroRespostas } = await supabase
      .from("anamnese_respostas")
      .insert(
        campos.map((campo) => {
          const resposta = respostas[campo.id] || "";
          const justificativa = justificativas[campo.id] || "";

          return {
            anamnese_id: anamnese.id,
            cliente_id: cliente.id,
            campo_id: campo.id,
            resposta:
              campo.tipo === "sim_nao_justificativa" && resposta === "Sim"
                ? `Sim - ${justificativa}`
                : resposta,
          };
        }),
      );

    if (erroRespostas) {
      console.error("Erro ao salvar respostas:", erroRespostas);
      alert(
        "A ficha foi criada, mas houve erro ao salvar as respostas: " +
          erroRespostas.message,
      );
      setSalvando(false);
      return;
    }

    let pdfUrl = "";

    try {
      const pdfBlob = gerarPdfBlob({
        empresaNome: cliente?.empresa_nome || "Seu estabelecimento",
        clienteNome: cliente?.nome || "Cliente",
        respostas: respostasPdf,
        assinatura,
        hash,
        ip,
        data: dataAssinatura,
      });

      pdfUrl = await uploadPdfAnamnese(
        pdfBlob,
        cliente.nome || "cliente",
        anamnese.id,
      );

      const { error: erroPdfUrl } = await supabase
        .from("anamneses_clientes")
        .update({ pdf_url: pdfUrl })
        .eq("id", anamnese.id);

      if (erroPdfUrl) {
        console.warn(
          "PDF gerado, mas não foi possível salvar a URL no banco:",
          erroPdfUrl,
        );
      }
    } catch (erroPdf) {
      console.warn(
        "Anamnese salva, mas houve erro ao gerar/upload do PDF:",
        erroPdf,
      );
    }

    alert("Anamnese salva com sucesso!");
    setAnamnesePreenchida({
      id: anamnese.id,
      assinatura,
      ip,
      hash,
      data_assinatura: dataAssinatura,
      preenchido_em: dataAssinatura,
      pdf_url: pdfUrl,
    });
    setPdfAnamneseUrl(pdfUrl);
    setAnamneseObrigatoria(false);
    setAssinaturaComplementarObrigatoria(false);
    setModoAtualizacaoAnamnese(false);
    setModalAnamneseAberto(false);
    setAba("agenda");
    setRespostas({});
    setJustificativas({});
    setAceitaTermo(false);
    setAssinatura("");
    setSalvando(false);
  }

  function sair() {
    setCliente(null);
    setTelefone("");
    setMensagem("");
    setAba("agenda");
    setAnamneseObrigatoria(false);
    setAssinaturaComplementarObrigatoria(false);
    setModalAnamneseAberto(false);
    setAssinatura("");
    setAnamnesePreenchida(null);
    setPdfAnamneseUrl("");
    setNovoAgendamentoAberto(false);
    setAgendamentoReagendandoId(null);
    setServicoAgendamentoId("");
    setProfissionalAgendamentoId("");
    setHorarioAgendamento("");
    setValorAgendamentoFinal(null);
    setPrecoEspecialAplicado(false);
  }

  function renderizarCampo(campo: CampoAnamnese) {
    const estiloCampo = {
      width: "100%",
      padding: 14,
      borderRadius: isMobile ? 12 : 14,
      border: "1px solid #cbd5e1",
      marginTop: isMobile ? 5 : 8,
      boxSizing: "border-box" as const,
    };

    const valor = respostas[campo.id] || "";
    const opcoes = Array.isArray(campo.opcoes) ? campo.opcoes : [];

    if (campo.tipo === "sim_nao" || campo.tipo === "sim_nao_justificativa") {
      return (
        <>
          <select
            value={valor}
            onChange={(e) => alterarResposta(campo.id, e.target.value)}
            style={estiloCampo}
          >
            <option value="">Selecione</option>
            <option value="Não">Não</option>
            <option value="Sim">Sim</option>
          </select>

          {campo.tipo === "sim_nao_justificativa" && valor === "Sim" && (
            <textarea
              value={justificativas[campo.id] || ""}
              onChange={(e) => alterarJustificativa(campo.id, e.target.value)}
              placeholder={campo.placeholder || "Descreva os detalhes"}
              style={{
                ...estiloCampo,
                minHeight: 90,
                marginTop: 10,
                background: "#fff7ed",
                border: "1px solid #fdba74",
              }}
            />
          )}
        </>
      );
    }

    if (campo.tipo === "textarea") {
      return (
        <textarea
          value={valor}
          onChange={(e) => alterarResposta(campo.id, e.target.value)}
          placeholder={campo.placeholder || ""}
          style={{ ...estiloCampo, minHeight: 100 }}
        />
      );
    }

    if (campo.tipo === "select") {
      return (
        <select
          value={valor}
          onChange={(e) => alterarResposta(campo.id, e.target.value)}
          style={estiloCampo}
        >
          <option value="">Selecione</option>
       {opcoes.map((opcao: any) => (
            <option key={opcao} value={opcao}>
              {opcao}
            </option>
          ))}
        </select>
      );
    }

    if (campo.tipo === "checkbox") {
      return (
        <label
          style={{
            display: "flex",
            gap: 10,
            alignItems: "center",
            marginTop: 10,
            fontWeight: 700,
          }}
        >
          <input
            type="checkbox"
            checked={valor === "Sim"}
            onChange={(e) =>
              alterarResposta(campo.id, e.target.checked ? "Sim" : "Não")
            }
          />
          Sim
        </label>
      );
    }

    return (
      <input
        type={
          campo.tipo === "date" || campo.tipo === "number" ? campo.tipo : "text"
        }
        value={valor}
        onChange={(e) => alterarResposta(campo.id, e.target.value)}
        placeholder={campo.placeholder || ""}
        style={estiloCampo}
      />
    );
  }

  const formularioAssinaturaComplementar = (
    <div>
      <h2 style={{ marginTop: 0 }}>Assinatura da anamnese</h2>

      <div
        style={{
          background: "#fff7ed",
          border: "1px solid #fed7aa",
          color: "#9a3412",
          borderRadius: 18,
          padding: isMobile ? 12 : 18,
          marginBottom: 20,
          fontWeight: 800,
        }}
      >
        Sua ficha já está preenchida. Para finalizar e liberar o acesso
        completo, assine o termo abaixo.
      </div>

      {modelo?.termo_responsabilidade && (
        <div
          style={{
            background: "#f8fafc",
            border: "1px solid #e2e8f0",
            borderRadius: 18,
            padding: isMobile ? 12 : 18,
            marginTop: 20,
          }}
        >
          <strong>Termo de responsabilidade</strong>
          <p style={{ color: "#475569" }}>{modelo.termo_responsabilidade}</p>

          <label style={{ fontWeight: 800 }}>
            <input
              type="checkbox"
              checked={aceitaTermo}
              onChange={(e) => setAceitaTermo(e.target.checked)}
            />{" "}
            Li e aceito o termo.
          </label>
        </div>
      )}

      <div
        style={{
          background: "#f8fafc",
          border: "1px solid #e2e8f0",
          borderRadius: 18,
          padding: isMobile ? 12 : 18,
          marginTop: 20,
        }}
      >
        <strong>Assinatura do cliente *</strong>
        <p style={{ color: "#475569", marginTop: 6 }}>
          Assine abaixo para validar a ficha de anamnese já preenchida.
        </p>

        <AssinaturaCanvas onChange={setAssinatura} initialValue={assinatura} />
      </div>

      <button
        type="button"
        onClick={salvarAssinaturaComplementar}
        disabled={salvando}
        style={{
          marginTop: 22,
          padding: "15px 22px",
          borderRadius: 16,
          border: 0,
          background: "#282663",
          color: "#fff",
          fontWeight: 900,
          cursor: "pointer",
        }}
      >
        {salvando ? "Salvando..." : "Salvar assinatura"}
      </button>
    </div>
  );

  const formularioAnamnese = (
    <div>
      <h2 style={{ marginTop: 0 }}>{modelo?.titulo || "Anamnese"}</h2>

      {modelo?.descricao && (
        <p style={{ color: "#64748b" }}>{modelo.descricao}</p>
      )}

      {campos.map((campo) => (
        <div key={campo.id} style={{ marginBottom: 18 }}>
          <label style={{ fontWeight: 900 }}>
            {campo.label}
            {campo.obrigatorio ? " *" : ""}
          </label>

          {campo.ajuda && (
            <p style={{ margin: "6px 0 0", color: "#64748b", fontSize: 13 }}>
              {campo.ajuda}
            </p>
          )}

          {renderizarCampo(campo)}
        </div>
      ))}

      {modelo?.termo_responsabilidade && (
        <div
          style={{
            background: "#f8fafc",
            border: "1px solid #e2e8f0",
            borderRadius: 18,
            padding: isMobile ? 12 : 18,
            marginTop: 20,
          }}
        >
          <strong>Termo de responsabilidade</strong>
          <p style={{ color: "#475569" }}>{modelo.termo_responsabilidade}</p>

          <label style={{ fontWeight: 800 }}>
            <input
              type="checkbox"
              checked={aceitaTermo}
              onChange={(e) => setAceitaTermo(e.target.checked)}
            />{" "}
            Li e aceito o termo.
          </label>
        </div>
      )}

      <div
        style={{
          background: "#f8fafc",
          border: "1px solid #e2e8f0",
          borderRadius: 18,
          padding: isMobile ? 12 : 18,
          marginTop: 20,
        }}
      >
        <strong>Assinatura do cliente *</strong>
        <p style={{ color: "#475569", marginTop: 6 }}>
          Assine abaixo para validar a ficha de anamnese.
        </p>

        <AssinaturaCanvas onChange={setAssinatura} initialValue={assinatura} />
      </div>

      <button
        type="button"
        onClick={salvarAnamnese}
        disabled={salvando}
        style={{
          marginTop: 22,
          padding: "15px 22px",
          borderRadius: 16,
          border: 0,
          background: "#282663",
          color: "#fff",
          fontWeight: 900,
          cursor: "pointer",
        }}
      >
        {salvando
          ? "Salvando..."
          : modoAtualizacaoAnamnese
            ? "Salvar atualização da anamnese"
            : "Enviar anamnese"}
      </button>

      {modoAtualizacaoAnamnese && (
        <button
          type="button"
          onClick={cancelarAtualizacaoAnamnese}
          disabled={salvando}
          style={{
            marginTop: 12,
            marginLeft: 10,
            padding: "15px 22px",
            borderRadius: 16,
            border: "1px solid #cbd5e1",
            background: "#fff",
            color: "#334155",
            fontWeight: 900,
            cursor: "pointer",
          }}
        >
          Cancelar atualização
        </button>
      )}
    </div>
  );

const botaoAba = (valor: string, label: string) => {
    const abaBloqueada = acessoBloqueadoPorAnamnese && valor !== "anamnese";

    return (
      <button
        type="button"
        onClick={() => {
          if (abaBloqueada) {
            levarParaAnamneseObrigatoria();
            return;
          }

          setAba(valor);
        }}
        disabled={abaBloqueada}
        title={
          abaBloqueada
            ? assinaturaComplementarObrigatoria
              ? "Assine a anamnese para liberar esta área."
              : "Preencha a anamnese para liberar esta área."
            : undefined
        }
        style={{
          border: aba === valor ? "2px solid #282663" : "1px solid #cbd5e1",
          background: aba === valor ? "#282663" : "#fff",
          color: aba === valor ? "#fff" : "#282663",
          padding: isMobile ? "9px 12px" : "13px 18px",
          borderRadius: isMobile ? 999 : 16,
          fontWeight: 900,
          fontSize: isMobile ? 12 : 14,
          whiteSpace: "nowrap",
          flex: isMobile ? "0 0 auto" : undefined,
          boxShadow: aba === valor ? "0 10px 20px rgba(40,38,99,.18)" : "0 6px 14px rgba(15,23,42,.06)",
          cursor: abaBloqueada ? "not-allowed" : "pointer",
          opacity: abaBloqueada ? 0.55 : 1,
        }}
      >
        {label}
      </button>
    );
  };

  if (!cliente) {
    return (
      <div
        style={{
          minHeight: "100vh",
          background: "linear-gradient(135deg, #eef3fb, #dbe7f7)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          padding: isMobile ? 12 : 24,
        }}
      >
        <div
          style={{
            width: "100%",
            maxWidth: 520,
            background: "#fff",
            borderRadius: isMobile ? 20 : 28,
            padding: isMobile ? 14 : 36,
            boxShadow: "0 24px 60px rgba(15,23,42,.16)",
            maxHeight: "calc(100vh - 48px)",
            overflowY: "auto",
          }}
        >
          <h1 style={{ margin: 0, color: "#0f172a", fontSize: isMobile ? 22 : 30 }}>
            Meu Espaço
          </h1>

          <p style={{ color: "#64748b", lineHeight: 1.5 }}>
            Acesse seus agendamentos, dados pessoais, anamnese e histórico.
          </p>

          {!modoCadastro ? (
            <>
              <label style={{ fontWeight: 800 }}>Telefone</label>

              <input
                value={telefone}
                onChange={(e) => setTelefone(e.target.value)}
                placeholder="Ex: 11999999999"
                style={{
                  width: "100%",
                  padding: isMobile ? "11px 12px" : "15px 16px",
                  borderRadius: 16,
                  border: "1px solid #cbd5e1",
                  marginTop: isMobile ? 5 : 8,
                  fontSize: isMobile ? 14 : 16,
                  boxSizing: "border-box",
                }}
              />

              {mensagem && (
                <div
                  style={{
                    background: "#fee2e2",
                    color: "#991b1b",
                    borderRadius: isMobile ? 12 : 14,
                    padding: isMobile ? 10 : 12,
                    marginTop: 14,
                  }}
                >
                  {mensagem}
                </div>
              )}

              <button
                type="button"
                onClick={entrarPorTelefone}
                disabled={carregando}
                style={{
                  width: "100%",
                  marginTop: 18,
                  padding: isMobile ? 12 : 15,
                  borderRadius: 16,
                  border: 0,
                  background: "#282663",
                  color: "#fff",
                  fontWeight: 900,
                  fontSize: isMobile ? 14 : 16,
                  cursor: "pointer",
                }}
              >
                {carregando ? "Entrando..." : "Entrar"}
              </button>

              <button
                type="button"
                onClick={() => {
                  setMensagem("");
                  setCadastro((atual) => ({ ...atual, telefone }));
                  setModoCadastro(true);
                }}
                style={{
                  width: "100%",
                  marginTop: 12,
                  padding: 14,
                  borderRadius: 16,
                  border: "1px solid #282663",
                  background: "#fff",
                  color: "#282663",
                  fontWeight: 900,
                  fontSize: 15,
                  cursor: "pointer",
                }}
              >
                Primeiro acesso? Cadastre-se
              </button>
            </>
          ) : (
            <>
              <h2
                style={{ margin: "18px 0 8px", color: "#0f172a", fontSize: 22 }}
              >
                Criar cadastro
              </h2>

              <p style={{ color: "#64748b", lineHeight: 1.5, marginTop: 0 }}>
                Preencha seus dados para acessar o Meu Espaço e realizar
                agendamentos.
              </p>

              <label style={{ fontWeight: 800 }}>Nome completo *</label>
              <input
                value={cadastro.nome}
                onChange={(e) =>
                  setCadastro({ ...cadastro, nome: e.target.value })
                }
                placeholder="Seu nome completo"
                style={{
                  width: "100%",
                  padding: isMobile ? "11px 12px" : "15px 16px",
                  borderRadius: 16,
                  border: "1px solid #cbd5e1",
                  marginTop: isMobile ? 5 : 8,
                  marginBottom: 12,
                  fontSize: isMobile ? 14 : 16,
                  boxSizing: "border-box",
                }}
              />

              <label style={{ fontWeight: 800 }}>Telefone *</label>
              <input
                value={cadastro.telefone}
                onChange={(e) =>
                  setCadastro({ ...cadastro, telefone: e.target.value })
                }
                placeholder="Ex: 11999999999"
                style={{
                  width: "100%",
                  padding: isMobile ? "11px 12px" : "15px 16px",
                  borderRadius: 16,
                  border: "1px solid #cbd5e1",
                  marginTop: isMobile ? 5 : 8,
                  marginBottom: 12,
                  fontSize: isMobile ? 14 : 16,
                  boxSizing: "border-box",
                }}
              />

              <label style={{ fontWeight: 800 }}>E-mail</label>
              <input
                value={cadastro.email}
                onChange={(e) =>
                  setCadastro({ ...cadastro, email: e.target.value })
                }
                placeholder="seuemail@exemplo.com"
                style={{
                  width: "100%",
                  padding: isMobile ? "11px 12px" : "15px 16px",
                  borderRadius: 16,
                  border: "1px solid #cbd5e1",
                  marginTop: isMobile ? 5 : 8,
                  marginBottom: 12,
                  fontSize: isMobile ? 14 : 16,
                  boxSizing: "border-box",
                }}
              />

              <label style={{ fontWeight: 800 }}>Data de nascimento</label>
              <input
                type="date"
                value={cadastro.data_nascimento}
                onChange={(e) =>
                  setCadastro({ ...cadastro, data_nascimento: e.target.value })
                }
                style={{
                  width: "100%",
                  padding: isMobile ? "11px 12px" : "15px 16px",
                  borderRadius: 16,
                  border: "1px solid #cbd5e1",
                  marginTop: isMobile ? 5 : 8,
                  marginBottom: 12,
                  fontSize: isMobile ? 14 : 16,
                  boxSizing: "border-box",
                }}
              />

              <label style={{ fontWeight: 800 }}>CEP</label>
              <input
                value={cadastro.cep}
                onChange={(e) => buscarCepCadastro(e.target.value)}
                placeholder="Ex: 05888160"
                style={{
                  width: "100%",
                  padding: isMobile ? "11px 12px" : "15px 16px",
                  borderRadius: 16,
                  border: "1px solid #cbd5e1",
                  marginTop: isMobile ? 5 : 8,
                  marginBottom: 8,
                  fontSize: isMobile ? 14 : 16,
                  boxSizing: "border-box",
                }}
              />

              {buscandoCep && (
                <p
                  style={{ color: "#64748b", margin: "0 0 12px", fontSize: 13 }}
                >
                  Buscando endereço pelo CEP...
                </p>
              )}

              <label style={{ fontWeight: 800 }}>Endereço</label>
              <input
                value={cadastro.endereco}
                onChange={(e) =>
                  setCadastro({ ...cadastro, endereco: e.target.value })
                }
                placeholder="Rua, avenida..."
                style={{
                  width: "100%",
                  padding: isMobile ? "11px 12px" : "15px 16px",
                  borderRadius: 16,
                  border: "1px solid #cbd5e1",
                  marginTop: isMobile ? 5 : 8,
                  marginBottom: 12,
                  fontSize: isMobile ? 14 : 16,
                  boxSizing: "border-box",
                }}
              />

              <div
                style={{
                  display: "grid",
                  gridTemplateColumns: "1fr 1fr",
                  gap: 12,
                }}
              >
                <div>
                  <label style={{ fontWeight: 800 }}>Número</label>
                  <input
                    value={cadastro.numero}
                    onChange={(e) =>
                      setCadastro({ ...cadastro, numero: e.target.value })
                    }
                    placeholder="Número"
                    style={{
                      width: "100%",
                      padding: isMobile ? "11px 12px" : "15px 16px",
                      borderRadius: 16,
                      border: "1px solid #cbd5e1",
                      marginTop: isMobile ? 5 : 8,
                      marginBottom: 12,
                      fontSize: isMobile ? 14 : 16,
                      boxSizing: "border-box",
                    }}
                  />
                </div>

                <div>
                  <label style={{ fontWeight: 800 }}>Bairro</label>
                  <input
                    value={cadastro.bairro}
                    onChange={(e) =>
                      setCadastro({ ...cadastro, bairro: e.target.value })
                    }
                    placeholder="Bairro"
                    style={{
                      width: "100%",
                      padding: isMobile ? "11px 12px" : "15px 16px",
                      borderRadius: 16,
                      border: "1px solid #cbd5e1",
                      marginTop: isMobile ? 5 : 8,
                      marginBottom: 12,
                      fontSize: isMobile ? 14 : 16,
                      boxSizing: "border-box",
                    }}
                  />
                </div>
              </div>

              <div
                style={{
                  display: "grid",
                  gridTemplateColumns: "1fr 110px",
                  gap: 12,
                }}
              >
                <div>
                  <label style={{ fontWeight: 800 }}>Cidade</label>
                  <input
                    value={cadastro.cidade}
                    onChange={(e) =>
                      setCadastro({ ...cadastro, cidade: e.target.value })
                    }
                    placeholder="Cidade"
                    style={{
                      width: "100%",
                      padding: isMobile ? "11px 12px" : "15px 16px",
                      borderRadius: 16,
                      border: "1px solid #cbd5e1",
                      marginTop: isMobile ? 5 : 8,
                      marginBottom: 12,
                      fontSize: isMobile ? 14 : 16,
                      boxSizing: "border-box",
                    }}
                  />
                </div>

                <div>
                  <label style={{ fontWeight: 800 }}>UF</label>
                  <input
                    value={cadastro.estado}
                    onChange={(e) =>
                      setCadastro({
                        ...cadastro,
                        estado: e.target.value.toUpperCase(),
                      })
                    }
                    placeholder="SP"
                    maxLength={2}
                    style={{
                      width: "100%",
                      padding: isMobile ? "11px 12px" : "15px 16px",
                      borderRadius: 16,
                      border: "1px solid #cbd5e1",
                      marginTop: isMobile ? 5 : 8,
                      marginBottom: 12,
                      fontSize: isMobile ? 14 : 16,
                      boxSizing: "border-box",
                    }}
                  />
                </div>
              </div>

              {mensagem && (
                <div
                  style={{
                    background: "#fee2e2",
                    color: "#991b1b",
                    borderRadius: isMobile ? 12 : 14,
                    padding: isMobile ? 10 : 12,
                    marginTop: 14,
                  }}
                >
                  {mensagem}
                </div>
              )}

              <button
                type="button"
                onClick={cadastrarClienteMeuEspaco}
                disabled={cadastrando}
                style={{
                  width: "100%",
                  marginTop: 18,
                  padding: isMobile ? 12 : 15,
                  borderRadius: 16,
                  border: 0,
                  background: "#282663",
                  color: "#fff",
                  fontWeight: 900,
                  fontSize: isMobile ? 14 : 16,
                  cursor: "pointer",
                }}
              >
                {cadastrando ? "Cadastrando..." : "Cadastrar e entrar"}
              </button>

              <button
                type="button"
                onClick={() => {
                  setMensagem("");
                  setModoCadastro(false);
                }}
                style={{
                  width: "100%",
                  marginTop: 12,
                  padding: 14,
                  borderRadius: 16,
                  border: "1px solid #cbd5e1",
                  background: "#fff",
                  color: "#334155",
                  fontWeight: 900,
                  fontSize: 15,
                  cursor: "pointer",
                }}
              >
                Já tenho cadastro
              </button>
            </>
          )}
        </div>
      </div>
    );
  }

  const navInferior = isMobile && !anamneseObrigatoria && !assinaturaComplementarObrigatoria;

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "linear-gradient(180deg, #eef3fb 0%, #f8fafc 45%, #ffffff 100%)",
        padding: isMobile ? "10px 10px 92px" : 28,
      }}
    >
      <div style={{ maxWidth: 1160, margin: "0 auto" }}>
        <div
          style={{
            background: "#282663",
            color: "#fff",
            borderRadius: isMobile ? 22 : 24,
            padding: isMobile ? 14 : 24,
            marginBottom: isMobile ? 12 : 24,
            display: "flex",
            flexDirection: isMobile ? "column" : "row",
            gap: isMobile ? 10 : 0,
            justifyContent: "space-between",
            alignItems: isMobile ? "stretch" : "center",
          }}
        >
          <div>
            <p style={{ margin: 0, opacity: 0.82, fontWeight: 800, fontSize: isMobile ? 12 : 14 }}>
              Meu Espaço
            </p>
            <h1 style={{ margin: "3px 0 0", fontSize: isMobile ? 21 : 30, lineHeight: 1.15 }}>
              Olá, {primeiroNome(cliente.nome)}
            </h1>
          </div>

          <button
            type="button"
            onClick={sair}
            style={{
              background: "#fff",
              color: "#282663",
              border: 0,
              borderRadius: 999,
              padding: isMobile ? "10px 14px" : "12px 16px",
              width: isMobile ? "100%" : undefined,
              fontWeight: 900,
              cursor: "pointer",
            }}
          >
            Sair
          </button>
        </div>

       {/* BANNER PROMOCIONAL */}
        {!anamneseObrigatoria &&
          !assinaturaComplementarObrigatoria &&
          configuracoes?.banner_cliente_ativo !== false && (
            <div
              style={{
                position: "relative",
                borderRadius: isMobile ? 18 : 24,
                overflow: "hidden",
                marginBottom: isMobile ? 12 : 20,
                boxShadow: "0 14px 35px rgba(15,23,42,.16)",
                minHeight: isMobile ? 170 : 180,
                display: "flex",
                alignItems: "center",
              }}
            >
              <img
                src={
                  configuracoes?.banner_cliente_imagem_url ||
                  "https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&w=1400&q=80"
                }
                alt={configuracoes?.banner_cliente_titulo || "Banner do Meu Espaço"}
                style={{
                  position: "absolute",
                  inset: 0,
                  width: "100%",
                  height: "100%",
                  objectFit: "cover",
                  objectPosition: `${configuracoes?.banner_cliente_pos_x ?? 50}% ${
                    configuracoes?.banner_cliente_pos_y ?? 50
                  }%`,
                  transform: `scale(${
                    Number(configuracoes?.banner_cliente_zoom ?? 100) / 100
                  })`,
                  transformOrigin: `${configuracoes?.banner_cliente_pos_x ?? 50}% ${
                    configuracoes?.banner_cliente_pos_y ?? 50
                  }%`,
                }}
              />

              <div
                style={{
                  position: "absolute",
                  inset: 0,
                  background:
                    "linear-gradient(90deg, rgba(15,23,42,.88) 0%, rgba(15,23,42,.38) 100%)",
                }}
              />

              <div
                style={{
                  position: "relative",
                  zIndex: 2,
                  padding: isMobile ? 16 : 24,
                  maxWidth: 560,
                  color: "#fff",
                }}
              >
                <p
                  style={{
                    margin: 0,
                    fontSize: 12,
                    fontWeight: 800,
                    opacity: 0.9,
                    textTransform: "uppercase",
                    letterSpacing: 1,
                  }}
                >
                  {configuracoes?.banner_cliente_categoria || "Novidade"}
                </p>

                <h2
                  style={{
                    margin: "10px 0",
                    fontSize: isMobile ? 22 : 30,
                    lineHeight: 1.1,
                    fontWeight: 900,
                  }}
                >
                  {configuracoes?.banner_cliente_titulo ||
                    "Bem-vinda ao Meu Espaço"}
                </h2>

                <p
                  style={{
                    margin: 0,
                    fontSize: isMobile ? 14 : 17,
                    opacity: 0.95,
                    lineHeight: 1.5,
                  }}
                >
                  {configuracoes?.banner_cliente_texto ||
                    "Acompanhe novidades, promoções e dicas exclusivas."}
                </p>

                {(configuracoes?.banner_cliente_botao_texto ||
                  configuracoes?.banner_cliente_botao_link) && (
                  <button
                    type="button"
                    onClick={() => {
                      const link = configuracoes?.banner_cliente_botao_link;

                      if (link) {
                        window.open(link, "_blank");
                      }
                    }}
                    style={{
                      marginTop: 20,
                      background: "#fff",
                      color: "#111827",
                      border: "none",
                      borderRadius: 14,
                      padding: isMobile ? "11px 16px" : "14px 20px",
                      fontWeight: 900,
                      fontSize: 15,
                      cursor: configuracoes?.banner_cliente_botao_link
                        ? "pointer"
                        : "default",
                      boxShadow: "0 8px 20px rgba(0,0,0,.18)",
                    }}
                  >
                    {configuracoes?.banner_cliente_botao_texto || "Saiba mais"}
                  </button>
                )}
              </div>
            </div>
          )}

        {anamneseObrigatoria || assinaturaComplementarObrigatoria ? (
          <div
            style={{
              background: "#fff7ed",
              border: "1px solid #fed7aa",
              color: "#9a3412",
              padding: isMobile ? 12 : 18,
              borderRadius: isMobile ? 16 : 20,
              marginBottom: 20,
              fontWeight: 800,
            }}
          >
            {assinaturaComplementarObrigatoria
              ? "Sua ficha já está preenchida. Assine para liberar o acesso completo."
              : "Sua anamnese está pendente. Preencha para liberar o acesso completo."}
          </div>
        ) : (
          <div
            style={{
              display: navInferior ? "none" : "flex",
              gap: 10,
              marginBottom: isMobile ? 16 : 22,
              flexWrap: isMobile ? "nowrap" : "wrap",
              overflowX: isMobile ? "auto" : undefined,
              paddingBottom: isMobile ? 6 : 0,
              WebkitOverflowScrolling: "touch",
            }}
          >
            {botaoAba("agenda", "Agendamentos")}
{botaoAba("dados", "Dados pessoais")}
{botaoAba("anamnese", "Anamnese")}
{botaoAba("historico", "Histórico")}
{botaoAba("pacotes", "Pacotes")}
          </div>
        )}

        {(anamneseObrigatoria || assinaturaComplementarObrigatoria) &&
          modalAnamneseAberto && (
            <div
              style={{
                position: "fixed",
                inset: 0,
                background: "rgba(15,23,42,.65)",
                zIndex: 50,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                padding: isMobile ? 10 : 18,
              }}
            >
              <div
                style={{
                  width: "100%",
                  maxWidth: 780,
                  maxHeight: "90vh",
                  overflowY: "auto",
                  background: "#fff",
                  borderRadius: isMobile ? 20 : 28,
                  padding: isMobile ? 16 : 28,
                  boxShadow: "0 30px 80px rgba(0,0,0,.28)",
                }}
              >
                <div
                  style={{
                    background: "#fff7ed",
                    border: "1px solid #fed7aa",
                    color: "#9a3412",
                    padding: 14,
                    borderRadius: 16,
                    marginBottom: 20,
                    fontWeight: 800,
                  }}
                >
                  {assinaturaComplementarObrigatoria
                    ? "Para continuar no Meu Espaço, assine a ficha já preenchida."
                    : "Para continuar no Meu Espaço, preencha a ficha obrigatória abaixo."}
                </div>

                {assinaturaComplementarObrigatoria
                  ? formularioAssinaturaComplementar
                  : formularioAnamnese}
              </div>
            </div>
          )}

        <div
          style={{
            background: "#fff",
            borderRadius: isMobile ? 22 : 26,
            padding: isMobile ? 13 : 28,
            boxShadow: "0 14px 35px rgba(15,23,42,.08)",
            border: isMobile ? "1px solid #e2e8f0" : undefined,
          }}
        >
          {aba === "agenda" &&
            !anamneseObrigatoria &&
            !assinaturaComplementarObrigatoria && (
              <div>
                <div
                  style={{
                    display: "flex",
                    flexDirection: isMobile ? "column" : "row",
                    justifyContent: "space-between",
                    gap: 12,
                    alignItems: isMobile ? "stretch" : "center",
                    marginBottom: 18,
                  }}
                >
                  <div>
                    <h2 style={{ margin: 0 }}>Agendamentos</h2>
                    <p style={{ color: "#64748b", margin: "6px 0 0" }}>
                      Escolha um serviço, profissional e um horário livre para
                      agendar.
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      if (acessoBloqueadoPorAnamnese) {
                        levarParaAnamneseObrigatoria();
                        return;
                      }

                      if (novoAgendamentoAberto && !agendamentoReagendandoId) {
                        setNovoAgendamentoAberto(false);
                        return;
                      }

                      limparFormularioAgendamento();
                      setNovoAgendamentoAberto(true);
                    }}
                    disabled={acessoBloqueadoPorAnamnese}
                    style={{
                      padding: isMobile ? "11px 14px" : "13px 18px",
                      width: isMobile ? "100%" : undefined,
                      borderRadius: 999,
                      border: 0,
                      background: "#282663",
                      color: "#fff",
                      fontWeight: 900,
                      cursor: "pointer",
                    }}
                  >
                    {novoAgendamentoAberto && !agendamentoReagendandoId
                      ? "Fechar"
                      : "+ Novo agendamento"}
                  </button>
                </div>

                {novoAgendamentoAberto && (
                  <div
                    style={{
                      background: "#f8fafc",
                      border: "1px solid #e2e8f0",
                      borderRadius: isMobile ? 18 : 22,
                      padding: isMobile ? 12 : 20,
                      marginBottom: isMobile ? 16 : 22,
                    }}
                  >
                    <h3 style={{ marginTop: 0 }}>
                      {agendamentoReagendandoId
                        ? "Reagendar agendamento"
                        : "Novo agendamento"}
                    </h3>

                    <div
                      style={{
                        display: "grid",
                        gridTemplateColumns: isMobile
                          ? "1fr"
                          : "repeat(auto-fit, minmax(220px, 1fr))",
                        gap: isMobile ? 10 : 14,
                      }}
                    >
                      <div>
                        <label style={{ fontWeight: 800 }}>Serviço *</label>
                        <select
                          value={servicoAgendamentoId}
                          onChange={(e) => {
                            setServicoAgendamentoId(e.target.value);
                            setHorarioAgendamento("");
                          }}
                          style={{
                            width: "100%",
                            padding: isMobile ? 9 : 14,
                            borderRadius: isMobile ? 12 : 14,
                            border: "1px solid #cbd5e1",
                            marginTop: isMobile ? 5 : 8,
                          }}
                        >
                          <option value="">Selecione</option>
                          {servicos.map((servico) => (
                            <option key={servico.id} value={servico.id}>
                              {servico.nome} -{" "}
                              {formatarMoeda(precoBaseServico(servico))} -{" "}
                              {servico.duracao_padrao_minutos ||
                                servico.duracao ||
                                60}{" "}
                              min
                            </option>
                          ))}
                        </select>

                        {servicos.length === 0 && (
                          <p
                            style={{
                              marginTop: isMobile ? 5 : 8,
                              color: "#b45309",
                              fontWeight: 800,
                              fontSize: isMobile ? 11 : 12,
                            }}
                          >
                            Nenhum serviço disponível para esta empresa. Verifique
                            o cadastro de serviços ou as permissões/RLS em produção.
                          </p>
                        )}

                        {servicoAgendamentoId && (
                          <div
                            style={{
                              marginTop: 10,
                              background: precoEspecialAplicado
                                ? "#dcfce7"
                                : "#fff",
                              border: precoEspecialAplicado
                                ? "1px solid #bbf7d0"
                                : "1px solid #e2e8f0",
                              color: precoEspecialAplicado
                                ? "#166534"
                                : "#0f172a",
                              borderRadius: isMobile ? 12 : 14,
                              padding: isMobile ? 10 : 12,
                              fontWeight: 900,
                            }}
                          >
                            {carregandoValorAgendamento
                              ? "Calculando valor..."
                              : `Valor: ${formatarMoeda(valorAgendamentoFinal)}`}
                            {precoEspecialAplicado && (
                              <span style={{ display: "block", fontSize: isMobile ? 11 : 12 }}>
                                Preço especial deste cliente aplicado.
                              </span>
                            )}
                          </div>
                        )}
                      </div>

                      <div>
                        <label style={{ fontWeight: 800 }}>
                          Profissional *
                        </label>
                        <select
                          value={profissionalAgendamentoId}
                          onChange={(e) =>
                            setProfissionalAgendamentoId(e.target.value)
                          }
                          style={{
                            width: "100%",
                            padding: isMobile ? 9 : 14,
                            borderRadius: isMobile ? 12 : 14,
                            border: "1px solid #cbd5e1",
                            marginTop: isMobile ? 5 : 8,
                          }}
                        >
                          <option value="">Selecione</option>
                          {profissionais.map((profissional) => (
                            <option
                              key={profissional.id}
                              value={profissional.id}
                            >
                              {profissional.nome}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label style={{ fontWeight: 800 }}>Data *</label>
                        <input
                          type="date"
                          value={dataAgendamento}
                          min={hojeISO()}
                          onChange={(e) => setDataAgendamento(e.target.value)}
                          style={{
                            width: "100%",
                            padding: isMobile ? 9 : 14,
                            borderRadius: isMobile ? 12 : 14,
                            border: "1px solid #cbd5e1",
                            marginTop: isMobile ? 5 : 8,
                            boxSizing: "border-box",
                          }}
                        />
                      </div>
                    </div>

                    <div style={{ marginTop: 18 }}>
                      <label style={{ fontWeight: 800 }}>
                        Horários livres *
                      </label>

                      {carregandoHorarios && (
                        <p style={{ color: "#64748b" }}>
                          Buscando horários livres...
                        </p>
                      )}

                      {!carregandoHorarios &&
                        servicoAgendamentoId &&
                        profissionalAgendamentoId &&
                        dataAgendamento &&
                        horariosLivres.length === 0 && (
                          <div
                            style={{
                              background: "#fee2e2",
                              color: "#991b1b",
                              border: "1px solid #fecaca",
                              borderRadius: isMobile ? 12 : 14,
                              padding: isMobile ? 10 : 12,
                              marginTop: 10,
                              fontWeight: 800,
                            }}
                          >
                            Não há horários livres para esse serviço nessa data.
                            Escolha outra data ou outro profissional.
                          </div>
                        )}

                      <div
                        style={{
                          display: "flex",
                          gap: 10,
                          flexWrap: "wrap",
                          marginTop: 10,
                        }}
                      >
                        {horariosLivres.map((horario) => (
                          <button
                            key={horario}
                            type="button"
                            onClick={() => setHorarioAgendamento(horario)}
                            style={{
                              padding: "11px 14px",
                              borderRadius: isMobile ? 12 : 14,
                              border:
                                horarioAgendamento === horario
                                  ? "2px solid #282663"
                                  : "1px solid #cbd5e1",
                              background:
                                horarioAgendamento === horario
                                  ? "#282663"
                                  : "#fff",
                              color:
                                horarioAgendamento === horario
                                  ? "#fff"
                                  : "#0f172a",
                              fontWeight: 900,
                              cursor: "pointer",
                            }}
                          >
                            {horario}
                          </button>
                        ))}
                      </div>
                    </div>

                    {servicoAgendamentoId && horarioAgendamento && (
                      <div
                        style={{
                          marginTop: 18,
                          background: "#f0f9ff",
                          border: "1px solid #bae6fd",
                          color: "#075985",
                          borderRadius: 16,
                          padding: 14,
                          fontWeight: 800,
                        }}
                      >
                        Resumo: {pegarServicoSelecionado()?.nome} em{" "}
                        {formatarData(dataAgendamento)} às {horarioAgendamento}.
                        <br />
                        Valor do lançamento financeiro:{" "}
                        {formatarMoeda(valorAgendamentoFinal)}
                        {precoEspecialAplicado
                          ? " (preço especial aplicado)"
                          : ""}
                        .
                      </div>
                    )}

                    <button
                      type="button"
                      onClick={salvarNovoAgendamentoCliente}
                      disabled={salvandoAgendamento}
                      style={{
                        marginTop: 20,
                        padding: "14px 20px",
                        borderRadius: 16,
                        border: 0,
                        background: "#282663",
                        color: "#fff",
                        fontWeight: 900,
                        cursor: "pointer",
                      }}
                    >
                      {salvandoAgendamento
                        ? agendamentoReagendandoId
                          ? "Reagendando..."
                          : "Agendando..."
                        : agendamentoReagendandoId
                          ? "Confirmar reagendamento"
                          : "Confirmar agendamento"}
                    </button>
                  </div>
                )}

                {agendamentos.length === 0 && (
                  <p style={{ color: "#64748b" }}>
                    Nenhum agendamento em aberto.
                  </p>
                )}

                {agendamentos.map((a) => {
                  const status = String(a.status || "").toLowerCase();
                  const podeAlterar = !["cancelado", "finalizado"].includes(status);
                  const jaConfirmado = status === "confirmado";

                  return (
                    <div
                      key={a.id}
                      style={{
                        border: "1px solid #e2e8f0",
                        borderRadius: 18,
                        padding: isMobile ? 12 : 18,
                        marginBottom: 14,
                      }}
                    >
                      <strong>{a.servico || a.servico_nome}</strong>
                      <div>
                        {formatarData(a.data)} às {a.horario}
                      </div>
                      <div>Status: {a.status}</div>

                      {podeAlterar && (
                        <div
                          style={{
                            display: "flex",
                            gap: 10,
                            flexWrap: "wrap",
                            marginTop: 14,
                          }}
                        >
                          <button
                            type="button"
                            onClick={() => confirmarAgendamentoCliente(a)}
                            disabled={jaConfirmado}
                            style={{
                              padding: "11px 14px",
                              borderRadius: isMobile ? 12 : 14,
                              border: 0,
                              background: jaConfirmado ? "#dcfce7" : "#16a34a",
                              color: jaConfirmado ? "#166534" : "#fff",
                              fontWeight: 900,
                              cursor: jaConfirmado ? "default" : "pointer",
                            }}
                          >
                            {jaConfirmado ? "Confirmado" : "Confirmar"}
                          </button>

                          <button
                            type="button"
                            onClick={() => iniciarReagendamentoCliente(a)}
                            style={{
                              padding: "11px 14px",
                              borderRadius: isMobile ? 12 : 14,
                              border: "1px solid #282663",
                              background: "#fff",
                              color: "#282663",
                              fontWeight: 900,
                              cursor: "pointer",
                            }}
                          >
                            Reagendar
                          </button>

                          <button
                            type="button"
                            onClick={() => cancelarAgendamentoCliente(a)}
                            style={{
                              padding: "11px 14px",
                              borderRadius: isMobile ? 12 : 14,
                              border: "1px solid #fecaca",
                              background: "#fee2e2",
                              color: "#991b1b",
                              fontWeight: 900,
                              cursor: "pointer",
                            }}
                          >
                            Cancelar
                          </button>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}

          {aba === "dados" &&
            !anamneseObrigatoria &&
            !assinaturaComplementarObrigatoria && (
              <div>
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    gap: 18,
                    alignItems: "center",
                    marginBottom: 22,
                    flexWrap: "wrap",
                  }}
                >
                  <div
                    style={{ display: "flex", gap: 16, alignItems: "center" }}
                  >
                    <div
                      style={{
                        width: 64,
                        height: 64,
                        borderRadius: isMobile ? 18 : 22,
                        background: "linear-gradient(135deg, #282663, #5b5bd6)",
                        color: "#fff",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        fontSize: 26,
                        fontWeight: 900,
                        boxShadow: "0 14px 30px rgba(40,38,99,.22)",
                      }}
                    >
                      {String(cliente.nome || "C")
                        .slice(0, 1)
                        .toUpperCase()}
                    </div>

                    <div>
                      <p
                        style={{
                          margin: 0,
                          color: "#64748b",
                          fontWeight: 800,
                          textTransform: "uppercase",
                          fontSize: isMobile ? 11 : 12,
                          letterSpacing: 0.6,
                        }}
                      >
                        Perfil do cliente
                      </p>
                      <h2 style={{ margin: "4px 0 0", color: "#0f172a" }}>
                        {cliente.nome}
                      </h2>
                    </div>
                  </div>

                  <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
                    <div
                      style={{
                        background:
                          anamnesePreenchida &&
                          !anamneseEstaVencida(anamnesePreenchida)
                            ? "#dcfce7"
                            : "#fff7ed",
                        color:
                          anamnesePreenchida &&
                          !anamneseEstaVencida(anamnesePreenchida)
                            ? "#166534"
                            : "#9a3412",
                        border:
                          anamnesePreenchida &&
                          !anamneseEstaVencida(anamnesePreenchida)
                            ? "1px solid #bbf7d0"
                            : "1px solid #fed7aa",
                        borderRadius: 999,
                        padding: "10px 14px",
                        fontWeight: 900,
                      }}
                    >
                      {anamnesePreenchida &&
                      !anamneseEstaVencida(anamnesePreenchida)
                        ? "Anamnese em dia"
                        : "Anamnese pendente"}
                    </div>

                    {!editandoDados && (
                      <button
                        type="button"
                        onClick={iniciarEdicaoDados}
                        style={{
                          padding: isMobile ? "9px 12px" : "12px 16px",
                          borderRadius: isMobile ? 12 : 14,
                          border: "1px solid #282663",
                          background: "#fff",
                          color: "#282663",
                          fontWeight: 900,
                          cursor: "pointer",
                        }}
                      >
                        Editar dados
                      </button>
                    )}
                  </div>
                </div>

                {mensagem && (
                  <div
                    style={{
                      background: mensagem.includes("sucesso") ? "#dcfce7" : "#fee2e2",
                      color: mensagem.includes("sucesso") ? "#166534" : "#991b1b",
                      borderRadius: isMobile ? 12 : 14,
                      padding: isMobile ? 10 : 12,
                      marginBottom: isMobile ? 12 : 16,
                      fontWeight: 800,
                    }}
                  >
                    {mensagem}
                  </div>
                )}

                {!editandoDados ? (
                  <>
                    <div
                      style={{
                        display: "grid",
                        gridTemplateColumns: isMobile ? "1fr" : "repeat(auto-fit, minmax(220px, 1fr))",
                        gap: isMobile ? 10 : 14,
                      }}
                    >
                      {[
                        ["Nome completo", cliente.nome || "-"],
                        ["Telefone", cliente.telefone || "-"],
                        ["E-mail", cliente.email || "Não informado"],
                        ["Nascimento", formatarData(cliente.data_nascimento)],
                        ["CEP", cliente.cep || "Não informado"],
                        ["Endereço", cliente.endereco || "Não informado"],
                        ["Número", cliente.numero || "-"],
                        ["Bairro", cliente.bairro || "-"],
                        [
                          "Cidade/UF",
                          `${cliente.cidade || "-"}/${cliente.estado || "-"}`,
                        ],
                      ].map(([titulo, valor]) => (
                        <div
                          key={titulo}
                          style={{
                            background: "#f8fafc",
                            border: "1px solid #e2e8f0",
                            borderRadius: isMobile ? 16 : 20,
                            padding: isMobile ? 12 : 18,
                          }}
                        >
                          <p
                            style={{
                              margin: "0 0 6px",
                              color: "#64748b",
                              fontSize: isMobile ? 11 : 12,
                              fontWeight: 800,
                              textTransform: "uppercase",
                              letterSpacing: isMobile ? 0.3 : 0.5,
                            }}
                          >
                            {titulo}
                          </p>
                          <strong style={{ color: "#0f172a", fontSize: isMobile ? 14 : 16 }}>
                            {valor}
                          </strong>
                        </div>
                      ))}
                    </div>

                    <div
                      style={{
                        marginTop: 18,
                        background: "#eef2ff",
                        border: "1px solid #c7d2fe",
                        color: "#3730a3",
                        borderRadius: isMobile ? 16 : 20,
                        padding: isMobile ? 12 : 18,
                        fontWeight: 800,
                      }}
                    >
                      Você pode atualizar seus dados cadastrais por aqui. O telefone não fica editável porque ele é usado como login do Meu Espaço.
                    </div>
                  </>
                ) : (
                  <div
                    style={{
                      background: "#f8fafc",
                      border: "1px solid #e2e8f0",
                      borderRadius: isMobile ? 18 : 22,
                      padding: isMobile ? 14 : 20,
                    }}
                  >
                    <h3 style={{ marginTop: 0 }}>Editar dados pessoais</h3>
                    <p style={{ color: "#64748b", marginTop: -6 }}>
                      Atualize seus dados. Para trocar o telefone de acesso, fale com o estabelecimento.
                    </p>

                    <div
                      style={{
                        display: "grid",
                        gridTemplateColumns: "repeat(auto-fit, minmax(230px, 1fr))",
                        gap: isMobile ? 10 : 14,
                      }}
                    >
                      <div>
                        <label style={{ fontWeight: 800 }}>Nome completo *</label>
                        <input
                          value={dadosEdicao.nome}
                          onChange={(e) =>
                            setDadosEdicao({ ...dadosEdicao, nome: e.target.value })
                          }
                          style={{
                            width: "100%",
                            padding: isMobile ? 9 : 14,
                            borderRadius: isMobile ? 12 : 14,
                            border: "1px solid #cbd5e1",
                            marginTop: isMobile ? 5 : 8,
                            boxSizing: "border-box",
                          }}
                        />
                      </div>

                      <div>
                        <label style={{ fontWeight: 800 }}>Telefone/login</label>
                        <input
                          value={cliente.telefone || ""}
                          disabled
                          style={{
                            width: "100%",
                            padding: isMobile ? 9 : 14,
                            borderRadius: isMobile ? 12 : 14,
                            border: "1px solid #cbd5e1",
                            background: "#e2e8f0",
                            color: "#475569",
                            marginTop: isMobile ? 5 : 8,
                            boxSizing: "border-box",
                          }}
                        />
                      </div>

                      <div>
                        <label style={{ fontWeight: 800 }}>E-mail</label>
                        <input
                          value={dadosEdicao.email}
                          onChange={(e) =>
                            setDadosEdicao({ ...dadosEdicao, email: e.target.value })
                          }
                          style={{
                            width: "100%",
                            padding: isMobile ? 9 : 14,
                            borderRadius: isMobile ? 12 : 14,
                            border: "1px solid #cbd5e1",
                            marginTop: isMobile ? 5 : 8,
                            boxSizing: "border-box",
                          }}
                        />
                      </div>

                      <div>
                        <label style={{ fontWeight: 800 }}>Data de nascimento</label>
                        <input
                          type="date"
                          value={dadosEdicao.data_nascimento || ""}
                          onChange={(e) =>
                            setDadosEdicao({ ...dadosEdicao, data_nascimento: e.target.value })
                          }
                          style={{
                            width: "100%",
                            padding: isMobile ? 9 : 14,
                            borderRadius: isMobile ? 12 : 14,
                            border: "1px solid #cbd5e1",
                            marginTop: isMobile ? 5 : 8,
                            boxSizing: "border-box",
                          }}
                        />
                      </div>

                      <div>
                        <label style={{ fontWeight: 800 }}>CEP</label>
                        <input
                          value={dadosEdicao.cep}
                          onChange={(e) => buscarCepEdicao(e.target.value)}
                          style={{
                            width: "100%",
                            padding: isMobile ? 9 : 14,
                            borderRadius: isMobile ? 12 : 14,
                            border: "1px solid #cbd5e1",
                            marginTop: isMobile ? 5 : 8,
                            boxSizing: "border-box",
                          }}
                        />
                        {buscandoCep && (
                          <p style={{ color: "#64748b", margin: "6px 0 0", fontSize: 13 }}>
                            Buscando endereço pelo CEP...
                          </p>
                        )}
                      </div>

                      <div>
                        <label style={{ fontWeight: 800 }}>Endereço</label>
                        <input
                          value={dadosEdicao.endereco}
                          onChange={(e) =>
                            setDadosEdicao({ ...dadosEdicao, endereco: e.target.value })
                          }
                          style={{
                            width: "100%",
                            padding: isMobile ? 9 : 14,
                            borderRadius: isMobile ? 12 : 14,
                            border: "1px solid #cbd5e1",
                            marginTop: isMobile ? 5 : 8,
                            boxSizing: "border-box",
                          }}
                        />
                      </div>

                      <div>
                        <label style={{ fontWeight: 800 }}>Número</label>
                        <input
                          value={dadosEdicao.numero}
                          onChange={(e) =>
                            setDadosEdicao({ ...dadosEdicao, numero: e.target.value })
                          }
                          style={{
                            width: "100%",
                            padding: isMobile ? 9 : 14,
                            borderRadius: isMobile ? 12 : 14,
                            border: "1px solid #cbd5e1",
                            marginTop: isMobile ? 5 : 8,
                            boxSizing: "border-box",
                          }}
                        />
                      </div>

                      <div>
                        <label style={{ fontWeight: 800 }}>Bairro</label>
                        <input
                          value={dadosEdicao.bairro}
                          onChange={(e) =>
                            setDadosEdicao({ ...dadosEdicao, bairro: e.target.value })
                          }
                          style={{
                            width: "100%",
                            padding: isMobile ? 9 : 14,
                            borderRadius: isMobile ? 12 : 14,
                            border: "1px solid #cbd5e1",
                            marginTop: isMobile ? 5 : 8,
                            boxSizing: "border-box",
                          }}
                        />
                      </div>

                      <div>
                        <label style={{ fontWeight: 800 }}>Cidade</label>
                        <input
                          value={dadosEdicao.cidade}
                          onChange={(e) =>
                            setDadosEdicao({ ...dadosEdicao, cidade: e.target.value })
                          }
                          style={{
                            width: "100%",
                            padding: isMobile ? 9 : 14,
                            borderRadius: isMobile ? 12 : 14,
                            border: "1px solid #cbd5e1",
                            marginTop: isMobile ? 5 : 8,
                            boxSizing: "border-box",
                          }}
                        />
                      </div>

                      <div>
                        <label style={{ fontWeight: 800 }}>UF</label>
                        <input
                          value={dadosEdicao.estado}
                          maxLength={2}
                          onChange={(e) =>
                            setDadosEdicao({
                              ...dadosEdicao,
                              estado: e.target.value.toUpperCase(),
                            })
                          }
                          style={{
                            width: "100%",
                            padding: isMobile ? 9 : 14,
                            borderRadius: isMobile ? 12 : 14,
                            border: "1px solid #cbd5e1",
                            marginTop: isMobile ? 5 : 8,
                            boxSizing: "border-box",
                          }}
                        />
                      </div>
                    </div>

                    <div style={{ display: "flex", gap: 12, marginTop: 20, flexWrap: "wrap" }}>
                      <button
                        type="button"
                        onClick={salvarDadosCliente}
                        disabled={salvandoDados}
                        style={{
                          padding: "14px 20px",
                          borderRadius: 16,
                          border: 0,
                          background: "#282663",
                          color: "#fff",
                          fontWeight: 900,
                          cursor: "pointer",
                        }}
                      >
                        {salvandoDados ? "Salvando..." : "Salvar alterações"}
                      </button>

                      <button
                        type="button"
                        onClick={cancelarEdicaoDados}
                        disabled={salvandoDados}
                        style={{
                          padding: "14px 20px",
                          borderRadius: 16,
                          border: "1px solid #cbd5e1",
                          background: "#fff",
                          color: "#334155",
                          fontWeight: 900,
                          cursor: "pointer",
                        }}
                      >
                        Cancelar
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}

          {aba === "anamnese" &&
            (assinaturaComplementarObrigatoria ? (
              formularioAssinaturaComplementar
            ) : anamneseObrigatoria || modoAtualizacaoAnamnese ? (
              formularioAnamnese
            ) : (
              <div>
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    gap: 16,
                    alignItems: "flex-start",
                    flexWrap: "wrap",
                    marginBottom: 18,
                  }}
                >
                  <div>
                    <h2 style={{ margin: 0 }}>Anamnese</h2>
                    <p style={{ color: "#64748b", margin: "6px 0 0" }}>
                      A ficha fica válida por 12 meses. Se algo mudar antes
                      disso, o cliente pode atualizar por aqui.
                    </p>
                  </div>

                  <div
                    style={{
                      background:
                        anamnesePreenchida &&
                        !anamneseEstaVencida(anamnesePreenchida)
                          ? "#dcfce7"
                          : "#fff7ed",
                      color:
                        anamnesePreenchida &&
                        !anamneseEstaVencida(anamnesePreenchida)
                          ? "#166534"
                          : "#9a3412",
                      border:
                        anamnesePreenchida &&
                        !anamneseEstaVencida(anamnesePreenchida)
                          ? "1px solid #bbf7d0"
                          : "1px solid #fed7aa",
                      borderRadius: 999,
                      padding: "10px 14px",
                      fontWeight: 900,
                    }}
                  >
                    {anamnesePreenchida &&
                    !anamneseEstaVencida(anamnesePreenchida)
                      ? "Ficha válida"
                      : "Atualização necessária"}
                  </div>
                </div>

                <div
                  style={{
                    display: "grid",
                    gridTemplateColumns: isMobile ? "1fr" : "repeat(auto-fit, minmax(220px, 1fr))",
                    gap: isMobile ? 10 : 14,
                    marginBottom: 18,
                  }}
                >
                  <div
                    style={{
                      background: "#f8fafc",
                      border: "1px solid #e2e8f0",
                      borderRadius: isMobile ? 16 : 20,
                      padding: isMobile ? 12 : 18,
                    }}
                  >
                    <p
                      style={{
                        margin: "0 0 6px",
                        color: "#64748b",
                        fontSize: isMobile ? 11 : 12,
                        fontWeight: 800,
                      }}
                    >
                      Último preenchimento
                    </p>
                    <strong>
                      {formatarDataAnamnese(
                        obterDataBaseAnamnese(anamnesePreenchida),
                      )}
                    </strong>
                  </div>

                  <div
                    style={{
                      background: "#f8fafc",
                      border: "1px solid #e2e8f0",
                      borderRadius: isMobile ? 16 : 20,
                      padding: isMobile ? 12 : 18,
                    }}
                  >
                    <p
                      style={{
                        margin: "0 0 6px",
                        color: "#64748b",
                        fontSize: isMobile ? 11 : 12,
                        fontWeight: 800,
                      }}
                    >
                      Próxima atualização obrigatória
                    </p>
                    <strong>
                      {formatarDataAnamnese(
                        calcularValidadeAnamnese(anamnesePreenchida),
                      )}
                    </strong>
                  </div>

                  <div
                    style={{
                      background: "#f8fafc",
                      border: "1px solid #e2e8f0",
                      borderRadius: isMobile ? 16 : 20,
                      padding: isMobile ? 12 : 18,
                    }}
                  >
                    <p
                      style={{
                        margin: "0 0 6px",
                        color: "#64748b",
                        fontSize: isMobile ? 11 : 12,
                        fontWeight: 800,
                      }}
                    >
                      Assinatura
                    </p>
                    <strong>
                      {anamnesePreenchida?.assinatura ? "Assinada" : "Pendente"}
                    </strong>
                  </div>
                </div>

                <div
                  style={{
                    background: "#eef2ff",
                    color: "#3730a3",
                    border: "1px solid #c7d2fe",
                    borderRadius: 18,
                    padding: isMobile ? 12 : 18,
                    fontWeight: 800,
                  }}
                >
                  Caso tenha surgido alergia, doença, uso de medicamento ou
                  qualquer mudança importante, atualize sua ficha antes do
                  atendimento.
                </div>

                <div
                  style={{
                    display: "flex",
                    gap: 12,
                    flexWrap: "wrap",
                    marginTop: 18,
                  }}
                >
                  <button
                    type="button"
                    onClick={baixarPdfAnamnese}
                    style={{
                      padding: "13px 18px",
                      borderRadius: isMobile ? 12 : 14,
                      border: 0,
                      background: "#282663",
                      color: "#fff",
                      fontWeight: 900,
                      cursor: "pointer",
                    }}
                  >
                    Baixar PDF da anamnese
                  </button>

                  <button
                    type="button"
                    onClick={abrirAtualizacaoAnamnese}
                    style={{
                      padding: "13px 18px",
                      borderRadius: isMobile ? 12 : 14,
                      border: "1px solid #282663",
                      background: "#fff",
                      color: "#282663",
                      fontWeight: 900,
                      cursor: "pointer",
                    }}
                  >
                    Atualizar minha anamnese
                  </button>
                </div>
              </div>
            ))}

          {aba === "historico" &&
            !anamneseObrigatoria &&
            !assinaturaComplementarObrigatoria && (
              <div>
                <h2 style={{ marginTop: 0 }}>Histórico</h2>

                {historico.length === 0 && (
                  <p style={{ color: "#64748b" }}>
                    Nenhum atendimento finalizado.
                  </p>
                )}

                {historico.map((h) => (
                  <div
                    key={h.id}
                    style={{
                      border: "1px solid #e2e8f0",
                      borderRadius: 18,
                      padding: isMobile ? 13 : 18,
                      marginBottom: 14,
                    }}
                  >
                    <strong>{h.servico || h.servico_nome}</strong>
                    <div>
                      {formatarData(h.data)} às {h.horario}
                    </div>
                    <div>Status: {h.status}</div>
                  </div>
                ))}
              </div>
            )}


          {aba === "pacotes" &&
            !anamneseObrigatoria &&
            !assinaturaComplementarObrigatoria && (
              <div>
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "flex-start",
                    gap: 14,
                    flexWrap: "wrap",
                    marginBottom: 18,
                  }}
                >
                  <div>
                    <h2 style={{ margin: 0 }}>Pacotes e Combos</h2>
                    <p style={{ color: "#64748b", margin: "6px 0 0" }}>
                      Consulte seus pacotes ativos, saldos restantes e validade.
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={() => cliente?.id && carregarPacotesCliente(cliente.id)}
                    style={{
                      padding: "11px 14px",
                      borderRadius: 14,
                      border: "1px solid #cbd5e1",
                      background: "#fff",
                      color: "#282663",
                      fontWeight: 900,
                      cursor: "pointer",
                    }}
                  >
                    Atualizar
                  </button>
                </div>

                {carregandoPacotesCliente && (
                  <p style={{ color: "#64748b" }}>Carregando pacotes...</p>
                )}

                {!carregandoPacotesCliente && pacotesCliente.length === 0 && (
                  <div
                    style={{
                      border: "1px solid #e2e8f0",
                      borderRadius: 18,
                      padding: isMobile ? 13 : 18,
                      marginBottom: 14,
                      background: "#f8fafc",
                    }}
                  >
                    <strong>Nenhum pacote ativo encontrado.</strong>
                    <p style={{ color: "#64748b", marginTop: 8 }}>
                      Quando o estabelecimento vincular um pacote ao seu cadastro,
                      ele aparecerá aqui.
                    </p>
                  </div>
                )}

                {pacotesCliente.map((vinculo: any) => {
                  const percentual = vinculo.total_sessoes
                    ? Math.min((vinculo.total_usado / vinculo.total_sessoes) * 100, 100)
                    : 0;
                  const status = String(vinculo.status || "ativo").toLowerCase();

                  return (
                    <div
                      key={vinculo.id}
                      style={{
                        border: "1px solid #e2e8f0",
                        borderRadius: 22,
                        padding: isMobile ? 14 : 20,
                        marginBottom: 16,
                        background: "#fff",
                        boxShadow: "0 10px 25px rgba(15,23,42,.05)",
                      }}
                    >
                      <div
                        style={{
                          display: "flex",
                          justifyContent: "space-between",
                          alignItems: "flex-start",
                          gap: 14,
                          flexWrap: "wrap",
                        }}
                      >
                        <div>
                          <h3 style={{ margin: "0 0 6px", color: "#0f172a" }}>
                            {vinculo.pacote?.nome || "Pacote"}
                          </h3>
                          <p style={{ margin: 0, color: "#64748b", fontWeight: 700 }}>
                            Validade: {vinculo.data_fim ? formatarData(vinculo.data_fim) : "Sem data final"}
                          </p>
                        </div>

                        <div
                          style={{
                            background: status === "ativo" ? "#dcfce7" : "#fee2e2",
                            color: status === "ativo" ? "#166534" : "#991b1b",
                            border: status === "ativo" ? "1px solid #bbf7d0" : "1px solid #fecaca",
                            borderRadius: 999,
                            padding: "8px 12px",
                            fontWeight: 900,
                          }}
                        >
                          {vinculo.total_restante} sessões restantes
                        </div>
                      </div>

                      <div style={{ marginTop: 18 }}>
                        <div
                          style={{
                            display: "flex",
                            justifyContent: "space-between",
                            marginBottom: 8,
                            fontWeight: 800,
                            color: "#334155",
                          }}
                        >
                          <span>Uso do pacote</span>
                          <span>
                            {vinculo.total_usado}/{vinculo.total_sessoes}
                          </span>
                        </div>

                        <div
                          style={{
                            width: "100%",
                            height: 14,
                            background: "#e2e8f0",
                            borderRadius: 999,
                            overflow: "hidden",
                          }}
                        >
                          <div
                            style={{
                              width: `${percentual}%`,
                              height: "100%",
                              background: "linear-gradient(90deg,#282663,#5b5bd6)",
                              borderRadius: 999,
                            }}
                          />
                        </div>
                      </div>

                      {vinculo.saldos.length > 0 && (
                        <div
                          style={{
                            display: "grid",
                            gridTemplateColumns: isMobile ? "1fr" : "repeat(auto-fit, minmax(220px, 1fr))",
                            gap: 10,
                            marginTop: 18,
                          }}
                        >
                          {vinculo.saldos.map((saldo: any) => (
                            <div
                              key={saldo.id}
                              style={{
                                border: "1px solid #e2e8f0",
                                borderRadius: 16,
                                padding: 12,
                                background: "#f8fafc",
                              }}
                            >
                              <strong>{saldo.servico_nome}</strong>
                              <p style={{ margin: "6px 0 0", color: "#64748b" }}>
                                Restam {saldo.quantidade_restante} de {saldo.quantidade_total}
                              </p>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
        </div>

        {navInferior && (
          <div
            style={{
              position: "fixed",
              left: 10,
              right: 10,
              bottom: 10,
              zIndex: 40,
              background: "rgba(255,255,255,.96)",
              border: "1px solid #e2e8f0",
              borderRadius: 24,
              boxShadow: "0 18px 45px rgba(15,23,42,.18)",
              padding: "8px 8px calc(8px + env(safe-area-inset-bottom))",
              display: "grid",
              gridTemplateColumns: "repeat(5, 1fr)",
              gap: 6,
              backdropFilter: "blur(14px)",
            }}
          >
            {[
              ["agenda", "📅", "Agenda"],
              ["dados", "👤", "Dados"],
              ["anamnese", "🧾", "Ficha"],
              ["historico", "🕘", "Histórico"],
              ["pacotes", "🎁", "Pacotes"],
            ].map(([valor, icone, label]) => (
              <button
                key={valor}
                type="button"
                onClick={() => setAba(valor)}
                style={{
                  border: 0,
                  borderRadius: 18,
                  padding: "8px 4px",
                  background: aba === valor ? "#282663" : "transparent",
                  color: aba === valor ? "#fff" : "#475569",
                  fontWeight: 900,
                  fontSize: 11,
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  gap: 2,
                  cursor: "pointer",
                }}
              >
                <span style={{ fontSize: 17, lineHeight: 1 }}>{icone}</span>
                <span>{label}</span>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

