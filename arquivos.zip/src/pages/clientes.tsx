import { useEffect, useState } from "react";
import { supabase } from "../lib/supabase";
import HistoricoAnamnese from "../components/clientes/HistoricoAnamnese";

type Cliente = {
  id: string;
  nome: string;
  telefone: string | null;
  criado_em: string;
};

type Configuracao = {
  nome_empresa?: string | null;
  nome_fantasia?: string | null;
};

export default function ClientesPage() {
  const [clientes, setClientes] = useState<Cliente[]>([]);
  const [clientesFiltrados, setClientesFiltrados] = useState<Cliente[]>([]);
  const [clienteSelecionado, setClienteSelecionado] = useState<Cliente | null>(null);
  const [busca, setBusca] = useState("");
  const [loading, setLoading] = useState(true);
  const [empresaNome, setEmpresaNome] = useState("Seu estabelecimento");

  useEffect(() => {
    void inicializar();
  }, []);

  useEffect(() => {
    filtrarClientes();
  }, [busca, clientes]);

  async function inicializar() {
    setLoading(true);
    await Promise.all([carregarClientes(), carregarConfiguracaoEmpresa()]);
    setLoading(false);
  }

  async function carregarClientes() {
    const { data, error } = await supabase
      .from("clientes")
      .select("*")
      .order("nome", { ascending: true });

    if (error) {
      console.error("Erro ao carregar clientes:", error);
      setClientes([]);
      return;
    }

    setClientes((data || []) as Cliente[]);
  }

  async function carregarConfiguracaoEmpresa() {
    const { data, error } = await supabase
      .from("configuracoes")
      .select("nome_empresa, nome_fantasia")
      .limit(1)
      .maybeSingle();

    if (error) {
      console.error("Erro ao carregar configurações da empresa:", error);
      setEmpresaNome("Seu estabelecimento");
      return;
    }

    const config = (data || {}) as Configuracao;

    setEmpresaNome(
      config.nome_fantasia ||
        config.nome_empresa ||
        "Seu estabelecimento"
    );
  }

  function filtrarClientes() {
    if (!busca.trim()) {
      setClientesFiltrados(clientes);
      return;
    }

    const termo = busca.toLowerCase();

    const filtrados = clientes.filter((c) =>
      c.nome.toLowerCase().includes(termo) ||
      (c.telefone || "").includes(termo)
    );

    setClientesFiltrados(filtrados);
  }

  function selecionarCliente(cliente: Cliente) {
    setClienteSelecionado(cliente);
  }

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-slate-900">Clientes</h1>
        <p className="text-slate-500">
          Gerencie seus clientes e visualize histórico de anamnese
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-[320px_1fr]">
        <div className="rounded-2xl bg-white p-4 shadow space-y-4">
          <input
            type="text"
            placeholder="Buscar cliente..."
            value={busca}
            onChange={(e) => setBusca(e.target.value)}
            className="w-full rounded-lg border p-2"
          />

          <div className="space-y-2 max-h-[500px] overflow-auto">
            {loading ? (
              <p className="text-slate-500 text-sm">Carregando...</p>
            ) : clientesFiltrados.length === 0 ? (
              <p className="text-slate-500 text-sm">
                Nenhum cliente encontrado
              </p>
            ) : (
              clientesFiltrados.map((cliente) => (
                <button
                  key={cliente.id}
                  onClick={() => selecionarCliente(cliente)}
                  className={`w-full text-left rounded-xl p-3 border ${
                    clienteSelecionado?.id === cliente.id
                      ? "border-slate-900 bg-slate-50"
                      : "border-slate-200"
                  }`}
                >
                  <p className="font-medium text-slate-900">
                    {cliente.nome}
                  </p>
                  <p className="text-sm text-slate-500">
                    {cliente.telefone || "Sem telefone"}
                  </p>
                </button>
              ))
            )}
          </div>
        </div>

        <div className="space-y-6">
          {!clienteSelecionado ? (
            <div className="rounded-2xl bg-white p-6 shadow">
              <p className="text-slate-500">
                Selecione um cliente para visualizar os detalhes
              </p>
            </div>
          ) : (
            <>
              <div className="rounded-2xl bg-white p-6 shadow">
                <h2 className="text-2xl font-bold text-slate-900">
                  {clienteSelecionado.nome}
                </h2>

                <div className="mt-4 space-y-2 text-slate-700">
                  <p>
                    <strong>Telefone:</strong>{" "}
                    {clienteSelecionado.telefone || "Não informado"}
                  </p>
                  <p>
                    <strong>Cadastrado em:</strong>{" "}
                    {new Date(
                      clienteSelecionado.criado_em
                    ).toLocaleDateString("pt-BR")}
                  </p>
                </div>
              </div>

              <div className="rounded-2xl bg-white p-6 shadow">
                <HistoricoAnamnese
                  clienteId={clienteSelecionado.id}
                  clienteNome={clienteSelecionado.nome}
                  telefoneCliente={clienteSelecionado.telefone || ""}
                  empresaNome={empresaNome}
                />
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}