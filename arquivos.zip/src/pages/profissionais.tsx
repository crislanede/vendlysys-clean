import { useEffect, useMemo, useState } from "react";
import { supabase } from "../lib/supabase";

type Profissional = {
  id: string;
  nome: string;
  telefone: string | null;
  especialidades: string[] | null;
  dias_atendimento: string[] | null;
  hora_inicio: string | null;
  hora_fim: string | null;
  hora_inicio_almoco: string | null;
  hora_fim_almoco: string | null;
  intervalo_minutos: number | null;
  cor: string | null;
  ativo: boolean | null;
  avatar_url?: string | null;
  excluido_em?: string | null;
  motivo_inativacao?: string | null;
};

type Servico = {
  id: string;
  nome: string;
  categoria: string | null;
  ativo: boolean | null;
};

const diasSemana = [
  { value: "segunda", label: "Segunda" },
  { value: "terca", label: "Terça" },
  { value: "quarta", label: "Quarta" },
  { value: "quinta", label: "Quinta" },
  { value: "sexta", label: "Sexta" },
  { value: "sabado", label: "Sábado" },
  { value: "domingo", label: "Domingo" },
];

type FormState = {
  nome: string;
  telefone: string;
  especialidades: string[];
  dias_atendimento: string[];
  hora_inicio: string;
  hora_fim: string;
  hora_inicio_almoco: string;
  hora_fim_almoco: string;
  intervalo_minutos: string;
  cor: string;
  ativo: boolean;
  avatar_url: string;
};

const initialForm: FormState = {
  nome: "",
  telefone: "",
  especialidades: [],
  dias_atendimento: [],
  hora_inicio: "08:00",
  hora_fim: "18:00",
  hora_inicio_almoco: "12:00",
  hora_fim_almoco: "13:00",
  intervalo_minutos: "0",
  cor: "#f97316",
  ativo: true,
  avatar_url: "",
};

function traduzirDia(valor: string) {
  const encontrado = diasSemana.find((d) => d.value === valor);
  return encontrado?.label || valor;
}

function horaParaMinutos(hora: string) {
  const [h, m] = hora.split(":").map(Number);
  return h * 60 + m;
}

function getIniciais(nome: string) {
  return nome
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((parte) => parte[0]?.toUpperCase())
    .join("");
}

export default function ProfissionaisPage() {
  const [lista, setLista] = useState<Profissional[]>([]);
  const [servicos, setServicos] = useState<Servico[]>([]);
  const [loading, setLoading] = useState(true);
  const [salvando, setSalvando] = useState(false);
  const [uploadingAvatar, setUploadingAvatar] = useState(false);

  const [busca, setBusca] = useState("");
  const [mostrarFormulario, setMostrarFormulario] = useState(false);
  const [editandoId, setEditandoId] = useState<string | null>(null);
  const [form, setForm] = useState<FormState>(initialForm);

  useEffect(() => {
    void carregarTudo();
  }, []);

  async function carregarTudo() {
    setLoading(true);
    await Promise.all([carregarProfissionais(), carregarServicos()]);
    setLoading(false);
  }

  async function carregarProfissionais() {
    const { data, error } = await supabase
      .from("profissionais")
      .select("*")
      .is("excluido_em", null)
      .order("nome", { ascending: true });

    if (error) {
      console.error("Erro ao carregar profissionais:", error);
      setLista([]);
      return;
    }

    setLista((data || []) as Profissional[]);
  }

  async function carregarServicos() {
    const { data, error } = await supabase
      .from("servicos")
      .select("id, nome, categoria, ativo")
      .eq("ativo", true)
      .order("nome", { ascending: true });

    if (error) {
      console.error("Erro ao carregar serviços:", error);
      setServicos([]);
      return;
    }

    setServicos((data || []) as Servico[]);
  }

  const categoriasDisponiveis = useMemo(() => {
    const categorias = servicos
      .map((s) => s.categoria)
      .filter(Boolean) as string[];

    return [...new Set(categorias)].sort((a, b) => a.localeCompare(b));
  }, [servicos]);

  const listaFiltrada = useMemo(() => {
    const termo = busca.toLowerCase().trim();
    if (!termo) return lista;

    return lista.filter((item) => {
      return (
        item.nome?.toLowerCase().includes(termo) ||
        item.telefone?.toLowerCase().includes(termo) ||
        item.especialidades?.join(" ").toLowerCase().includes(termo)
      );
    });
  }, [lista, busca]);

  function atualizarCampo<K extends keyof FormState>(campo: K, valor: FormState[K]) {
    setForm((atual) => ({
      ...atual,
      [campo]: valor,
    }));
  }

  function alternarEspecialidade(categoria: string) {
    setForm((atual) => {
      const jaExiste = atual.especialidades.includes(categoria);

      return {
        ...atual,
        especialidades: jaExiste
          ? atual.especialidades.filter((item) => item !== categoria)
          : [...atual.especialidades, categoria],
      };
    });
  }

  function alternarDia(dia: string) {
    setForm((atual) => {
      const jaExiste = atual.dias_atendimento.includes(dia);

      return {
        ...atual,
        dias_atendimento: jaExiste
          ? atual.dias_atendimento.filter((item) => item !== dia)
          : [...atual.dias_atendimento, dia],
      };
    });
  }

  function abrirNovo() {
    setEditandoId(null);
    setForm(initialForm);
    setMostrarFormulario(true);
  }

  function editarProfissional(item: Profissional) {
    setEditandoId(item.id);
    setForm({
      nome: item.nome || "",
      telefone: item.telefone || "",
      especialidades: item.especialidades || [],
      dias_atendimento: item.dias_atendimento || [],
      hora_inicio: item.hora_inicio || "08:00",
      hora_fim: item.hora_fim || "18:00",
      hora_inicio_almoco: item.hora_inicio_almoco || "12:00",
      hora_fim_almoco: item.hora_fim_almoco || "13:00",
      intervalo_minutos: String(item.intervalo_minutos ?? 0),
      cor: item.cor || "#f97316",
      ativo: item.ativo ?? true,
      avatar_url: item.avatar_url || "",
    });
    setMostrarFormulario(true);
  }

  function cancelarFormulario() {
    setEditandoId(null);
    setForm(initialForm);
    setMostrarFormulario(false);
  }

  function validarHorarios() {
    const inicio = horaParaMinutos(form.hora_inicio);
    const fim = horaParaMinutos(form.hora_fim);

    if (inicio >= fim) {
      alert("O horário de início deve ser menor que o horário final.");
      return false;
    }

    if (Number(form.intervalo_minutos) < 0) {
      alert("O intervalo não pode ser negativo.");
      return false;
    }

    if (form.hora_inicio_almoco && form.hora_fim_almoco) {
      const almocoInicio = horaParaMinutos(form.hora_inicio_almoco);
      const almocoFim = horaParaMinutos(form.hora_fim_almoco);

      if (almocoInicio >= almocoFim) {
        alert("O início do almoço deve ser menor que o fim do almoço.");
        return false;
      }

      if (almocoInicio < inicio || almocoFim > fim) {
        alert("O horário de almoço precisa estar dentro do expediente.");
        return false;
      }
    }

    return true;
  }

  async function uploadAvatar(file: File) {
    setUploadingAvatar(true);

    const extensao = file.name.split(".").pop();
    const nomeArquivo = `profissional-${Date.now()}.${extensao}`;

    const { error: uploadError } = await supabase.storage
      .from("avatars")
      .upload(nomeArquivo, file, {
        upsert: true,
      });

    if (uploadError) {
      console.error("Erro no upload do avatar:", uploadError);
      alert("Erro ao enviar avatar.");
      setUploadingAvatar(false);
      return;
    }

    const { data } = supabase.storage.from("avatars").getPublicUrl(nomeArquivo);

    atualizarCampo("avatar_url", data.publicUrl);
    setUploadingAvatar(false);
  }

  async function salvarProfissional(e: React.FormEvent) {
    e.preventDefault();

    if (!form.nome.trim()) {
      alert("Informe o nome do profissional.");
      return;
    }

    if (!validarHorarios()) {
      return;
    }

    setSalvando(true);

    const payload = {
      nome: form.nome.trim(),
      telefone: form.telefone.trim() || null,
      especialidades: form.especialidades,
      dias_atendimento: form.dias_atendimento,
      hora_inicio: form.hora_inicio || null,
      hora_fim: form.hora_fim || null,
      hora_inicio_almoco: form.hora_inicio_almoco || null,
      hora_fim_almoco: form.hora_fim_almoco || null,
      intervalo_minutos: Number(form.intervalo_minutos || 0),
      cor: form.cor || "#f97316",
      ativo: form.ativo,
      avatar_url: form.avatar_url || null,
      excluido_em: null,
    };

    if (editandoId) {
      const { error } = await supabase
        .from("profissionais")
        .update(payload)
        .eq("id", editandoId);

      if (error) {
        console.error("Erro ao atualizar profissional:", error);
        alert("Erro ao atualizar profissional.");
        setSalvando(false);
        return;
      }

      alert("Profissional atualizado com sucesso.");
    } else {
      const { error } = await supabase
        .from("profissionais")
        .insert([payload]);

      if (error) {
        console.error("Erro ao criar profissional:", error);
        alert("Erro ao criar profissional.");
        setSalvando(false);
        return;
      }

      alert("Profissional criado com sucesso.");
    }

    setSalvando(false);
    cancelarFormulario();
    await carregarProfissionais();
  }

  async function alternarStatus(item: Profissional) {
    const novoStatus = !(item.ativo ?? true);

    const { error } = await supabase
      .from("profissionais")
      .update({
        ativo: novoStatus,
        motivo_inativacao: novoStatus ? null : "Inativado manualmente",
      })
      .eq("id", item.id);

    if (error) {
      console.error("Erro ao alterar status do profissional:", error);
      alert("Erro ao alterar status.");
      return;
    }

    await carregarProfissionais();
  }

  async function excluirLogicamente(item: Profissional) {
    const confirmar = window.confirm(
      `Deseja excluir logicamente o profissional ${item.nome}?`
    );
    if (!confirmar) return;

    const { error } = await supabase
      .from("profissionais")
      .update({
        ativo: false,
        excluido_em: new Date().toISOString(),
        motivo_inativacao: "Exclusão lógica",
      })
      .eq("id", item.id);

    if (error) {
      console.error("Erro ao excluir profissional:", error);
      alert("Erro ao excluir profissional.");
      return;
    }

    await carregarProfissionais();
    alert("Profissional removido da listagem com sucesso.");
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
        <div>
          <p className="text-sm text-orange-500">Gestão</p>
          <h1 className="text-3xl font-bold text-slate-900">Profissionais</h1>
          <p className="text-slate-500">
            Cadastre profissionais, configure agenda, avatar, dias, horários e cor.
          </p>
        </div>

        <button
          type="button"
          onClick={abrirNovo}
          className="rounded-xl px-5 py-3 font-semibold text-white"
          style={{ backgroundColor: "var(--color-primary)" }}
        >
          Novo profissional
        </button>
      </div>

      <div className="rounded-2xl bg-white p-6 shadow space-y-4">
        <div className="grid gap-4 md:grid-cols-[1fr_auto]">
          <input
            value={busca}
            onChange={(e) => setBusca(e.target.value)}
            className="w-full rounded-lg border p-2"
            placeholder="Buscar por nome, telefone ou especialidade"
          />

          <button
            type="button"
            onClick={() => void carregarProfissionais()}
            className="rounded-xl border px-4 py-2 font-medium text-slate-700"
          >
            Recarregar
          </button>
        </div>
      </div>

      {mostrarFormulario && (
        <form
          onSubmit={salvarProfissional}
          className="rounded-2xl bg-white p-6 shadow space-y-6"
        >
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-semibold text-slate-900">
              {editandoId ? "Editar profissional" : "Novo profissional"}
            </h2>

            <button
              type="button"
              onClick={cancelarFormulario}
              className="rounded-xl border px-4 py-2 text-sm font-medium text-slate-700"
            >
              Fechar
            </button>
          </div>

          <div className="grid gap-6 md:grid-cols-[160px_1fr]">
            <div className="space-y-3">
              <div className="flex h-36 w-36 items-center justify-center overflow-hidden rounded-2xl border bg-slate-50">
                {form.avatar_url ? (
                  <img
                    src={form.avatar_url}
                    alt="Avatar do profissional"
                    className="h-full w-full object-cover"
                  />
                ) : (
                  <span className="text-2xl font-bold text-slate-500">
                    {getIniciais(form.nome || "P")}
                  </span>
                )}
              </div>

              <label className="block">
                <span className="mb-1 block text-sm text-slate-600">
                  Avatar
                </span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) void uploadAvatar(file);
                  }}
                  className="block w-full text-sm"
                />
              </label>

              {uploadingAvatar && (
                <p className="text-sm text-slate-500">Enviando avatar...</p>
              )}
            </div>

            <div className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <label className="mb-1 block text-sm text-slate-600">Nome</label>
                  <input
                    value={form.nome}
                    onChange={(e) => atualizarCampo("nome", e.target.value)}
                    className="w-full rounded-lg border p-2"
                    placeholder="Nome do profissional"
                  />
                </div>

                <div>
                  <label className="mb-1 block text-sm text-slate-600">Telefone</label>
                  <input
                    value={form.telefone}
                    onChange={(e) => atualizarCampo("telefone", e.target.value)}
                    className="w-full rounded-lg border p-2"
                    placeholder="Telefone"
                  />
                </div>
              </div>

              <div className="grid gap-6 md:grid-cols-2">
                <div>
                  <label className="mb-2 block text-sm text-slate-600">
                    Especialidades
                  </label>

                  {categoriasDisponiveis.length === 0 ? (
                    <p className="text-sm text-slate-500">
                      Nenhuma categoria encontrada em Serviços.
                    </p>
                  ) : (
                    <div className="grid gap-2">
                      {categoriasDisponiveis.map((categoria) => (
                        <label
                          key={categoria}
                          className="flex items-center gap-2 rounded-lg border p-2"
                        >
                          <input
                            type="checkbox"
                            checked={form.especialidades.includes(categoria)}
                            onChange={() => alternarEspecialidade(categoria)}
                          />
                          <span>{categoria}</span>
                        </label>
                      ))}
                    </div>
                  )}
                </div>

                <div>
                  <label className="mb-2 block text-sm text-slate-600">
                    Dias de atendimento
                  </label>

                  <div className="grid gap-2">
                    {diasSemana.map((dia) => (
                      <label
                        key={dia.value}
                        className="flex items-center gap-2 rounded-lg border p-2"
                      >
                        <input
                          type="checkbox"
                          checked={form.dias_atendimento.includes(dia.value)}
                          onChange={() => alternarDia(dia.value)}
                        />
                        <span>{dia.label}</span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>

              <div className="grid gap-4 md:grid-cols-3">
                <div>
                  <label className="mb-1 block text-sm text-slate-600">
                    Hora início
                  </label>
                  <input
                    type="time"
                    value={form.hora_inicio}
                    onChange={(e) => atualizarCampo("hora_inicio", e.target.value)}
                    className="w-full rounded-lg border p-2"
                  />
                </div>

                <div>
                  <label className="mb-1 block text-sm text-slate-600">
                    Hora fim
                  </label>
                  <input
                    type="time"
                    value={form.hora_fim}
                    onChange={(e) => atualizarCampo("hora_fim", e.target.value)}
                    className="w-full rounded-lg border p-2"
                  />
                </div>

                <div>
                  <label className="mb-1 block text-sm text-slate-600">
                    Intervalo entre atendimentos (min)
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={form.intervalo_minutos}
                    onChange={(e) =>
                      atualizarCampo("intervalo_minutos", e.target.value)
                    }
                    className="w-full rounded-lg border p-2"
                  />
                </div>
              </div>

              <div className="grid gap-4 md:grid-cols-3">
                <div>
                  <label className="mb-1 block text-sm text-slate-600">
                    Início do almoço
                  </label>
                  <input
                    type="time"
                    value={form.hora_inicio_almoco}
                    onChange={(e) =>
                      atualizarCampo("hora_inicio_almoco", e.target.value)
                    }
                    className="w-full rounded-lg border p-2"
                  />
                </div>

                <div>
                  <label className="mb-1 block text-sm text-slate-600">
                    Fim do almoço
                  </label>
                  <input
                    type="time"
                    value={form.hora_fim_almoco}
                    onChange={(e) =>
                      atualizarCampo("hora_fim_almoco", e.target.value)
                    }
                    className="w-full rounded-lg border p-2"
                  />
                </div>

                <div>
                  <label className="mb-1 block text-sm text-slate-600">Cor</label>
                  <input
                    type="color"
                    value={form.cor}
                    onChange={(e) => atualizarCampo("cor", e.target.value)}
                    className="h-11 w-full rounded-lg border"
                  />
                </div>
              </div>

              <div className="flex items-center gap-3">
                <input
                  id="ativo"
                  type="checkbox"
                  checked={form.ativo}
                  onChange={(e) => atualizarCampo("ativo", e.target.checked)}
                />
                <label htmlFor="ativo" className="text-sm text-slate-700">
                  Profissional ativo
                </label>
              </div>
            </div>
          </div>

          <div className="flex gap-3">
            <button
              type="submit"
              disabled={salvando}
              className="rounded-xl px-5 py-3 font-semibold text-white disabled:opacity-60"
              style={{ backgroundColor: "var(--color-primary)" }}
            >
              {salvando
                ? "Salvando..."
                : editandoId
                ? "Salvar alterações"
                : "Criar profissional"}
            </button>

            <button
              type="button"
              onClick={cancelarFormulario}
              className="rounded-xl border px-5 py-3 font-medium text-slate-700"
            >
              Cancelar
            </button>
          </div>
        </form>
      )}

      <div className="rounded-2xl bg-white p-6 shadow space-y-4">
        {loading ? (
          <p>Carregando...</p>
        ) : listaFiltrada.length === 0 ? (
          <p className="text-slate-500">Nenhum profissional cadastrado.</p>
        ) : (
          <div className="space-y-4">
            {listaFiltrada.map((item) => (
              <div
                key={item.id}
                className="rounded-2xl border p-4"
                style={{
                  borderLeftWidth: "6px",
                  borderLeftColor: item.cor || "#f97316",
                }}
              >
                <div className="flex flex-col gap-4 xl:flex-row xl:items-start xl:justify-between">
                  <div className="flex gap-4">
                    <div className="flex h-16 w-16 items-center justify-center overflow-hidden rounded-2xl border bg-slate-50 shrink-0">
                      {item.avatar_url ? (
                        <img
                          src={item.avatar_url}
                          alt={item.nome}
                          className="h-full w-full object-cover"
                        />
                      ) : (
                        <span className="font-bold text-slate-600">
                          {getIniciais(item.nome)}
                        </span>
                      )}
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center gap-3">
                        <p className="text-xl font-semibold text-slate-900">
                          {item.nome}
                        </p>

                        <span
                          className={`rounded-full px-3 py-1 text-xs font-medium ${
                            item.ativo
                              ? "bg-green-100 text-green-700"
                              : "bg-slate-100 text-slate-700"
                          }`}
                        >
                          {item.ativo ? "ativo" : "inativo"}
                        </span>
                      </div>

                      <p className="text-sm text-slate-500">
                        {item.telefone || "Sem telefone"}
                      </p>

                      <p className="text-sm text-slate-600">
                        <strong>Especialidades:</strong>{" "}
                        {item.especialidades?.length
                          ? item.especialidades.join(", ")
                          : "Não informado"}
                      </p>

                      <p className="text-sm text-slate-600">
                        <strong>Dias:</strong>{" "}
                        {item.dias_atendimento?.length
                          ? item.dias_atendimento.map(traduzirDia).join(", ")
                          : "Não informado"}
                      </p>

                      <p className="text-sm text-slate-600">
                        <strong>Atendimento:</strong>{" "}
                        {item.hora_inicio || "--:--"} às {item.hora_fim || "--:--"}
                      </p>

                      <p className="text-sm text-slate-600">
                        <strong>Almoço:</strong>{" "}
                        {item.hora_inicio_almoco || "--:--"} às{" "}
                        {item.hora_fim_almoco || "--:--"}
                      </p>

                      <p className="text-sm text-slate-600">
                        <strong>Intervalo:</strong>{" "}
                        {item.intervalo_minutos ?? 0} min
                      </p>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    <button
                      type="button"
                      onClick={() => editarProfissional(item)}
                      className="rounded-xl border px-4 py-2 text-sm font-medium text-slate-700"
                    >
                      Editar
                    </button>

                    <button
                      type="button"
                      onClick={() => void alternarStatus(item)}
                      className="rounded-xl px-4 py-2 text-sm font-medium text-white"
                      style={{
                        backgroundColor: item.ativo ? "#ef4444" : "#16a34a",
                      }}
                    >
                      {item.ativo ? "Inativar" : "Ativar"}
                    </button>

                    <button
                      type="button"
                      onClick={() => void excluirLogicamente(item)}
                      className="rounded-xl bg-slate-900 px-4 py-2 text-sm font-medium text-white"
                    >
                      Excluir
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
} 