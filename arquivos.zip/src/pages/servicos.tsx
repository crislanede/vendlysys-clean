import { useEffect, useMemo, useState } from "react";
import type { ChangeEvent } from "react";
import * as XLSX from "xlsx";
import { supabase } from "../lib/supabase";

import PageHeader from "../components/ui/PageHeader";
import SectionCard from "../components/ui/SectionCard";
import PrimaryButton from "../components/ui/PrimaryButton";
import EmptyState from "../components/ui/EmptyState";

type Servico = {
  id: string;
  nome: string;
  categoria: string | null;
  preco: number | null;
  preco_promocional: number | null;
  preco_descricao: string | null;
  duracao_padrao_minutos: number | null;
  ativo: boolean;
};

type LinhaImportacao = {
  nome?: string;
  categoria?: string;
  valor?: string | number;
  preco_promocional?: string | number;
  duracao_minutos?: string | number;
  preco_descricao?: string;
  ativo?: string | boolean;
};

type ErroImportacao = {
  linha: number;
  motivo: string;
};

const categorias = [
  "Manicure e Pedicure",
  "Nail Design",
  "Alongamento",
  "Spa",
  "Sobrancelhas",
  "Cílios",
  "Pele",
  "Calista",
];

export default function ServicosPage() {
  const [servicos, setServicos] = useState<Servico[]>([]);
  const [loading, setLoading] = useState(true);
  const [importando, setImportando] = useState(false);

  const [nome, setNome] = useState("");
  const [categoria, setCategoria] = useState("");
  const [preco, setPreco] = useState("");
  const [precoPromocional, setPrecoPromocional] = useState("");
  const [precoDescricao, setPrecoDescricao] = useState("");
  const [duracao, setDuracao] = useState("60");
  const [ativo, setAtivo] = useState(true);

  const [mostrarFormulario, setMostrarFormulario] = useState(false);
  const [editandoId, setEditandoId] = useState<string | null>(null);

  const [resumoImportacao, setResumoImportacao] = useState<{
    sucesso: number;
    erros: ErroImportacao[];
  } | null>(null);

  useEffect(() => {
    carregarServicos();
  }, []);

  async function carregarServicos() {
    setLoading(true);

    const { data, error } = await supabase
      .from("servicos")
      .select("*")
      .order("nome", { ascending: true });

    if (error) {
      console.error("Erro ao carregar serviços:", error);
      setServicos([]);
      setLoading(false);
      return;
    }

    setServicos((data || []) as Servico[]);
    setLoading(false);
  }

  function limparFormulario() {
    setNome("");
    setCategoria("");
    setPreco("");
    setPrecoPromocional("");
    setPrecoDescricao("");
    setDuracao("60");
    setAtivo(true);
    setEditandoId(null);
    setMostrarFormulario(false);
  }

  async function salvarServico(e: React.FormEvent) {
    e.preventDefault();

    if (!nome.trim() || !preco) {
      alert("Preencha nome e preço.");
      return;
    }

    const payload = {
      nome: nome.trim(),
      categoria: categoria.trim() || null,
      preco: Number(preco),
      preco_promocional: precoPromocional ? Number(precoPromocional) : null,
      preco_descricao: precoDescricao.trim() || null,
      duracao_padrao_minutos: duracao ? Number(duracao) : 60,
      ativo,
    };

    if (editandoId) {
      const { error } = await supabase
        .from("servicos")
        .update(payload)
        .eq("id", editandoId);

      if (error) {
        console.error("Erro ao atualizar serviço:", error);
        alert("Erro ao atualizar serviço.");
        return;
      }

      limparFormulario();
      await carregarServicos();
      return;
    }

    const { error } = await supabase.from("servicos").insert([payload]);

    if (error) {
      console.error("Erro ao salvar serviço:", error);
      alert("Erro ao salvar serviço.");
      return;
    }

    limparFormulario();
    await carregarServicos();
  }

  function editarServico(item: Servico) {
    setNome(item.nome || "");
    setCategoria(item.categoria || "");
    setPreco(item.preco != null ? String(item.preco) : "");
    setPrecoPromocional(
      item.preco_promocional != null ? String(item.preco_promocional) : ""
    );
    setPrecoDescricao(item.preco_descricao || "");
    setDuracao(
      item.duracao_padrao_minutos != null
        ? String(item.duracao_padrao_minutos)
        : "60"
    );
    setAtivo(item.ativo);
    setEditandoId(item.id);
    setMostrarFormulario(true);
  }

  async function toggleAtivo(id: string, ativoAtual: boolean) {
    const { error } = await supabase
      .from("servicos")
      .update({ ativo: !ativoAtual })
      .eq("id", id);

    if (error) {
      console.error("Erro ao atualizar status do serviço:", error);
      alert("Erro ao atualizar serviço.");
      return;
    }

    await carregarServicos();
  }

  function formatarMoeda(valor: number | null | undefined) {
    return Number(valor || 0).toLocaleString("pt-BR", {
      style: "currency",
      currency: "BRL",
    });
  }

  function baixarModelo() {
    window.open("/modelo_servicos.xlsx", "_blank");
  }

  function normalizarTexto(valor: unknown) {
    return String(valor || "").trim();
  }

  function normalizarBoolean(valor: unknown) {
    const texto = String(valor || "")
      .trim()
      .toLowerCase();

    if (!texto) return true;
    if (["sim", "s", "true", "1", "ativo"].includes(texto)) return true;
    if (["nao", "não", "n", "false", "0", "inativo"].includes(texto)) return false;
    return null;
  }

  function normalizarNumero(valor: unknown) {
    if (valor === null || valor === undefined || valor === "") return null;

    const texto = String(valor).trim().replace(/\./g, "").replace(",", ".");
    const numero = Number(texto);

    if (Number.isNaN(numero)) return null;
    return numero;
  }

  const chavesExistentes = useMemo(() => {
    return new Set(
      servicos.map((item) =>
        `${(item.nome || "").trim().toLowerCase()}|${(item.categoria || "")
          .trim()
          .toLowerCase()}`
      )
    );
  }, [servicos]);

  async function importarArquivo(e: ChangeEvent<HTMLInputElement>) {
    const arquivo = e.target.files?.[0];
    if (!arquivo) return;

    setImportando(true);
    setResumoImportacao(null);

    try {
      const buffer = await arquivo.arrayBuffer();
      const workbook = XLSX.read(buffer, { type: "array" });

      const nomeAba =
        workbook.SheetNames.find(
          (nomeSheet) => nomeSheet.toLowerCase() === "serviços"
        ) ||
        workbook.SheetNames.find(
          (nomeSheet) => nomeSheet.toLowerCase() === "servicos"
        ) ||
        workbook.SheetNames[0];

      const worksheet = workbook.Sheets[nomeAba];
      const linhas = XLSX.utils.sheet_to_json<LinhaImportacao>(worksheet, {
        defval: "",
      });

      if (!linhas.length) {
        alert("O arquivo está vazio.");
        setImportando(false);
        e.target.value = "";
        return;
      }

      const erros: ErroImportacao[] = [];
      const payloadValido: Array<{
        nome: string;
        categoria: string | null;
        preco: number;
        preco_promocional: number | null;
        preco_descricao: string | null;
        duracao_padrao_minutos: number;
        ativo: boolean;
      }> = [];

      const chavesArquivo = new Set<string>();

      linhas.forEach((linha, index) => {
        const numeroLinha = index + 2;

        const nomeServico = normalizarTexto(linha.nome);
        const categoriaServico = normalizarTexto(linha.categoria);
        const valorServico = normalizarNumero(linha.valor);
        const valorPromocional = normalizarNumero(linha.preco_promocional);
        const duracaoServico = normalizarNumero(linha.duracao_minutos);
        const descricaoPreco = normalizarTexto(linha.preco_descricao);
        const ativoNormalizado = normalizarBoolean(linha.ativo);

        if (!nomeServico) {
          erros.push({
            linha: numeroLinha,
            motivo: "Nome do serviço é obrigatório.",
          });
          return;
        }

        if (valorServico === null || valorServico <= 0) {
          erros.push({
            linha: numeroLinha,
            motivo: "Valor deve ser preenchido e maior que zero.",
          });
          return;
        }

        if (duracaoServico !== null && duracaoServico <= 0) {
          erros.push({
            linha: numeroLinha,
            motivo: "Duração deve ser maior que zero.",
          });
          return;
        }

        if (ativoNormalizado === null) {
          erros.push({
            linha: numeroLinha,
            motivo: "Campo ativo deve ser SIM ou NÃO.",
          });
          return;
        }

        const chave = `${nomeServico.toLowerCase()}|${categoriaServico.toLowerCase()}`;

        if (chavesExistentes.has(chave)) {
          erros.push({
            linha: numeroLinha,
            motivo: "Serviço já existe na base.",
          });
          return;
        }

        if (chavesArquivo.has(chave)) {
          erros.push({
            linha: numeroLinha,
            motivo: "Serviço duplicado dentro da própria planilha.",
          });
          return;
        }

        chavesArquivo.add(chave);

        payloadValido.push({
          nome: nomeServico,
          categoria: categoriaServico || null,
          preco: valorServico,
          preco_promocional:
            valorPromocional && valorPromocional > 0 ? valorPromocional : null,
          preco_descricao: descricaoPreco || null,
          duracao_padrao_minutos:
            duracaoServico && duracaoServico > 0 ? duracaoServico : 60,
          ativo: ativoNormalizado ?? true,
        });
      });

      if (payloadValido.length > 0) {
        const { error } = await supabase.from("servicos").insert(payloadValido);

        if (error) {
          console.error("Erro ao importar serviços:", error);
          alert("Erro ao importar serviços.");
          setImportando(false);
          e.target.value = "";
          return;
        }
      }

      setResumoImportacao({
        sucesso: payloadValido.length,
        erros,
      });

      await carregarServicos();
    } catch (error) {
      console.error("Erro ao processar arquivo:", error);
      alert("Não foi possível ler o arquivo. Verifique se está no modelo correto.");
    } finally {
      setImportando(false);
      e.target.value = "";
    }
  }

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Catálogo"
        title="Serviços"
        description="Gerencie categorias, preços, promoções, duração e importação em lote dos atendimentos."
        action={
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={baixarModelo}
              className="rounded-2xl border border-slate-300 px-4 py-2 text-sm font-medium text-slate-700 transition hover:bg-slate-50"
            >
              Baixar modelo
            </button>

            <label className="cursor-pointer rounded-2xl border border-slate-300 px-4 py-2 text-sm font-medium text-slate-700 transition hover:bg-slate-50">
              {importando ? "Importando..." : "Importar serviços"}
              <input
                type="file"
                accept=".xlsx,.xls,.csv"
                onChange={importarArquivo}
                className="hidden"
                disabled={importando}
              />
            </label>

            <PrimaryButton
              type="button"
              onClick={() => {
                if (mostrarFormulario) {
                  limparFormulario();
                } else {
                  setMostrarFormulario(true);
                }
              }}
            >
              {mostrarFormulario ? "Fechar" : "Novo serviço"}
            </PrimaryButton>
          </div>
        }
      />

      {resumoImportacao && (
        <SectionCard
          title="Resultado da importação"
          description={`${resumoImportacao.sucesso} serviço(s) importado(s) com sucesso`}
        >
          {resumoImportacao.erros.length === 0 ? (
            <p className="text-sm text-emerald-700">
              Importação concluída sem erros.
            </p>
          ) : (
            <div className="space-y-2">
              <p className="text-sm text-amber-700">
                Algumas linhas não foram importadas:
              </p>

              <div className="max-h-60 space-y-2 overflow-auto rounded-2xl border border-slate-200 p-3">
                {resumoImportacao.erros.map((erro, index) => (
                  <p key={`${erro.linha}-${index}`} className="text-sm text-slate-600">
                    <span className="font-medium">Linha {erro.linha}:</span> {erro.motivo}
                  </p>
                ))}
              </div>
            </div>
          )}
        </SectionCard>
      )}

      {mostrarFormulario && (
        <SectionCard
          title={editandoId ? "Editar serviço" : "Novo serviço"}
          description="Cadastre ou ajuste as informações do serviço"
        >
          <form
            onSubmit={salvarServico}
            className="grid grid-cols-1 gap-3 md:grid-cols-2"
          >
            <input
              placeholder="Nome do serviço"
              value={nome}
              onChange={(e) => setNome(e.target.value)}
              className="rounded-2xl border border-slate-200 p-3"
            />

            <select
              value={categoria}
              onChange={(e) => setCategoria(e.target.value)}
              className="rounded-2xl border border-slate-200 p-3"
            >
              <option value="">Selecione a categoria (opcional)</option>
              {categorias.map((item) => (
                <option key={item} value={item}>
                  {item}
                </option>
              ))}
            </select>

            <input
              type="number"
              step="0.01"
              placeholder="Preço"
              value={preco}
              onChange={(e) => setPreco(e.target.value)}
              className="rounded-2xl border border-slate-200 p-3"
            />

            <input
              type="number"
              step="0.01"
              placeholder="Preço promocional"
              value={precoPromocional}
              onChange={(e) => setPrecoPromocional(e.target.value)}
              className="rounded-2xl border border-slate-200 p-3"
            />

            <input
              placeholder="Descrição do preço (ex: a partir de R$20)"
              value={precoDescricao}
              onChange={(e) => setPrecoDescricao(e.target.value)}
              className="rounded-2xl border border-slate-200 p-3 md:col-span-2"
            />

            <input
              type="number"
              min="1"
              placeholder="Duração em minutos"
              value={duracao}
              onChange={(e) => setDuracao(e.target.value)}
              className="rounded-2xl border border-slate-200 p-3"
            />

            <div className="flex items-center">
              <label className="flex items-center gap-2 rounded-2xl border border-slate-200 p-3 text-sm text-slate-700">
                <input
                  type="checkbox"
                  checked={ativo}
                  onChange={(e) => setAtivo(e.target.checked)}
                />
                Serviço ativo
              </label>
            </div>

            <div className="md:col-span-2">
              <PrimaryButton type="submit">
                {editandoId ? "Atualizar" : "Salvar"}
              </PrimaryButton>
            </div>
          </form>
        </SectionCard>
      )}

      {loading ? (
        <SectionCard>
          <p>Carregando...</p>
        </SectionCard>
      ) : servicos.length === 0 ? (
        <EmptyState
          title="Nenhum serviço cadastrado"
          description="Cadastre o primeiro serviço ou importe uma planilha para começar."
        />
      ) : (
        <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
          {servicos.map((item) => (
            <SectionCard key={item.id}>
              <div className="flex items-start justify-between gap-4">
                <div>
                  <p className="text-lg font-semibold text-slate-800">
                    {item.nome}
                  </p>

                  <p className="mt-1 text-sm text-slate-500">
                    {item.categoria || "Sem categoria"}
                  </p>

                  <p className="mt-3 text-sm text-slate-500">
                    Preço:{" "}
                    <span className="font-medium text-slate-700">
                      {formatarMoeda(item.preco)}
                    </span>
                  </p>

                  <p className="text-sm text-slate-500">
                    Promocional:{" "}
                    <span className="font-medium text-slate-700">
                      {item.preco_promocional
                        ? formatarMoeda(item.preco_promocional)
                        : "--"}
                    </span>
                  </p>

                  {item.preco_descricao && (
                    <p className="text-sm text-slate-500">
                      {item.preco_descricao}
                    </p>
                  )}

                  <p className="mt-2 text-sm text-slate-500">
                    Duração: {item.duracao_padrao_minutos || 0} min
                  </p>

                  <div className="mt-3">
                    <span
                      className={`rounded-full px-3 py-1 text-xs font-medium ${
                        item.ativo
                          ? "bg-emerald-100 text-emerald-700"
                          : "bg-slate-200 text-slate-600"
                      }`}
                    >
                      {item.ativo ? "Ativo" : "Inativo"}
                    </span>
                  </div>
                </div>

                <div className="flex shrink-0 flex-col items-end gap-2">
                  <button
                    type="button"
                    onClick={() => editarServico(item)}
                    className="text-sm font-medium text-blue-600"
                  >
                    Editar
                  </button>

                  <button
                    type="button"
                    onClick={() => toggleAtivo(item.id, item.ativo)}
                    className="text-sm font-medium text-orange-600"
                  >
                    {item.ativo ? "Inativar" : "Ativar"}
                  </button>
                </div>
              </div>
            </SectionCard>
          ))}
        </div>
      )}
    </div>
  );
}