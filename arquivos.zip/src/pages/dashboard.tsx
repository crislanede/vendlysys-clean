import { useEffect, useState } from "react";
import { supabase } from "../lib/supabase";
import PageHeader from "../components/ui/PageHeader";
import SectionCard from "../components/ui/SectionCard";
import EmptyState from "../components/ui/EmptyState";

type Agendamento = {
  id: string;
  cliente: string;
  servico: string;
  horario: string;
  status: string;
  data: string;
  valor: number | null;
};

export default function DashboardPage() {
  const [agendamentosHoje, setAgendamentosHoje] = useState(0);
  const [clientes, setClientes] = useState(0);
  const [faturamento, setFaturamento] = useState(0);
  const [servicos, setServicos] = useState(0);
  const [proximos, setProximos] = useState<Agendamento[]>([]);
  const [resumo, setResumo] = useState({
    confirmado: 0,
    pendente: 0,
    cancelado: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    carregarDashboard();
  }, []);

  async function carregarDashboard() {
    setLoading(true);

    const hoje = new Date().toISOString().split("T")[0];
    const inicioMes = new Date(
      new Date().getFullYear(),
      new Date().getMonth(),
      1
    )
      .toISOString()
      .split("T")[0];

    const { data: agHoje } = await supabase
      .from("agendamentos")
      .select("*")
      .eq("data", hoje);

    setAgendamentosHoje(agHoje?.length || 0);

    const { count: totalClientes } = await supabase
      .from("clientes")
      .select("*", { count: "exact", head: true });

    setClientes(totalClientes || 0);

    const { count: totalServicos } = await supabase
      .from("servicos")
      .select("*", { count: "exact", head: true });

    setServicos(totalServicos || 0);

    const { data: financeiro } = await supabase
      .from("financeiro")
      .select("valor, tipo, status")
      .gte("data_lancamento", inicioMes);

    const total =
      financeiro?.reduce((acc, item) => {
        if (item.tipo === "entrada" && item.status !== "cancelado") {
          return acc + Number(item.valor || 0);
        }
        return acc;
      }, 0) || 0;

    setFaturamento(total);

    const { data: proximosData } = await supabase
      .from("agendamentos")
      .select("*")
      .gte("data", hoje)
      .order("data", { ascending: true })
      .order("horario", { ascending: true })
      .limit(5);

    setProximos((proximosData || []) as Agendamento[]);

    const confirmado =
      agHoje?.filter((a) => a.status === "confirmado").length || 0;
    const pendente =
      agHoje?.filter((a) => a.status === "pendente").length || 0;
    const cancelado =
      agHoje?.filter((a) => a.status === "cancelado").length || 0;

    setResumo({ confirmado, pendente, cancelado });
    setLoading(false);
  }

  function formatarMoeda(valor: number) {
    return valor.toLocaleString("pt-BR", {
      style: "currency",
      currency: "BRL",
    });
  }

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Visão geral"
        title="Dashboard"
        description="Acompanhe o desempenho da operação em tempo real."
      />

      {loading ? (
        <SectionCard>
          <p>Carregando...</p>
        </SectionCard>
      ) : (
        <>
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
            <Card
              title="Agendamentos hoje"
              value={String(agendamentosHoje)}
              subtitle="Movimento do dia"
            />
            <Card
              title="Clientes ativos"
              value={String(clientes)}
              subtitle="Base atual"
            />
            <Card
              title="Faturamento do mês"
              value={formatarMoeda(faturamento)}
              subtitle="Receita acumulada"
            />
            <Card
              title="Serviços cadastrados"
              value={String(servicos)}
              subtitle="Catálogo disponível"
            />
          </div>

          <div className="grid grid-cols-1 gap-4 xl:grid-cols-3">
            <SectionCard
              title="Próximos agendamentos"
              description="Atendimentos previstos"
            >
              <div className="space-y-3">
                {proximos.length === 0 ? (
                  <EmptyState
                    title="Nenhum agendamento encontrado"
                    description="Os próximos agendamentos aparecerão aqui."
                  />
                ) : (
                  proximos.map((a) => (
                    <div
                      key={a.id}
                      className="flex items-center justify-between rounded-2xl border border-slate-200 p-4 transition hover:shadow-sm"
                    >
                      <div>
                        <p className="font-medium text-slate-800">{a.cliente}</p>
                        <p className="text-sm text-slate-500">{a.servico}</p>
                      </div>

                      <div className="text-right">
                        <p className="font-medium text-slate-800">{a.horario}</p>
                        <p className="text-xs text-slate-500">{a.status}</p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </SectionCard>

            <SectionCard
              title="Resumo rápido"
              description="Situação dos agendamentos do dia"
            >
              <div className="space-y-3">
                <ResumoItem label="Confirmados" value={resumo.confirmado} />
                <ResumoItem label="Pendentes" value={resumo.pendente} />
                <ResumoItem label="Cancelados" value={resumo.cancelado} />
              </div>
            </SectionCard>
          </div>
        </>
      )}
    </div>
  );
}

function Card({
  title,
  value,
  subtitle,
}: {
  title: string;
  value: string;
  subtitle: string;
}) {
  return (
    <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm transition hover:shadow-md">
      <p className="text-sm text-slate-500">{title}</p>
      <h2 className="mt-2 text-3xl font-bold tracking-tight text-slate-800">
        {value}
      </h2>
      <p className="mt-3 text-xs text-slate-400">{subtitle}</p>
    </div>
  );
}

function ResumoItem({
  label,
  value,
}: {
  label: string;
  value: number;
}) {
  return (
    <div className="flex items-center justify-between rounded-2xl border border-slate-200 px-4 py-3">
      <span className="text-sm text-slate-500">{label}</span>
      <span className="font-semibold text-slate-800">{value}</span>
    </div>
  );
}