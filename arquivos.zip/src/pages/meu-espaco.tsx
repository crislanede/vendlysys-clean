import { useEffect, useState } from "react";
import { supabase } from "../lib/supabase";
import AssinaturaCanvas from "../components/AssinaturaCanvas";
import { gerarHash } from "../lib/hash";
import { gerarPdfBlob } from "../lib/pdfAnamnese";
import { uploadPdfAnamnese } from "../lib/uploadAnamnese";
import {
  abrirWhatsapp,
  montarMensagemPdfAnamnese,
} from "../lib/whatsapp";

type Agendamento = {
  id: string;
  cliente: string;
  cliente_id?: string | null;
  telefone?: string | null;
  servico: string;
  profissional: string;
  data: string;
  horario: string;
  status: string;
  token_cliente: string;
  empresa_id?: string | null;
};

export default function MeuEspaco() {
  const [agendamento, setAgendamento] = useState<Agendamento | null>(null);
  const [respostas] = useState<Record<string, string>>({});
  const [assinatura, setAssinatura] = useState<string | null>(null);
  const [aceiteTermo, setAceiteTermo] = useState(false);
  const [salvandoAnamnese, setSalvandoAnamnese] = useState(false);

  const [pdfUrlGerado, setPdfUrlGerado] = useState("");
  const [empresaNome, setEmpresaNome] = useState("Seu estabelecimento");
  const [telefoneCliente, setTelefoneCliente] = useState("");

  useEffect(() => {
    void carregarDados();
  }, []);

  async function carregarDados() {
    const params = new URLSearchParams(window.location.search);
    const token = params.get("token");

    if (!token) return;

    const { data, error } = await supabase
      .from("agendamentos")
      .select("*")
      .eq("token_cliente", token)
      .maybeSingle();

    if (error || !data) {
      console.error("Erro ao carregar agendamento:", error);
      return;
    }

    setAgendamento(data);

    await carregarEmpresa(data.empresa_id || null);
    await carregarTelefoneCliente(data);
  }

  async function carregarEmpresa(empresaId: string | null) {
    if (!empresaId) return;

    const { data } = await supabase
      .from("configuracoes")
      .select("nome_empresa, nome_fantasia")
      .eq("empresa_id", empresaId)
      .maybeSingle();

    setEmpresaNome(
      data?.nome_fantasia || data?.nome_empresa || "Seu estabelecimento"
    );
  }

  async function carregarTelefoneCliente(ag: Agendamento) {
    if (ag.telefone) {
      setTelefoneCliente(ag.telefone);
      return;
    }

    const { data } = await supabase
      .from("clientes")
      .select("telefone")
      .eq("id", ag.cliente_id)
      .maybeSingle();

    setTelefoneCliente(data?.telefone || "");
  }

  async function salvarAnamnese() {
    if (!agendamento) return;

    if (!aceiteTermo) {
      alert("Você precisa aceitar o termo.");
      return;
    }

    if (!assinatura) {
      alert("Assinatura obrigatória.");
      return;
    }

    setSalvandoAnamnese(true);

    const dataAssinatura = new Date().toISOString();
const ip = "0.0.0.0";

const hash = await gerarHash(
  JSON.stringify(respostas) + assinatura
);

    const { data: anamnese, error } = await supabase
      .from("anamneses_clientes")
      .insert({
        cliente_id: agendamento.cliente_id,
        cliente_nome: agendamento.cliente,
        aceita_termo: true,
        preenchido: true,
        preenchido_em: dataAssinatura,
        assinatura_base64: assinatura,
        hash_assinatura: hash,
        ip_assinatura: ip,
        assinado_em: dataAssinatura,
      })
      .select()
      .single();

    if (error) {
      console.error(error);
      setSalvandoAnamnese(false);
      return;
    }

  const pdfBlob = gerarPdfBlob({
  empresaNome,
  clienteNome: agendamento.cliente,
  servico: agendamento.servico,
  profissional: agendamento.profissional,
  dataAgendamento: agendamento.data,
  horarioAgendamento: agendamento.horario,
  respostas,
  assinatura,
  hash,
  ip,
  data: dataAssinatura,
});
    const urlPdf = await uploadPdfAnamnese(
      pdfBlob,
      agendamento.cliente,
      anamnese.id
    );

    await supabase
      .from("anamneses_clientes")
      .update({ pdf_url: urlPdf })
      .eq("id", anamnese.id);

    setPdfUrlGerado(urlPdf);
    setSalvandoAnamnese(false);
  }

  function enviarPdfWhatsapp() {
    if (!agendamento || !pdfUrlGerado) return;

    const mensagem = montarMensagemPdfAnamnese({
      cliente: agendamento.cliente,
      empresa: empresaNome,
      pdfUrl: pdfUrlGerado,
    });

    abrirWhatsapp(telefoneCliente, mensagem);
  }

  if (!agendamento) {
    return <p className="p-6">Carregando...</p>;
  }

  return (
    <div className="p-6 space-y-6 max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold">Meu Espaço</h1>

      {/* TERMO */}
      <div className="bg-white p-4 rounded-xl shadow">
        <p className="text-sm text-slate-600">
          Declaro que as informações são verdadeiras.
        </p>

        <label className="flex gap-2 mt-2">
          <input
            type="checkbox"
            checked={aceiteTermo}
            onChange={(e) => setAceiteTermo(e.target.checked)}
          />
          Aceito o termo
        </label>
      </div>

      {/* ASSINATURA */}
      <div className="bg-white p-4 rounded-xl shadow">
        <p className="font-medium mb-2">Assinatura</p>
        <AssinaturaCanvas onChange={setAssinatura} />
      </div>

      {/* BOTÕES */}
      <div className="flex gap-3 flex-wrap">
        <button
          onClick={() => void salvarAnamnese()}
          disabled={salvandoAnamnese}
          className="bg-blue-600 text-white px-4 py-2 rounded-xl"
        >
          {salvandoAnamnese ? "Salvando..." : "Salvar Anamnese"}
        </button>

        {pdfUrlGerado && (
          <button
            onClick={enviarPdfWhatsapp}
            className="bg-green-600 text-white px-4 py-2 rounded-xl"
          >
            Enviar no WhatsApp
          </button>
        )}
      </div>
    </div>
  );
}