import { useEffect, useMemo, useState } from "react";
import { supabase } from "../lib/supabase";

import PageHeader from "../components/ui/PageHeader";
import SectionCard from "../components/ui/SectionCard";
import PrimaryButton from "../components/ui/PrimaryButton";
import SecondaryButton from "../components/ui/SecondaryButton";
import EmptyState from "../components/ui/EmptyState";

type Lancamento = {
  id: string;
  tipo: string;
  descricao: string;
  valor: number;
  data_lancamento: string;
  status: string;
  cliente: string | null;
  profissional: string | null;
  servico: string | null;
  agendamento_id: string | null;
  observacoes: string | null;
  created_at?: string;
};

type Despesa = {
  id: string;
  descricao: string;
  valor: number;
  categoria: string | null;
  data: string;
  observacao: string | null;
};

export default function FinanceiroPage() {
  const [lancamentos, setLancamentos] = useState<Lancamento[]>([]);
  const [despesas, setDespesas] = useState<Despesa[]>([]);
  const [loading, setLoading] = useState(true);

  const [tipo, setTipo] = useState("entrada");
  const [descricao, setDescricao] = useState("");
  const [valor, setValor] = useState("");
  const [dataLancamento, setDataLancamento] = useState("");
  const [status, setStatus] = useState("pendente");
  const [cliente, setCliente] = useState("");
  const [profissional, setProfissional] = useState("");
  const [servico, setServico] = useState("");
  const [observacoes, setObservacoes] = useState("");

  const [mostrarFormulario, setMostrarFormulario] = useState(false);
  const [editandoId, setEditandoId] = useState<string | null>(null);

  const [filtroDataInicio, setFiltroDataInicio] = useState("");
  const [filtroDataFim, setFiltroDataFim] = useState("");
  const [filtroTipo, setFiltroTipo] = useState("");
  const [filtroStatus, setFiltroStatus] = useState("");

  useEffect(() => {
    carregarDados();
  }, []);

  async function carregarDados() {
    setLoading(true);

    const { data: dataFinanceiro, error: errorFinanceiro } = await supabase
      .from("financeiro")
      .select("*")
      .order("data_lancamento", { ascending: false })
      .order("created_at", { ascending: false });

    const { data: dataDespesas, error: errorDespesas } = await supabase
      .from("despesas")
      .select("*")
      .order("data", { ascending: false });

    if (errorFinanceiro) {
      console.error("Erro ao carregar financeiro:", errorFinanceiro);
      setLancamentos([]);
    } else {
      setLancamentos((dataFinanceiro || []) as Lancamento[]);
    }

    if (errorDespesas) {
      console.error("Erro ao carregar despesas:", errorDespesas);
      setDespesas([]);
    } else {
      setDespesas((dataDespesas || []) as Despesa[]);
    }

    setLoading(false);
  }

  function limparFormulario() {
    setTipo("entrada");
    setDescricao("");
    setValor("");
    setDataLancamento("");
    setStatus("pendente");
    setCliente("");
    setProfissional("");
    setServico("");
    setObservacoes("");
    setEditandoId(null);
    setMostrarFormulario(false);
  }

  async function salvarLancamento(e: React.FormEvent) {
    e.preventDefault();

    if (!descricao || !valor || !dataLancamento) {
      alert("Preencha descrição, valor e data.");
      return;
    }

    const payload = {
      tipo,
      descricao,
      valor: Number(valor),
      data_lancamento: dataLancamento,
      status,
      cliente: cliente || null,
      profissional: profissional || null,
      servico: servico || null,
      observacoes: observacoes || null,
    };

    if (editandoId) {
      const { error } = await supabase
        .from("financeiro")
        .update(payload)
        .eq("id", editandoId);

      if (error) {
        console.error("Erro ao atualizar lançamento:", error);
        alert("Erro ao atualizar lançamento.");
        return;
      }

      limparFormulario();
      await carregarDados();
      return;
    }

    const { error } = await supabase.from("financeiro").insert([payload]);

    if (error) {
      console.error("Erro ao salvar lançamento:", error);
      alert("Erro ao salvar lançamento.");
      return;
    }

    limparFormulario();
    await carregarDados();
  }

  function editarLancamento(item: Lancamento) {
    setTipo(item.tipo);
    setDescricao(item.descricao);
    setValor(String(item.valor));
    setDataLancamento(item.data_lancamento);
    setStatus(item.status);
    setCliente(item.cliente || "");
    setProfissional(item.profissional || "");
    setServico(item.servico || "");
    setObservacoes(item.observacoes || "");
    setEditandoId(item.id);
    setMostrarFormulario(true);
  }

  async function excluirLancamento(id: string) {
    const confirmar = window.confirm("Excluir lançamento?");
    if (!confirmar) return;

    const { error } = await supabase.from("financeiro").delete().eq("id", id);

    if (error) {
      console.error("Erro ao excluir lançamento:", error);
      alert("Erro ao excluir lançamento.");
      return;
    }

    await carregarDados();
  }

  async function marcarComoPago(id: string) {
    const { error } = await supabase
      .from("financeiro")
      .update({ status: "pago" })
      .eq("id", id);

    if (error) {
      console.error("Erro ao marcar como pago:", error);
      alert("Erro ao marcar como pago.");
      return;
    }

    await carregarDados();
  }

  function dentroDoPeriodo(dataStr: string) {
    if (filtroDataInicio && dataStr < filtroDataInicio) return false;
    if (filtroDataFim && dataStr > filtroDataFim) return false;
    return true;
  }

  const lancamentosFiltrados = useMemo(() => {
    return lancamentos.filter((item) => {
      const batePeriodo = dentroDoPeriodo(item.data_lancamento);
      const bateTipo = filtroTipo ? item.tipo === filtroTipo : true;
      const bateStatus = filtroStatus ? item.status === filtroStatus : true;

      return batePeriodo && bateTipo && bateStatus;
    });
  }, [lancamentos, filtroDataInicio, filtroDataFim, filtroTipo, filtroStatus]);

  const despesasFiltradas = useMemo(() => {
    return despesas.filter((item) => dentroDoPeriodo(item.data));
  }, [despesas, filtroDataInicio, filtroDataFim]);

  const totalReceitas = lancamentosFiltrados
    .filter((item) => item.tipo === "entrada" && item.status !== "cancelado")
    .reduce((acc, item) => acc + Number(item.valor), 0);

  const totalSaidasFinanceiro = lancamentosFiltrados
    .filter((item) => item.tipo === "saida" && item.status !== "cancelado")
    .reduce((acc, item) => acc + Number(item.valor), 0);

  const totalDespesas = despesasFiltradas.reduce(
    (acc, item) => acc + Number(item.valor || 0),
    0
  );

  const lucroLiquido = totalReceitas - totalSaidasFinanceiro - totalDespesas;

  function formatarMoeda(valor: number) {
    return valor.toLocaleString("pt-BR", {
      style: "currency",
      currency: "BRL",
    });
  }

  function formatarData(data: string) {
    return new Date(`${data}T00:00:00`).toLocaleDateString("pt-BR");
  }

  function limparFiltros() {
    setFiltroDataInicio("");
    setFiltroDataFim("");
    setFiltroTipo("");
    setFiltroStatus("");
  }

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Gestão"
        title="Financeiro"
        description="Controle receitas, saídas, despesas e lucro líquido."
        action={
          <PrimaryButton
            type="button"
            onClick={() => {
              if (mostrarFormulario) {
                limparFormulario();
              } else {
                setMostrarFormulario(true);
              }
            }}
          >
            {mostrarFormulario ? "Fechar" : "Novo lançamento"}
          </PrimaryButton>
        }
      />

      <div className="grid grid-cols-1 gap-4 md:grid-cols-4">
        <ResumoCard
          title="Receitas"
          value={formatarMoeda(totalReceitas)}
          valueClassName="text-emerald-600"
        />
        <ResumoCard
          title="Saídas financeiras"
          value={formatarMoeda(totalSaidasFinanceiro)}
          valueClassName="text-orange-600"
        />
        <ResumoCard
          title="Despesas"
          value={formatarMoeda(totalDespesas)}
          valueClassName="text-red-600"
        />
        <ResumoCard
          title="Lucro líquido"
          value={formatarMoeda(lucroLiquido)}
          valueClassName={lucroLiquido >= 0 ? "text-emerald-700" : "text-red-700"}
        />
      </div>

      <SectionCard title="Filtros" description="Refine a visualização do período">
        <div className="grid grid-cols-1 gap-3 md:grid-cols-5">
          <input
            type="date"
            value={filtroDataInicio}
            onChange={(e) => setFiltroDataInicio(e.target.value)}
            className="rounded-2xl border border-slate-200 p-3"
          />

          <input
            type="date"
            value={filtroDataFim}
            onChange={(e) => setFiltroDataFim(e.target.value)}
            className="rounded-2xl border border-slate-200 p-3"
          />

          <select
            value={filtroTipo}
            onChange={(e) => setFiltroTipo(e.target.value)}
            className="rounded-2xl border border-slate-200 p-3"
          >
            <option value="">Todos os tipos</option>
            <option value="entrada">entrada</option>
            <option value="saida">saida</option>
          </select>

          <select
            value={filtroStatus}
            onChange={(e) => setFiltroStatus(e.target.value)}
            className="rounded-2xl border border-slate-200 p-3"
          >
            <option value="">Todos os status</option>
            <option value="pendente">pendente</option>
            <option value="pago">pago</option>
            <option value="cancelado">cancelado</option>
          </select>

          <SecondaryButton type="button" onClick={limparFiltros}>
            Limpar filtros
          </SecondaryButton>
        </div>
      </SectionCard>

      {mostrarFormulario && (
        <SectionCard
          title={editandoId ? "Editar lançamento" : "Novo lançamento"}
          description="Cadastre manualmente entradas ou saídas"
        >
          <form onSubmit={salvarLancamento} className="grid grid-cols-1 gap-3 md:grid-cols-2">
            <select
              value={tipo}
              onChange={(e) => setTipo(e.target.value)}
              className="rounded-2xl border border-slate-200 p-3"
            >
              <option value="entrada">entrada</option>
              <option value="saida">saida</option>
            </select>

            <input
              placeholder="Descrição"
              value={descricao}
              onChange={(e) => setDescricao(e.target.value)}
              className="rounded-2xl border border-slate-200 p-3"
            />

            <input
              type="number"
              step="0.01"
              placeholder="Valor"
              value={valor}
              onChange={(e) => setValor(e.target.value)}
              className="rounded-2xl border border-slate-200 p-3"
            />

            <input
              type="date"
              value={dataLancamento}
              onChange={(e) => setDataLancamento(e.target.value)}
              className="rounded-2xl border border-slate-200 p-3"
            />

            <select
              value={status}
              onChange={(e) => setStatus(e.target.value)}
              className="rounded-2xl border border-slate-200 p-3"
            >
              <option value="pendente">pendente</option>
              <option value="pago">pago</option>
              <option value="cancelado">cancelado</option>
            </select>

            <input
              placeholder="Cliente"
              value={cliente}
              onChange={(e) => setCliente(e.target.value)}
              className="rounded-2xl border border-slate-200 p-3"
            />

            <input
              placeholder="Profissional"
              value={profissional}
              onChange={(e) => setProfissional(e.target.value)}
              className="rounded-2xl border border-slate-200 p-3"
            />

            <input
              placeholder="Serviço"
              value={servico}
              onChange={(e) => setServico(e.target.value)}
              className="rounded-2xl border border-slate-200 p-3"
            />

            <textarea
              placeholder="Observações"
              value={observacoes}
              onChange={(e) => setObservacoes(e.target.value)}
              className="rounded-2xl border border-slate-200 p-3 md:col-span-2"
            />

            <div className="md:col-span-2">
              <PrimaryButton type="submit">
                {editandoId ? "Atualizar" : "Salvar"}
              </PrimaryButton>
            </div>
          </form>
        </SectionCard>
      )}

      <SectionCard title="Receitas e lançamentos" description="Movimentações da tabela financeiro">
        {loading ? (
          <p>Carregando...</p>
        ) : lancamentosFiltrados.length === 0 ? (
          <EmptyState
            title="Nenhum lançamento encontrado"
            description="Os lançamentos filtrados aparecerão aqui."
          />
        ) : (
          <div className="space-y-3">
            {lancamentosFiltrados.map((item) => (
              <div
                key={item.id}
                className="flex justify-between gap-4 rounded-2xl border border-slate-200 p-4"
              >
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <p className="font-semibold text-slate-800">{item.descricao}</p>

                    {item.agendamento_id && (
                      <span className="rounded-full bg-blue-100 px-3 py-1 text-xs font-medium text-blue-700">
                        vindo da agenda
                      </span>
                    )}
                  </div>

                  <p className="text-sm text-slate-500">
                    {item.cliente || "-"} • {item.profissional || "-"} • {item.servico || "-"}
                  </p>

                  <p className="text-sm text-slate-500">
                    {formatarData(item.data_lancamento)}
                  </p>

                  {item.observacoes && (
                    <p className="mt-1 text-sm text-slate-400">{item.observacoes}</p>
                  )}
                </div>

                <div className="text-right">
                  <p
                    className={`font-bold ${
                      item.tipo === "entrada" ? "text-emerald-600" : "text-orange-600"
                    }`}
                  >
                    {item.tipo === "entrada" ? "+" : "-"} {formatarMoeda(Number(item.valor))}
                  </p>

                  <p className="text-xs text-slate-500">{item.status}</p>

                  <div className="mt-2 flex flex-wrap justify-end gap-2">
                    {item.status !== "pago" && (
                      <button
                        type="button"
                        onClick={() => marcarComoPago(item.id)}
                        className="text-sm font-medium text-green-600"
                      >
                        Marcar como pago
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={() => editarLancamento(item)}
                      className="text-sm font-medium text-blue-600"
                    >
                      Editar
                    </button>

                    <button
                      type="button"
                      onClick={() => excluirLancamento(item.id)}
                      className="text-sm font-medium text-red-600"
                    >
                      Excluir
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </SectionCard>

      <SectionCard title="Despesas do período" description="Itens vindos da tabela despesas">
        {loading ? (
          <p>Carregando...</p>
        ) : despesasFiltradas.length === 0 ? (
          <EmptyState
            title="Nenhuma despesa encontrada"
            description="As despesas do período aparecerão aqui."
          />
        ) : (
          <div className="space-y-3">
            {despesasFiltradas.map((item) => (
              <div
                key={item.id}
                className="flex justify-between gap-4 rounded-2xl border border-slate-200 p-4"
              >
                <div>
                  <p className="font-semibold text-slate-800">{item.descricao}</p>
                  <p className="text-sm text-slate-500">
                    {item.categoria || "Sem categoria"}
                  </p>
                  <p className="text-sm text-slate-500">
                    {formatarData(item.data)}
                  </p>
                  {item.observacao && (
                    <p className="mt-1 text-sm text-slate-400">{item.observacao}</p>
                  )}
                </div>

                <div className="text-right">
                  <p className="font-bold text-red-600">
                    - {formatarMoeda(Number(item.valor))}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </SectionCard>
    </div>
  );
}

function ResumoCard({
  title,
  value,
  valueClassName,
}: {
  title: string;
  value: string;
  valueClassName?: string;
}) {
  return (
    <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
      <p className="text-sm text-slate-500">{title}</p>
      <p className={`mt-2 text-3xl font-bold ${valueClassName || "text-slate-800"}`}>
        {value}
      </p>
    </div>
  );
}