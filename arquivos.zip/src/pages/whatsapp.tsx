import { useEffect, useMemo, useState } from "react";
import { supabase } from "../lib/supabase";

import PageHeader from "../components/ui/PageHeader";
import SectionCard from "../components/ui/SectionCard";
import EmptyState from "../components/ui/EmptyState";


import {
  abrirWhatsapp,
  montarMensagemCancelamento,
  montarMensagemConfirmacao,
  montarMensagemLembrete,
  montarMensagemReagendamento,
} from "../lib/whatsapp";

type Agendamento = {
  id: string;
  cliente: string;
  telefone: string | null;
  profissional: string;
  servico: string;
  data: string;
  horario: string;
  status: string;
};

type Configuracao = {
  nome_fantasia: string | null;
  nome_empresa: string | null;
};

type TipoMensagem =
  | "confirmacao"
  | "lembrete"
  | "cancelamento"
  | "reagendamento";

export default function WhatsappPage() {
  const [agendamentos, setAgendamentos] = useState<Agendamento[]>([]);
  const [loading, setLoading] = useState(true);
  const [busca, setBusca] = useState("");
  const [tipoMensagem, setTipoMensagem] =
    useState<TipoMensagem>("confirmacao");
  const [empresa, setEmpresa] = useState("VendlySys");

  useEffect(() => {
    carregarDados();
  }, []);

  async function carregarDados() {
    setLoading(true);

    const { data: agData, error: agError } = await supabase
      .from("agendamentos")
      .select("id, cliente, profissional, servico, data, horario, status")
      .order("data", { ascending: false })
      .order("horario", { ascending: false });

    const { data: cliData, error: cliError } = await supabase
      .from("clientes")
      .select("nome, telefone");

    const { data: configData } = await supabase
      .from("configuracoes")
      .select("nome_fantasia, nome_empresa")
      .limit(1)
      .maybeSingle();

    if (agError) console.error("Erro ao carregar agendamentos:", agError);
    if (cliError) console.error("Erro ao carregar clientes:", cliError);

    const empresaNome =
      (configData as Configuracao | null)?.nome_fantasia ||
      (configData as Configuracao | null)?.nome_empresa ||
      "VendlySys";

    setEmpresa(empresaNome);

    const agendamentosComTelefone = ((agData || []) as Omit<
      Agendamento,
      "telefone"
    >[]).map((item) => {
      const cliente = (cliData || []).find((c) => c.nome === item.cliente);

      return {
        ...item,
        telefone: cliente?.telefone || null,
      };
    });

    setAgendamentos(agendamentosComTelefone);
    setLoading(false);
  }

  const agendamentosFiltrados = useMemo(() => {
    const termo = busca.toLowerCase().trim();

    return agendamentos.filter((item) => {
      if (!termo) return true;

      return (
        item.cliente.toLowerCase().includes(termo) ||
        item.profissional.toLowerCase().includes(termo) ||
        item.servico.toLowerCase().includes(termo) ||
        item.data.toLowerCase().includes(termo) ||
        item.horario.toLowerCase().includes(termo)
      );
    });
  }, [agendamentos, busca]);

  function gerarMensagem(item: Agendamento) {
    if (tipoMensagem === "confirmacao") {
      return montarMensagemConfirmacao({
        cliente: item.cliente,
        servico: item.servico,
        profissional: item.profissional,
        data: item.data,
        horario: item.horario,
        empresa,
      });
    }

    if (tipoMensagem === "lembrete") {
      return montarMensagemLembrete({
        cliente: item.cliente,
        servico: item.servico,
        profissional: item.profissional,
        data: item.data,
        horario: item.horario,
        empresa,
      });
    }

    if (tipoMensagem === "cancelamento") {
      return montarMensagemCancelamento({
        cliente: item.cliente,
        servico: item.servico,
        profissional: item.profissional,
        data: item.data,
        horario: item.horario,
        empresa,
      });
    }

    return montarMensagemReagendamento({
      cliente: item.cliente,
      servico: item.servico,
      profissional: item.profissional,
      novaData: item.data,
      novoHorario: item.horario,
      empresa,
    });
  }

  async function registrarLog(item: Agendamento, mensagem: string) {
    await supabase.from("whatsapp_logs").insert([
      {
        agendamento_id: item.id,
        cliente: item.cliente,
        telefone: item.telefone,
        tipo: tipoMensagem,
        mensagem,
        status: "enviado",
      },
    ]);
  }

  async function enviarMensagem(item: Agendamento) {
    if (!item.telefone) {
      alert("Esse cliente não possui telefone cadastrado.");
      return;
    }

    const mensagem = gerarMensagem(item);
    abrirWhatsapp(item.telefone, mensagem);
    await registrarLog(item, mensagem);
  }

  function formatarData(data: string) {
    return new Date(`${data}T00:00:00`).toLocaleDateString("pt-BR");
  }

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Comunicação"
        title="WhatsApp"
        description="Envie mensagens automáticas para seus clientes"
      />

      <SectionCard title="Filtros">
        <div className="grid grid-cols-1 gap-3 md:grid-cols-[1fr_220px]">
          <input
            type="text"
            placeholder="Pesquisar por cliente, serviço ou profissional"
            value={busca}
            onChange={(e) => setBusca(e.target.value)}
            className="rounded-2xl border border-slate-200 p-3"
          />

          <select
            value={tipoMensagem}
            onChange={(e) => setTipoMensagem(e.target.value as TipoMensagem)}
            className="rounded-2xl border border-slate-200 p-3"
          >
            <option value="confirmacao">Confirmação</option>
            <option value="lembrete">Lembrete</option>
            <option value="cancelamento">Cancelamento</option>
            <option value="reagendamento">Reagendamento</option>
          </select>
        </div>
      </SectionCard>

      <SectionCard
        title="Agendamentos"
        description={`${agendamentosFiltrados.length} encontrado(s)`}
      >
        {loading ? (
          <p>Carregando...</p>
        ) : agendamentosFiltrados.length === 0 ? (
          <EmptyState title="Nenhum agendamento encontrado" />
        ) : (
          <div className="space-y-3">
            {agendamentosFiltrados.map((item) => (
              <div
                key={item.id}
                className="flex items-center justify-between rounded-2xl border border-slate-200 p-4"
              >
                <div>
                  <p className="font-semibold text-slate-800">{item.cliente}</p>
                  <p className="text-sm text-slate-500">
                    {item.servico} • {item.profissional}
                  </p>
                  <p className="text-xs text-slate-400">
                    {formatarData(item.data)} às {item.horario}
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => enviarMensagem(item)}
                  className="rounded-2xl bg-emerald-600 px-4 py-2 text-sm font-medium text-white transition hover:bg-emerald-700"
                >
                  Enviar WhatsApp
                </button>
              </div>
            ))}
          </div>
        )}
      </SectionCard>
    </div>
  );
}