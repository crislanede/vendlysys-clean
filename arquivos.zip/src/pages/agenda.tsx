import { useEffect, useState } from "react";
import { supabase } from "../lib/supabase";
import PageHeader from "../components/ui/PageHeader";
import SectionCard from "../components/ui/SectionCard";
import PrimaryButton from "../components/ui/PrimaryButton";
import SecondaryButton from "../components/ui/SecondaryButton";

import AlertaAnamneseAgenda from "../components/agenda/AlertaAnamneseAgenda";
import {
  buscarAlertasAnamneseCliente,
  type AlertaAnamneseItem,
} from "../lib/anamneseAlerta";

export default function AgendaPage() {
  const [clientes, setClientes] = useState<any[]>([]);
  const [servicos, setServicos] = useState<any[]>([]);
  const [profissionais, setProfissionais] = useState<any[]>([]);
  const [agendamentos, setAgendamentos] = useState<any[]>([]);

  const [cliente, setCliente] = useState("");
  const [servico, setServico] = useState("");
  const [profissional, setProfissional] = useState("");
  const [data, setData] = useState("");
  const [hora, setHora] = useState("");

  // 🔥 ANAMNESE
  const [alertas, setAlertas] = useState<AlertaAnamneseItem[]>([]);
  const [confirmou, setConfirmou] = useState(false);
  const [loadingAlerta, setLoadingAlerta] = useState(false);

  useEffect(() => {
    carregarTudo();
  }, []);

  async function carregarTudo() {
    const { data: c } = await supabase.from("clientes").select("*");
    const { data: s } = await supabase.from("servicos").select("*");
    const { data: p } = await supabase.from("profissionais").select("*");
    const { data: a } = await supabase.from("agendamentos").select("*");

    setClientes(c || []);
    setServicos(s || []);
    setProfissionais(p || []);
    setAgendamentos(a || []);
  }

  async function carregarAlertas(nomeCliente: string) {
    const c = clientes.find((x) => x.nome === nomeCliente);

    if (!c) return;

    setLoadingAlerta(true);

    const dados = await buscarAlertasAnamneseCliente({
      id: c.id,
      nome: c.nome,
    });

    setAlertas(dados);
    setConfirmou(false);
    setLoadingAlerta(false);
  }

  async function salvar() {
    if (!cliente || !servico || !data || !hora) {
      alert("Preencha todos os campos");
      return;
    }

    if (alertas.length > 0 && !confirmou) {
      alert("Confirme os alertas da anamnese");
      return;
    }

    await supabase.from("agendamentos").insert([
      {
        cliente,
        servico,
        profissional,
        data,
        horario: hora,
        status: "agendado",
      },
    ]);

    alert("Agendamento salvo");
    limpar();
    carregarTudo();
  }

  async function cancelar(id: string) {
    await supabase
      .from("agendamentos")
      .update({ status: "cancelado" })
      .eq("id", id);

    carregarTudo();
  }

  async function finalizar(id: string) {
    await supabase
      .from("agendamentos")
      .update({ status: "finalizado" })
      .eq("id", id);

    carregarTudo();
  }

  function limpar() {
    setCliente("");
    setServico("");
    setProfissional("");
    setData("");
    setHora("");
    setAlertas([]);
    setConfirmou(false);
  }

  return (
    <div className="p-6 space-y-6">
      <PageHeader title="Agenda" />

      <SectionCard title="Novo agendamento">
        <div className="grid gap-4 md:grid-cols-2">
          {/* CLIENTE */}
          <select
            value={cliente}
            onChange={(e) => {
              setCliente(e.target.value);
              carregarAlertas(e.target.value);
            }}
            className="border p-3 rounded-xl"
          >
            <option value="">Cliente</option>
            {clientes.map((c) => (
              <option key={c.id}>{c.nome}</option>
            ))}
          </select>

          {/* ALERTA */}
          <div className="md:col-span-2">
            <AlertaAnamneseAgenda
              alertas={alertas}
              loading={loadingAlerta}
            />
          </div>

          {alertas.length > 0 && (
            <div className="md:col-span-2 bg-red-50 p-3 rounded-xl">
              <label>
                <input
                  type="checkbox"
                  checked={confirmou}
                  onChange={(e) => setConfirmou(e.target.checked)}
                />{" "}
                Confirmo leitura da anamnese
              </label>
            </div>
          )}

          {/* SERVIÇO */}
          <select
            value={servico}
            onChange={(e) => setServico(e.target.value)}
            className="border p-3 rounded-xl"
          >
            <option>Serviço</option>
            {servicos.map((s) => (
              <option key={s.id}>{s.nome}</option>
            ))}
          </select>

          {/* PROFISSIONAL */}
          <select
            value={profissional}
            onChange={(e) => setProfissional(e.target.value)}
            className="border p-3 rounded-xl"
          >
            <option>Profissional</option>
            {profissionais.map((p) => (
              <option key={p.id}>{p.nome}</option>
            ))}
          </select>

          <input
            type="date"
            value={data}
            onChange={(e) => setData(e.target.value)}
            className="border p-3 rounded-xl"
          />

          <input
            type="time"
            value={hora}
            onChange={(e) => setHora(e.target.value)}
            className="border p-3 rounded-xl"
          />
        </div>

        <div className="mt-4 flex gap-3">
          <PrimaryButton onClick={salvar}>
            Salvar
          </PrimaryButton>

          <SecondaryButton onClick={limpar}>
            Limpar
          </SecondaryButton>
        </div>
      </SectionCard>

      <SectionCard title="Agendamentos">
        <div className="space-y-3">
          {agendamentos.map((a) => (
            <div
              key={a.id}
              className="border p-3 rounded-xl flex justify-between"
            >
              <div>
                <p className="font-bold">{a.cliente}</p>
                <p>{a.data} - {a.horario}</p>
                <p className="text-sm">{a.servico}</p>
              </div>

              <div className="flex gap-2">
                <PrimaryButton onClick={() => finalizar(a.id)}>
                  Finalizar
                </PrimaryButton>

                <SecondaryButton onClick={() => cancelar(a.id)}>
                  Cancelar
                </SecondaryButton>
              </div>
            </div>
          ))}
        </div>
      </SectionCard>
    </div>
  );
}