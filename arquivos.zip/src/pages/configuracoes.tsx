import { useEffect, useState } from "react";
import { supabase } from "../lib/supabase";

type Configuracao = {
  id?: string | number;
  nome_empresa?: string | null;
  nome_fantasia?: string | null;
  cor_primaria?: string | null;
  cor_secundaria?: string | null;
  cor_fundo?: string | null;
};

export default function Configuracoes() {
  const [config, setConfig] = useState<Configuracao>({
    nome_empresa: "",
    nome_fantasia: "",
    cor_primaria: "#f97316",
    cor_secundaria: "#0f172a",
    cor_fundo: "#f8fafc",
  });

  const [loading, setLoading] = useState(true);
  const [salvando, setSalvando] = useState(false);

  useEffect(() => {
    void carregarConfiguracao();
  }, []);

  async function carregarConfiguracao() {
    setLoading(true);

    const { data, error } = await supabase
      .from("configuracoes")
      .select(
        "id, nome_empresa, nome_fantasia, cor_primaria, cor_secundaria, cor_fundo"
      )
      .limit(1)
      .maybeSingle();

    if (error) {
      console.error("Erro ao carregar configurações:", error);
      setLoading(false);
      return;
    }

    if (data) {
      const novaConfig: Configuracao = {
        id: data.id,
        nome_empresa: data.nome_empresa || "",
        nome_fantasia: data.nome_fantasia || "",
        cor_primaria: data.cor_primaria || "#f97316",
        cor_secundaria: data.cor_secundaria || "#0f172a",
        cor_fundo: data.cor_fundo || "#f8fafc",
      };

      setConfig(novaConfig);
      aplicarTema(novaConfig);
    } else {
      const configPadrao: Configuracao = {
        nome_empresa: "",
        nome_fantasia: "",
        cor_primaria: "#f97316",
        cor_secundaria: "#0f172a",
        cor_fundo: "#f8fafc",
      };

      setConfig(configPadrao);
      aplicarTema(configPadrao);
    }

    setLoading(false);
  }

  function aplicarTema(cfg: Configuracao) {
    const root = document.documentElement;

    root.style.setProperty("--color-primary", cfg.cor_primaria || "#f97316");
    root.style.setProperty("--color-secondary", cfg.cor_secundaria || "#0f172a");
    root.style.setProperty("--color-background", cfg.cor_fundo || "#f8fafc");

    document.body.style.backgroundColor = cfg.cor_fundo || "#f8fafc";
  }

  function handleChange(campo: keyof Configuracao, valor: string) {
    const novaConfig = {
      ...config,
      [campo]: valor,
    };

    setConfig(novaConfig);
    aplicarTema(novaConfig);
  }

  async function salvar() {
    setSalvando(true);

    const payload = {
      nome_empresa: config.nome_empresa || null,
      nome_fantasia: config.nome_fantasia || null,
      cor_primaria: config.cor_primaria || "#f97316",
      cor_secundaria: config.cor_secundaria || "#0f172a",
      cor_fundo: config.cor_fundo || "#f8fafc",
    };

    if (config.id) {
      const { error } = await supabase
        .from("configuracoes")
        .update(payload)
        .eq("id", config.id);

      if (error) {
        console.error("Erro ao atualizar configurações:", error);
        alert("Erro ao atualizar configurações.");
        setSalvando(false);
        return;
      }
    } else {
      const { data, error } = await supabase
        .from("configuracoes")
        .insert([payload])
        .select(
          "id, nome_empresa, nome_fantasia, cor_primaria, cor_secundaria, cor_fundo"
        )
        .single();

      if (error) {
        console.error("Erro ao salvar configurações:", error);
        alert("Erro ao salvar configurações.");
        setSalvando(false);
        return;
      }

      setConfig((atual) => ({
        ...atual,
        id: data.id,
      }));
    }

    await carregarConfiguracao();

    alert("Configurações salvas com sucesso!");
    setSalvando(false);
  }

  if (loading) {
    return <p>Carregando...</p>;
  }

  return (
    <div className="space-y-6">
      <div>
        <p className="text-sm text-orange-500">Sistema</p>
        <h1 className="text-3xl font-bold text-slate-900">Configurações</h1>
        <p className="text-slate-500">
          Personalize o nome e a identidade visual do sistema.
        </p>
      </div>

      <div className="rounded-2xl bg-white p-6 shadow space-y-6">
        <div className="grid gap-4 md:grid-cols-2">
          <div>
            <label className="mb-1 block text-sm text-slate-600">
              Nome da empresa
            </label>
            <input
              value={config.nome_empresa || ""}
              onChange={(e) => handleChange("nome_empresa", e.target.value)}
              className="w-full rounded-lg border p-2"
            />
          </div>

          <div>
            <label className="mb-1 block text-sm text-slate-600">
              Nome fantasia
            </label>
            <input
              value={config.nome_fantasia || ""}
              onChange={(e) => handleChange("nome_fantasia", e.target.value)}
              className="w-full rounded-lg border p-2"
            />
          </div>
        </div>

        <div className="grid gap-6 md:grid-cols-3">
          <div>
            <label className="mb-2 block text-sm text-slate-600">
              Cor primária
            </label>
            <input
              type="color"
              value={config.cor_primaria || "#f97316"}
              onChange={(e) => handleChange("cor_primaria", e.target.value)}
              className="h-12 w-full rounded"
            />
          </div>

          <div>
            <label className="mb-2 block text-sm text-slate-600">
              Cor secundária
            </label>
            <input
              type="color"
              value={config.cor_secundaria || "#0f172a"}
              onChange={(e) => handleChange("cor_secundaria", e.target.value)}
              className="h-12 w-full rounded"
            />
          </div>

          <div>
            <label className="mb-2 block text-sm text-slate-600">
              Cor de fundo
            </label>
            <input
              type="color"
              value={config.cor_fundo || "#f8fafc"}
              onChange={(e) => handleChange("cor_fundo", e.target.value)}
              className="h-12 w-full rounded"
            />
          </div>
        </div>

        <div className="rounded-2xl border p-4">
          <p className="mb-3 text-sm font-medium text-slate-600">Prévia</p>

          <div
            className="rounded-2xl p-5"
            style={{
              backgroundColor: config.cor_fundo || "#f8fafc",
              border: "1px solid rgba(15,23,42,0.08)",
            }}
          >
            <div
              className="mb-4 rounded-xl px-4 py-3 text-white"
              style={{
                backgroundColor: config.cor_secundaria || "#0f172a",
              }}
            >
              <p className="text-sm opacity-80">Painel administrativo</p>
              <h3 className="text-xl font-bold">
                {config.nome_fantasia || config.nome_empresa || "Sua empresa"}
              </h3>
            </div>

            <button
              type="button"
              className="rounded-xl px-4 py-2 text-white font-semibold"
              style={{
                backgroundColor: config.cor_primaria || "#f97316",
              }}
            >
              Botão principal
            </button>
          </div>
        </div>

        <div>
          <button
            type="button"
            onClick={salvar}
            disabled={salvando}
            className="rounded-xl px-6 py-3 font-semibold text-white disabled:opacity-60"
            style={{
              backgroundColor: config.cor_primaria || "#f97316",
            }}
          >
            {salvando ? "Salvando..." : "Salvar configurações"}
          </button>
        </div>
      </div>
    </div>
  );
}