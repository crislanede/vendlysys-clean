type MensagemBaseParams = {
  cliente: string;
  servico?: string;
  profissional?: string;
  data?: string;
  horario?: string;
  empresa?: string;
  linkMeuEspaco?: string;
};

type MensagemReagendamentoParams = {
  cliente: string;
  servico?: string;
  profissional?: string;
  data?: string;
  horario?: string;
  novaData?: string;
  novoHorario?: string;
  empresa?: string;
  linkMeuEspaco?: string;
};

type MensagemCampanhaParams = {
  cliente?: string;
  titulo?: string;
  descricao?: string;
  conteudo?: string;
  empresa?: string;
  link?: string;
};

type MensagemPdfAnamneseParams = {
  cliente: string;
  empresa?: string;
  pdfUrl: string;
};

export function abrirWhatsapp(telefone: string, mensagem: string) {
  const numero = (telefone || "").replace(/\D/g, "");

  if (!numero) {
    alert("Telefone inválido para abrir o WhatsApp.");
    return;
  }

  const url = `https://wa.me/55${numero}?text=${encodeURIComponent(mensagem)}`;
  window.open(url, "_blank");
}

export function montarLinkMeuEspaco(token: string, baseUrl?: string) {
  const base =
    (baseUrl && baseUrl.trim()) ||
    window.location.origin;

  return `${base}/meu-espaco?token=${token}`;
}

export function montarMensagemConfirmacao({
  cliente,
  servico,
  profissional,
  data,
  horario,
  empresa,
  linkMeuEspaco,
}: MensagemBaseParams) {
  return [
    `Olá, ${cliente}!`,
    "",
    `Seu agendamento foi confirmado${empresa ? ` em *${empresa}*` : ""}.`,
    servico ? `• Serviço: ${servico}` : null,
    profissional ? `• Profissional: ${profissional}` : null,
    data ? `• Data: ${data}` : null,
    horario ? `• Horário: ${horario}` : null,
    linkMeuEspaco ? "" : null,
    linkMeuEspaco ? `Acesse seu Meu Espaço:` : null,
    linkMeuEspaco ? linkMeuEspaco : null,
    "",
    `Qualquer dúvida, estamos à disposição.`,
  ]
    .filter(Boolean)
    .join("\n");
}

export function montarMensagemCancelamento({
  cliente,
  servico,
  profissional,
  data,
  horario,
  empresa,
  linkMeuEspaco,
}: MensagemBaseParams) {
  return [
    `Olá, ${cliente}!`,
    "",
    `Seu agendamento foi cancelado${empresa ? ` em *${empresa}*` : ""}.`,
    servico ? `• Serviço: ${servico}` : null,
    profissional ? `• Profissional: ${profissional}` : null,
    data ? `• Data: ${data}` : null,
    horario ? `• Horário: ${horario}` : null,
    linkMeuEspaco ? "" : null,
    linkMeuEspaco ? `Acesse seu Meu Espaço:` : null,
    linkMeuEspaco ? linkMeuEspaco : null,
    "",
    `Se quiser, podemos te ajudar com um novo horário.`,
  ]
    .filter(Boolean)
    .join("\n");
}

export function montarMensagemLembrete({
  cliente,
  servico,
  profissional,
  data,
  horario,
  empresa,
  linkMeuEspaco,
}: MensagemBaseParams) {
  return [
    `Olá, ${cliente}!`,
    "",
    `Passando para lembrar do seu agendamento${empresa ? ` em *${empresa}*` : ""}.`,
    servico ? `• Serviço: ${servico}` : null,
    profissional ? `• Profissional: ${profissional}` : null,
    data ? `• Data: ${data}` : null,
    horario ? `• Horário: ${horario}` : null,
    linkMeuEspaco ? "" : null,
    linkMeuEspaco ? `Acesse seu Meu Espaço:` : null,
    linkMeuEspaco ? linkMeuEspaco : null,
    "",
    `Te esperamos!`,
  ]
    .filter(Boolean)
    .join("\n");
}

export function montarMensagemReagendamento({
  cliente,
  servico,
  profissional,
  data,
  horario,
  novaData,
  novoHorario,
  empresa,
  linkMeuEspaco,
}: MensagemReagendamentoParams) {
  return [
    `Olá, ${cliente}!`,
    "",
    `Seu agendamento foi reagendado${empresa ? ` em *${empresa}*` : ""}.`,
    servico ? `• Serviço: ${servico}` : null,
    profissional ? `• Profissional: ${profissional}` : null,
    data || horario
      ? `• Horário anterior: ${data || "-"}${horario ? ` às ${horario}` : ""}`
      : null,
    novaData || novoHorario
      ? `• Novo horário: ${novaData || "-"}${novoHorario ? ` às ${novoHorario}` : ""}`
      : null,
    linkMeuEspaco ? "" : null,
    linkMeuEspaco ? `Acesse seu Meu Espaço:` : null,
    linkMeuEspaco ? linkMeuEspaco : null,
    "",
    `Qualquer dúvida, estamos à disposição.`,
  ]
    .filter(Boolean)
    .join("\n");
}

export function montarMensagemCampanha({
  cliente,
  titulo,
  descricao,
  conteudo,
  empresa,
  link,
}: MensagemCampanhaParams) {
  const corpo = conteudo || descricao || "";

  return [
    cliente ? `Olá, ${cliente}!` : null,
    cliente ? "" : null,
    titulo ? `*${titulo}*` : null,
    empresa ? `*${empresa}*` : null,
    titulo || empresa ? "" : null,
    corpo || null,
    link ? "" : null,
    link ? link : null,
  ]
    .filter(Boolean)
    .join("\n");
}

export function montarMensagemPdfAnamnese({
  cliente,
  empresa,
  pdfUrl,
}: MensagemPdfAnamneseParams) {
  return [
    `Olá, ${cliente}!`,
    "",
    `Sua ficha de anamnese${empresa ? ` de *${empresa}*` : ""} foi registrada com sucesso.`,
    `Você pode acessar o PDF pelo link abaixo:`,
    pdfUrl,
    "",
    `Se precisar de algo, estamos à disposição.`,
  ].join("\n");
}