import { useEffect, useState } from "react";
import { NavLink } from "react-router-dom";
import { supabase } from "../../lib/supabase";

type Configuracao = {
  nome_empresa?: string | null;
  nome_fantasia?: string | null;
};

const menu = [
  { label: "Dashboard", to: "/dashboard" },
  { label: "Anamnese", to: "/anamnese-configuracao" },
  { label: "Agenda", to: "/agenda" },
  { label: "Clientes", to: "/clientes" },
  { label: "Financeiro", to: "/financeiro" },
  { label: "Serviços", to: "/servicos" },
  { label: "Profissionais", to: "/profissionais" },
  { label: "Usuários", to: "/usuarios" },
  { label: "Bloqueios", to: "/bloqueios" },
  { label: "Despesas", to: "/despesas" },
  { label: "Caixa", to: "/caixa" },
  { label: "Relatórios", to: "/relatorios" },
  { label: "Comissões", to: "/comissoes" },
  { label: "Pagamentos", to: "/pagamentos" },
  { label: "WhatsApp", to: "/whatsapp" },
  { label: "Campanhas", to: "/whatsapp-campanha" },
  { label: "Configurações", to: "/configuracoes" },
];

export default function Sidebar() {
  const [configuracao, setConfiguracao] = useState<Configuracao | null>(null);

  useEffect(() => {
    void carregarConfiguracao();
  }, []);

  async function carregarConfiguracao() {
    const { data, error } = await supabase
      .from("configuracoes")
      .select("nome_empresa, nome_fantasia")
      .limit(1)
      .maybeSingle();

    if (error) {
      console.error("Erro ao carregar configurações da sidebar:", error);
      return;
    }

    setConfiguracao(data || null);
  }

  const nomeEmpresa =
    configuracao?.nome_fantasia ||
    configuracao?.nome_empresa ||
    "VendlySys";

  return (
    <aside
      className="flex min-h-screen w-72 flex-col"
      style={{
        backgroundColor: "var(--color-secondary)",
        color: "#fff",
      }}
    >
      <div className="px-5 py-7">
        <div className="flex items-center gap-3">
          <div
            className="flex h-14 w-14 items-center justify-center rounded-full text-xl font-bold text-white"
            style={{ backgroundColor: "var(--color-primary)" }}
          >
            {nomeEmpresa.charAt(0).toUpperCase()}
          </div>

          <div>
            <h2 className="text-3xl font-extrabold leading-none">
              {nomeEmpresa}
            </h2>
            <p className="mt-1 text-sm text-white/80">Gestão de agendas</p>
          </div>
        </div>
      </div>

      <nav className="flex-1 space-y-2 px-4">
        {menu.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            className="block rounded-2xl px-4 py-3 text-base font-semibold transition"
            style={({ isActive }) => ({
              backgroundColor: isActive ? "var(--color-primary)" : "transparent",
              color: "#ffffff",
              opacity: isActive ? 1 : 0.9,
            })}
          >
            {item.label}
          </NavLink>
        ))}
      </nav>
    </aside>
  );
}