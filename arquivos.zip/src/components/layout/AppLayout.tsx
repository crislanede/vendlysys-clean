import { useEffect, useState } from "react";
import { Outlet } from "react-router-dom";
import { supabase } from "../../lib/supabase";
import Sidebar from "./Sidebar";

type Configuracao = {
  id?: string;
  nome_empresa?: string | null;
  nome_fantasia?: string | null;
  cor_primaria?: string | null;
  cor_secundaria?: string | null;
  cor_fundo?: string | null;
};

export default function AppLayout() {
  const [configuracao, setConfiguracao] = useState<Configuracao | null>(null);

  useEffect(() => {
    void carregarConfiguracao();
  }, []);

  useEffect(() => {
    if (!configuracao) return;

    const corPrimaria = configuracao.cor_primaria || "#f97316";
    const corSecundaria = configuracao.cor_secundaria || "#0f172a";
    const corFundo = configuracao.cor_fundo || "#f8fafc";

    document.documentElement.style.setProperty("--color-primary", corPrimaria);
    document.documentElement.style.setProperty(
      "--color-secondary",
      corSecundaria
    );
    document.documentElement.style.setProperty("--color-background", corFundo);

    document.body.style.backgroundColor = corFundo;
  }, [configuracao]);

  async function carregarConfiguracao() {
    const { data, error } = await supabase
      .from("configuracoes")
      .select(
        "id, nome_empresa, nome_fantasia, cor_primaria, cor_secundaria, cor_fundo"
      )
      .limit(1)
      .maybeSingle();

    if (error) {
      console.error("Erro ao carregar configurações do layout:", error);
      return;
    }

    setConfiguracao((data || null) as Configuracao | null);
  }

  const nomeEmpresa =
    configuracao?.nome_fantasia ||
    configuracao?.nome_empresa ||
    "VendlySys";

  return (
    <div
      className="flex min-h-screen"
      style={{ backgroundColor: "var(--color-background)" }}
    >
      <Sidebar />

      <div className="flex min-h-screen flex-1 flex-col">
        <header
          className="flex items-center justify-between border-b px-6 py-4"
          style={{
            backgroundColor: "#ffffff",
            borderColor: "rgba(15, 23, 42, 0.08)",
          }}
        >
          <div>
            <p
              className="text-xs"
              style={{ color: "var(--color-secondary)" }}
            >
              Painel administrativo
            </p>

            <h1
              className="text-lg font-semibold"
              style={{ color: "var(--color-secondary)" }}
            >
              {nomeEmpresa}
            </h1>
          </div>

          <div className="flex items-center gap-3">
            <button
              type="button"
              className="rounded-xl border px-4 py-2 text-sm"
              style={{
                borderColor: "rgba(15, 23, 42, 0.12)",
                color: "var(--color-secondary)",
                backgroundColor: "#fff",
              }}
            >
              Notificações
            </button>

            <div
              className="flex h-10 w-10 items-center justify-center rounded-full text-sm font-semibold text-white"
              style={{ backgroundColor: "var(--color-primary)" }}
            >
              C
            </div>

            <button
              type="button"
              className="rounded-xl border px-4 py-2 text-sm"
              style={{
                borderColor: "rgba(15, 23, 42, 0.12)",
                color: "var(--color-secondary)",
                backgroundColor: "#fff",
              }}
            >
              Sair
            </button>
          </div>
        </header>

        <main className="flex-1 p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}