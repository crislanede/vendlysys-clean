import type { ButtonHTMLAttributes } from "react";

type Props = ButtonHTMLAttributes<HTMLButtonElement>;

export default function SecondaryButton({ children, style, ...props }: Props) {
  return (
    <button
      {...props}
      style={{
        backgroundColor: "#fff",
        color: "var(--color-secondary)",
        borderRadius: "14px",
        padding: "10px 16px",
        fontWeight: 600,
        border: "1px solid rgba(15, 23, 42, 0.12)",
        cursor: "pointer",
        ...style,
      }}
    >
      {children}
    </button>
  );
}