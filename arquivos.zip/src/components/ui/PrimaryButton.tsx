import type { ButtonHTMLAttributes } from "react";

type Props = ButtonHTMLAttributes<HTMLButtonElement>;

export default function PrimaryButton({ children, style, ...props }: Props) {
  return (
    <button
      {...props}
      style={{
        backgroundColor: "var(--color-primary)",
        color: "#fff",
        borderRadius: "14px",
        padding: "10px 16px",
        fontWeight: 600,
        border: "none",
        cursor: "pointer",
        ...style,
      }}
    >
      {children}
    </button>
  );
}