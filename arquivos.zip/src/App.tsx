import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";

import AppLayout from "./components/layout/AppLayout";
import AnamneseConfiguracaoPage from "./pages/anamnese-configuracao";

import Dashboard from "./pages/dashboard";
import AgendaPage from "./pages/agenda";
import Clientes from "./pages/clientes";
import Financeiro from "./pages/financeiro";
import Servicos from "./pages/servicos";
import Profissionais from "./pages/profissionais";
import Usuarios from "./pages/usuarios";
import Configuracoes from "./pages/configuracoes";
import Relatorios from "./pages/relatorios";
import Login from "./pages/login";
import MeuEspaco from "./pages/meu-espaco";
import Bloqueios from "./pages/bloqueios";
import Caixa from "./pages/caixa";
import Comissoes from "./pages/comissoes";
import Despesas from "./pages/despesas";
import Pagamentos from "./pages/pagamentos";
import Whatsapp from "./pages/whatsapp";
import WhatsappCampanha from "./pages/whatsapp-campanha";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/meu-espaco" element={<MeuEspaco />} />

        <Route path="/" element={<AppLayout />}>
        <Route path="anamnese-configuracao" element={<AnamneseConfiguracaoPage />} />
          <Route index element={<Dashboard />} />
          <Route path="dashboard" element={<Dashboard />} />
        <Route path="/agenda" element={<AgendaPage />} />
          <Route path="clientes" element={<Clientes />} />
          <Route path="financeiro" element={<Financeiro />} />
          <Route path="servicos" element={<Servicos />} />
          <Route path="profissionais" element={<Profissionais />} />
          <Route path="usuarios" element={<Usuarios />} />
          <Route path="configuracoes" element={<Configuracoes />} />
          <Route path="relatorios" element={<Relatorios />} />
          <Route path="bloqueios" element={<Bloqueios />} />
          <Route path="caixa" element={<Caixa />} />
          <Route path="comissoes" element={<Comissoes />} />
          <Route path="despesas" element={<Despesas />} />
          <Route path="pagamentos" element={<Pagamentos />} />
          <Route path="whatsapp" element={<Whatsapp />} />
          <Route path="whatsapp-campanha" element={<WhatsappCampanha />} />
        </Route>

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}